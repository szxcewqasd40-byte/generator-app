package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.generator.ui.components.ElectricBadge
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.screens.*
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: GeneratorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val colorPalette by viewModel.colorPalette.collectAsState()

            GeneratorBillingTheme(
                themeMode = themeMode,
                colorPalette = colorPalette
            ) {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

/**
 * تبويبات شريط التنقل السفلي الموحدة:
 * 1. الرئيسية (اللوحة العامة والإحصائيات)
 * 2. المشتركين والتحصيل (المركز الرئيسي لإدارة المشتركين والجباية وتسديد الفواتير والطباعة)
 * 3. المصروفات (إدارة النفقات والوقود والصيانة)
 * 4. التقارير (التقارير المالية وحسابات الأرباح)
 * 5. الإعدادات (إعدادات المولدة، الأسعار، الحسابات، والنسخ الاحتياطي)
 */
sealed class NavTab(val title: String, val icon: ImageVector) {
    data object Dashboard : NavTab("الرئيسية", Icons.Default.Dashboard)
    data object SubscribersAndCollection : NavTab("المشتركين والتحصيل", Icons.Default.Payments)
    data object Expenses : NavTab("المصروفات", Icons.Default.TrendingDown)
    data object Reports : NavTab("التقارير", Icons.Default.Assessment)
    data object Settings : NavTab("الإعدادات", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: GeneratorViewModel) {
    var selectedTab by remember { mutableStateOf<NavTab>(NavTab.Dashboard) }
    val snackbarHostState = remember { SnackbarHostState() }
    val message by viewModel.message.collectAsState()
    val isAppLocked by viewModel.isAppLocked.collectAsState()
    val isAppLockEnabled by viewModel.isAppLockEnabled.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val currentUserProfile by viewModel.currentUserProfile.collectAsState()

    val hasFullAccess by viewModel.hasFullAccess.collectAsState()
    var showPaywallDialog by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                viewModel.onAppBackgrounded()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // 1. FIRST-TIME AUTHENTICATION GATEWAY (Google One-Tap & Phone SMS sign in)
    if (currentUserProfile == null) {
        Box(modifier = Modifier.fillMaxSize()) {
            WelcomeSignInScreen(
                viewModel = viewModel,
                onSuccess = {}
            )
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
    // 2. OPTIONAL APP LOCK (If owner explicitly enabled it in Settings)
    else if (isAppLockEnabled && isAppLocked) {
        Box(modifier = Modifier.fillMaxSize()) {
            AppLockScreen(viewModel = viewModel)
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
    // 3. TRIAL EXPIRED PAYWALL GATE (7-Day Trial Expired and no active subscription)
    else if (!hasFullAccess) {
        Box(modifier = Modifier.fillMaxSize()) {
            SubscriptionPaywallDialog(
                viewModel = viewModel,
                onDismiss = {}
            )
        }
    }
    // 4. MAIN APP INTERFACE (Cyber Midnight Navigation & Glass Scaffolding)
    else {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "مولدتي",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextWhitePrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            ElectricBadge(
                                text = "⚡ مزامنة سحابية",
                                color = ElectricCyan
                            )
                        }
                    },
                    actions = {
                        if (currentUserProfile != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0x330C1635),
                                border = BorderStroke(1.dp, Color(0x2238BDF8))
                            ) {
                                Text(
                                    text = currentUserProfile?.displayName ?: (currentUser?.name ?: ""),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = TextWhitePrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        if (isAppLockEnabled) {
                            IconButton(onClick = { viewModel.lockApp() }) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "قفل التطبيق",
                                    tint = ElectricCyan
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            },
            bottomBar = {
                Surface(
                    color = MaterialTheme.colorScheme.background,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.background,
                        tonalElevation = 8.dp
                    ) {
                        val items = listOf(
                            NavTab.Dashboard,
                            NavTab.SubscribersAndCollection,
                            NavTab.Expenses,
                            NavTab.Reports,
                            NavTab.Settings
                        )

                        items.forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        tab.icon,
                                        contentDescription = tab.title,
                                        tint = if (selectedTab == tab) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                label = {
                                    Text(
                                        tab.title,
                                        fontSize = 10.sp,
                                        color = if (selectedTab == tab) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    NavTab.Dashboard -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToSubscribers = { selectedTab = NavTab.SubscribersAndCollection },
                        onNavigateToBills = { selectedTab = NavTab.SubscribersAndCollection },
                        onNavigateToExpenses = { selectedTab = NavTab.Expenses },
                        onNavigateToBackup = { selectedTab = NavTab.Settings }
                    )
                    NavTab.SubscribersAndCollection -> SubscribersScreen(viewModel = viewModel)
                    NavTab.Expenses -> ExpensesScreen(viewModel = viewModel)
                    NavTab.Reports -> ReportsScreen(viewModel = viewModel)
                    NavTab.Settings -> SettingsBackupScreen(viewModel = viewModel)
                }

                if (showPaywallDialog) {
                    SubscriptionPaywallDialog(
                        viewModel = viewModel,
                        onDismiss = { showPaywallDialog = false }
                    )
                }
            }
        }
    }
}
