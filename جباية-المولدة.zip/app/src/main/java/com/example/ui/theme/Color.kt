package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// 1. ORIGINAL CYBER MIDNIGHT (اللون الأصلي الفاخر - أزرق كهربائي وسيان وذهب)
// ==========================================
val MidnightNavyDeep = Color(0xFF070B19)          // Base Deepest Midnight
val MidnightNavyTop = Color(0xFF0C142E)           // Gradient top
val MidnightNavyCard = Color(0xCC111D45)          // Glassmorphic Blue Card
val GlassSurface = Color(0x1AFFFFFF)              // Light glass overlay
val GlassBorder = Color(0x3338BDF8)               // Cyan glass border

val ElectricCyan = Color(0xFF00F0FF)              // Vibrant Electric Cyan
val ElectricCyanMuted = Color(0xFF0284C7)
val ElectricCyanGlow = Color(0x6600F0FF)
val ElectricBlue = Color(0xFF38BDF8)

val MetallicGold = Color(0xFFF59E0B)
val MetallicGoldGlow = Color(0x66F59E0B)
val MetallicSilver = Color(0xFFCBD5E1)
val MetallicEmerald = Color(0xFF10B981)
val MetallicCrimson = Color(0xFFEF4444)

// ==========================================
// 2. MONOCHROME BLACK & WHITE (أبيض وأسود عالي التباين)
// ==========================================
// Dark Monochrome (أسود نقي، رمادي فحمي، أبيض ناصع)
val BWDarkBackground = Color(0xFF000000)
val BWDarkSurface = Color(0xFF121212)
val BWDarkCard = Color(0xFF1E1E1E)
val BWDarkBorder = Color(0xFF383838)
val BWDarkPrimary = Color(0xFFFFFFFF)
val BWDarkOnPrimary = Color(0xFF000000)
val BWDarkSecondary = Color(0xFFE0E0E0)
val BWDarkMuted = Color(0xFFA0A0A0)

// Light Monochrome (أبيض ناصع، رمادي فاتح، أسود داكن)
val BWLightBackground = Color(0xFFF8F9FA)
val BWLightSurface = Color(0xFFFFFFFF)
val BWLightCard = Color(0xFFFFFFFF)
val BWLightBorder = Color(0xFFD1D5DB)
val BWLightPrimary = Color(0xFF111827)
val BWLightOnPrimary = Color(0xFFFFFFFF)
val BWLightSecondary = Color(0xFF374151)
val BWLightMuted = Color(0xFF6B7280)

// ==========================================
// 3. LIGHT MODE GENERAL (الوضع النهاري العام)
// ==========================================
val LightBaseBg = Color(0xFFF1F5F9)
val LightTopBg = Color(0xFFE2E8F0)
val LightCardBg = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFCBD5E1)

// ==========================================
// 4. ROYAL BLUE (الأزرق الملكي الرسمي)
// ==========================================
val RoyalBluePrimaryDark = Color(0xFF3B82F6)
val RoyalBluePrimaryLight = Color(0xFF1D4ED8)
val RoyalBlueDarkBg = Color(0xFF0A1128)
val RoyalBlueDarkCard = Color(0xFF142145)

// ==========================================
// 5. EMERALD GREEN (الأخضر الطاقي الزمردي)
// ==========================================
val EmeraldPrimaryDark = Color(0xFF10B981)
val EmeraldPrimaryLight = Color(0xFF047857)
val EmeraldDarkBg = Color(0xFF041C15)
val EmeraldDarkCard = Color(0xFF0A3026)

// ==========================================
// TYPOGRAPHY & COMMON ALIASES
// ==========================================
val TextWhitePrimary = Color(0xFFF8FAFC)
val TextCyanSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val TextDarkPrimary = Color(0xFF0F172A)
val TextDarkSecondary = Color(0xFF334155)
val TextDarkMuted = Color(0xFF64748B)

// Legacy Compatibility Aliases
val CorporateNavyPrimary = ElectricCyanMuted
val CorporateNavyLight = ElectricBlue
val CorporateNavyDark = MidnightNavyDeep
val CorporateSlate = MidnightNavyDeep

val AccentEmerald = MetallicEmerald
val AccentEmeraldLight = Color(0xFF34D399)
val AccentGold = MetallicGold
val AccentRed = MetallicCrimson

val LightBackground = LightBaseBg
val LightSurface = LightCardBg
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightOnSurface = TextDarkPrimary

val DarkBackground = MidnightNavyDeep
val DarkSurface = MidnightNavyCard
val DarkSurfaceVariant = Color(0xFF16234D)
val DarkOnSurface = TextWhitePrimary
