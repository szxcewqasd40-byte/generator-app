package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.generator.util.AppColorPalette
import com.example.generator.util.AppThemeMode

// =========================================================================
// 1. ORIGINAL CYBER PALETTE (Dark & Light)
// =========================================================================
val MidnightElectricDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = MidnightNavyDeep,
    primaryContainer = Color(0xFF0C2752),
    onPrimaryContainer = ElectricCyan,
    secondary = MetallicGold,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF3B2503),
    onSecondaryContainer = MetallicGold,
    tertiary = MetallicEmerald,
    onTertiary = Color.Black,
    background = MidnightNavyDeep,
    surface = MidnightNavyCard,
    surfaceVariant = Color(0xFF132048),
    onBackground = TextWhitePrimary,
    onSurface = TextWhitePrimary,
    onSurfaceVariant = TextCyanSecondary,
    outline = GlassBorder,
    outlineVariant = Color(0x2200F0FF),
    error = MetallicCrimson,
    onError = Color.White
)

val MidnightElectricLightColorScheme = lightColorScheme(
    primary = ElectricCyanMuted,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFFD97706),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFEF3C7),
    onSecondaryContainer = Color(0xFF92400E),
    tertiary = Color(0xFF059669),
    onTertiary = Color.White,
    background = LightBaseBg,
    surface = LightCardBg,
    surfaceVariant = Color(0xFFE2E8F0),
    onBackground = TextDarkPrimary,
    onSurface = TextDarkPrimary,
    onSurfaceVariant = TextDarkSecondary,
    outline = LightCardBorder,
    outlineVariant = Color(0xFFCBD5E1),
    error = Color(0xFFDC2626),
    onError = Color.White
)

// =========================================================================
// 2. MONOCHROME BLACK & WHITE PALETTE (Dark & Light)
// =========================================================================
val MonochromeDarkColorScheme = darkColorScheme(
    primary = BWDarkPrimary,
    onPrimary = BWDarkOnPrimary,
    primaryContainer = Color(0xFF2A2A2A),
    onPrimaryContainer = Color(0xFFFFFFFF),
    secondary = Color(0xFFE5E7EB),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF374151),
    onSecondaryContainer = Color(0xFFF3F4F6),
    tertiary = Color(0xFFD1D5DB),
    onTertiary = Color.Black,
    background = BWDarkBackground,
    surface = BWDarkSurface,
    surfaceVariant = BWDarkCard,
    onBackground = Color(0xFFFFFFFF),
    onSurface = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFFD1D5DB),
    outline = BWDarkBorder,
    outlineVariant = Color(0xFF4B5563),
    error = Color(0xFFEF4444),
    onError = Color.White
)

val MonochromeLightColorScheme = lightColorScheme(
    primary = BWLightPrimary,
    onPrimary = BWLightOnPrimary,
    primaryContainer = Color(0xFFE5E7EB),
    onPrimaryContainer = Color(0xFF111827),
    secondary = Color(0xFF374151),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF3F4F6),
    onSecondaryContainer = Color(0xFF1F2937),
    tertiary = Color(0xFF4B5563),
    onTertiary = Color.White,
    background = BWLightBackground,
    surface = BWLightSurface,
    surfaceVariant = Color(0xFFF3F4F6),
    onBackground = Color(0xFF111827),
    onSurface = Color(0xFF111827),
    onSurfaceVariant = Color(0xFF4B5563),
    outline = BWLightBorder,
    outlineVariant = Color(0xFFE5E7EB),
    error = Color(0xFFDC2626),
    onError = Color.White
)

// =========================================================================
// 3. ROYAL BLUE PALETTE
// =========================================================================
val RoyalBlueDarkColorScheme = darkColorScheme(
    primary = RoyalBluePrimaryDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFBFDBFE),
    secondary = MetallicGold,
    onSecondary = Color.Black,
    background = RoyalBlueDarkBg,
    surface = RoyalBlueDarkCard,
    surfaceVariant = Color(0xFF1E293B),
    onBackground = TextWhitePrimary,
    onSurface = TextWhitePrimary,
    onSurfaceVariant = TextCyanSecondary,
    outline = Color(0x333B82F6),
    error = MetallicCrimson,
    onError = Color.White
)

val RoyalBlueLightColorScheme = lightColorScheme(
    primary = RoyalBluePrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E40AF),
    secondary = Color(0xFFD97706),
    onSecondary = Color.White,
    background = LightBaseBg,
    surface = LightCardBg,
    surfaceVariant = Color(0xFFE2E8F0),
    onBackground = TextDarkPrimary,
    onSurface = TextDarkPrimary,
    onSurfaceVariant = TextDarkSecondary,
    outline = LightCardBorder,
    error = Color(0xFFDC2626),
    onError = Color.White
)

// =========================================================================
// 4. EMERALD GREEN PALETTE
// =========================================================================
val EmeraldDarkColorScheme = darkColorScheme(
    primary = EmeraldPrimaryDark,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF064E3B),
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = MetallicGold,
    onSecondary = Color.Black,
    background = EmeraldDarkBg,
    surface = EmeraldDarkCard,
    surfaceVariant = Color(0xFF0F3D32),
    onBackground = TextWhitePrimary,
    onSurface = TextWhitePrimary,
    onSurfaceVariant = TextCyanSecondary,
    outline = Color(0x3310B981),
    error = MetallicCrimson,
    onError = Color.White
)

val EmeraldLightColorScheme = lightColorScheme(
    primary = EmeraldPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1FAE5),
    onPrimaryContainer = Color(0xFF065F46),
    secondary = Color(0xFFD97706),
    onSecondary = Color.White,
    background = LightBaseBg,
    surface = LightCardBg,
    surfaceVariant = Color(0xFFE2E8F0),
    onBackground = TextDarkPrimary,
    onSurface = TextDarkPrimary,
    onSurfaceVariant = TextDarkSecondary,
    outline = LightCardBorder,
    error = Color(0xFFDC2626),
    onError = Color.White
)

/**
 * دالة مساعدة لتحديد نظام الألوان المناسب بناءً على اختيار المستخدم
 */
fun resolveColorScheme(
    themeMode: AppThemeMode,
    colorPalette: AppColorPalette,
    systemDark: Boolean
): Pair<ColorScheme, Boolean> {
    val isDark = when (themeMode) {
        AppThemeMode.SYSTEM -> systemDark
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
    }

    val scheme = when (colorPalette) {
        AppColorPalette.ORIGINAL_CYBER -> if (isDark) MidnightElectricDarkColorScheme else MidnightElectricLightColorScheme
        AppColorPalette.MONOCHROME_BW -> if (isDark) MonochromeDarkColorScheme else MonochromeLightColorScheme
        AppColorPalette.ROYAL_BLUE -> if (isDark) RoyalBlueDarkColorScheme else RoyalBlueLightColorScheme
        AppColorPalette.EMERALD_GREEN -> if (isDark) EmeraldDarkColorScheme else EmeraldLightColorScheme
    }

    return Pair(scheme, isDark)
}

@Composable
fun GeneratorBillingTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    colorPalette: AppColorPalette = AppColorPalette.ORIGINAL_CYBER,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val (colorScheme, _) = resolveColorScheme(themeMode, colorPalette, systemDark)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
