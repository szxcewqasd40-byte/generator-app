package com.example.generator.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

object VoiceInputHelper {

    /**
     * Converts Arabic-Indic digits and removes unwanted symbols
     */
    fun normalizeArabicDigits(input: String): String {
        return input
            .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
            .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
            .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
            .trim()
    }

    /**
     * Extracts pure numeric digits from spoken voice (e.g. for phone numbers, amounts, amperes)
     */
    fun extractNumericOnly(input: String): String {
        val normalized = normalizeArabicDigits(input)
        return normalized.filter { it.isDigit() || it == '.' }
    }
}

/**
 * Creates and remembers a Voice Speech-to-Text launcher using Google / Android Speech recognizer.
 */
@Composable
fun rememberVoiceInputLauncher(
    prompt: String = "تحدث الآن بالصوت للإدخال أو البحث...",
    onResult: (String) -> Unit
): () -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                val cleanedText = VoiceInputHelper.normalizeArabicDigits(spokenText.trim())
                onResult(cleanedText)
                Toast.makeText(context, "تم التقاط الصوت: $cleanedText", Toast.LENGTH_SHORT).show()
            }
        }
    }

    return {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "ar")
                putExtra(RecognizerIntent.EXTRA_PROMPT, prompt)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            launcher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "تطبيق التعرف على الصوت غير متاح، يرجى تفعيل خدمة Google Voice أو ميكروفون الهاتف",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

/**
 * Animated Voice Action Button that can be placed in text fields or toolbars.
 */
@Composable
fun VoiceIconButton(
    onVoiceInput: (String) -> Unit,
    modifier: Modifier = Modifier,
    prompt: String = "تحدث الآن بالصوت...",
    tint: Color = MaterialTheme.colorScheme.primary,
    tooltip: String = "إدخال بالصوت"
) {
    val launchVoice = rememberVoiceInputLauncher(prompt = prompt, onResult = onVoiceInput)

    IconButton(
        onClick = { launchVoice() },
        modifier = modifier
    ) {
        Icon(
            imageVector = Icons.Default.Mic,
            contentDescription = tooltip,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
    }
}

/**
 * Search Bar with integrated Voice Search microphone button and clear button.
 */
@Composable
fun VoiceSearchTextField(
    query: String,
    onQueryChange: (String) -> Unit,
    placeholderText: String = "ابحث هنا أو اضغط الميكروفون للتحدث...",
    modifier: Modifier = Modifier,
    prompt: String = "تحدث الآن للبحث الصوتي..."
) {
    val launchVoice = rememberVoiceInputLauncher(
        prompt = prompt,
        onResult = { spokenText ->
            onQueryChange(spokenText)
        }
    )

    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier,
        placeholder = { Text(placeholderText, fontSize = 13.sp) },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "بحث",
                tint = MaterialTheme.colorScheme.primary
            )
        },
        trailingIcon = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.padding(end = 4.dp)
            ) {
                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = { onQueryChange("") },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "مسح",
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Voice Search Button with Badge/Tint
                IconButton(
                    onClick = { launchVoice() },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "بحث صوتي",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        )
    )
}
