package com.example.generator.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.view.View
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.GeneratorSettings
import com.example.generator.data.entity.Payment
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

object PrintHelper {

    fun formatCurrency(amount: Double): String {
        val formatter = NumberFormat.getInstance(Locale("ar"))
        return "${formatter.format(amount)} د.ع"
    }

    /**
     * مشاركة الفاتورة عبر واتساب والتطبيقات.
     * تم تحديث التاريخ والوقت ليتم جلبهما مباشرة من ساعة وتاريخ الهاتف الحالية (System Current Date & Time)
     * لحظة الضغط على زر المشاركة ليعكس وقت وتاريخ التسديد/الإصدار الفعلي بدلاً من التاريخ القديم.
     */
    fun shareBillWhatsApp(context: Context, bill: Bill, settings: GeneratorSettings?) {
        val genName = settings?.generatorName ?: "مولدة الكهرباء الأهلية"
        val ownerName = settings?.ownerName?.takeIf { it.isNotBlank() } ?: "غير محدد"
        val phone = settings?.phone?.takeIf { it.isNotBlank() } ?: "غير متوفر"
        val mastercard = settings?.mastercardNumber?.takeIf { it.isNotBlank() }
        val address = settings?.address?.takeIf { it.isNotBlank() }
        
        // System Current Date & Time لحظة الضغط
        val dateFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
        val dateStr = dateFormat.format(Date())

        val text = """
            ⚡ *إيصال فاتورة كهرباء - $genName* ⚡
            ------------------------------------
            👤 *صاحب المولدة:* $ownerName
            📞 *رقم الهاتف:* $phone
            📅 *تاريخ وساعة التسديد:* $dateStr
            ------------------------------------
            📄 *رقم الفاتورة:* ${bill.billCode}
            👤 *المشترك:* ${bill.subscriberName} (${bill.subscriberCode})
            🗓️ *الفترة:* شهر ${bill.month} / ${bill.year}
            ⚡ *عدد الأمبيرات:* ${bill.amperes} أمبير
            💰 *سعر الأمبير:* ${formatCurrency(bill.pricePerAmpere)}${if (bill.fixedFee > 0) "\n🔌 *الفيزة الثابتة:* ${formatCurrency(bill.fixedFee)}" else ""}
            ------------------------------------
            💵 *المبلغ الإجمالي:* ${formatCurrency(bill.totalAmount)}
            ✅ *المبلغ المدفوع:* ${formatCurrency(bill.paidAmount)}
            🔴 *المبلغ المتبقي (الدين):* ${formatCurrency(bill.remainingAmount)}
            ------------------------------------
            ${if (address != null) "📍 *العنوان:* $address\n------------------------------------" else ""}${if (mastercard != null) "💳 *الدفع الإلكتروني (ماستر كارد / بنكي):*\n`$mastercard`\n📸 *يرجى إرسال صورة إشعار/وصل التحويل لتأكيد التسديد.*\n------------------------------------" else ""}
            ║█║▌║█║▌│║▌║▌█║
            *باركود الفاتورة:* ${bill.billCode}
            ------------------------------------
            شكراً لالتزامكم بالتسديد.
        """.trimIndent()

        shareText(context, text, "مشاركة الفاتورة عبر")
    }

    fun shareText(context: Context, text: String, title: String = "مشاركة النص عبر") {
        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            val chooser = Intent.createChooser(sendIntent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "حدث خطأ أثناء المشاركة: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareTextWhatsApp(context: Context, message: String) {
        shareText(context, message, "مشاركة عبر واتساب أو التطبيقات")
    }

    fun shareFile(context: Context, file: File, mimeType: String, title: String) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "فشل فتح مشاركة الملف: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * مشاركة إيصال استلام الدفعة عبر واتساب مع جلب تاريخ ووقت الهاتف الحالي لحظة المشاركة
     */
    fun sharePaymentWhatsApp(context: Context, payment: Payment, bill: Bill?, settings: GeneratorSettings?) {
        val genName = settings?.generatorName ?: "مولدة الكهرباء الأهلية"
        val ownerName = settings?.ownerName?.takeIf { it.isNotBlank() } ?: "غير محدد"
        val phone = settings?.phone?.takeIf { it.isNotBlank() } ?: "غير متوفر"
        val address = settings?.address?.takeIf { it.isNotBlank() }
        
        // System Current Date & Time لحظة الضغط على زر الإرسال
        val dateFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
        val dateStr = dateFormat.format(Date())

        val text = """
            🧾 *إيصال استلام دفعة - $genName* 🧾
            ------------------------------------
            👤 *صاحب المولدة:* $ownerName
            📞 *رقم الهاتف:* $phone
            📅 *تاريخ وساعة التسديد الفعلية:* $dateStr
            ------------------------------------
            🔢 *رقم الإيصال:* ${payment.receiptCode}
            👤 *المشترك:* ${payment.subscriberName}
            💵 *المبلغ المقبوض:* ${formatCurrency(payment.amountPaid)}
            ------------------------------------
            ${if (bill != null) "🔴 *المتبقي من الفاتورة:* ${formatCurrency(bill.remainingAmount)}\n------------------------------------" else ""}${if (address != null) "📍 *العنوان:* $address\n------------------------------------" else ""}✍️ *المستلم:* ${payment.collectedBy}
            ------------------------------------
            ║█║▌║█║▌│║▌║▌█║
            *باركود الإيصال:* ${payment.receiptCode}
            ------------------------------------
            شكراً لتسديدكم المبلغ.
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة الإيصال عبر"))
    }

    /**
     * Generates a PDF file for a Bill / Receipt and shares it.
     * تم تحديث التاريخ والوقت ليتم جلبهما من System Current Date & Time لحظة التصدير.
     */
    fun generateAndSharePdfBill(context: Context, bill: Bill, settings: GeneratorSettings?) {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint()
        paint.color = Color.BLACK
        paint.textSize = 20f
        paint.isAntiAlias = true

        val genName = settings?.generatorName ?: "مولدة الكهرباء الأهلية"
        val ownerName = settings?.ownerName?.takeIf { it.isNotBlank() } ?: "غير محدد"
        val phone = settings?.phone?.takeIf { it.isNotBlank() } ?: "غير متوفر"
        
        // System Current Date & Time لحظة التصدير
        val dateFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
        val dateStr = dateFormat.format(Date())

        var y = 60f

        paint.color = Color.rgb(30, 58, 138) // Corporate Navy
        paint.textSize = 24f
        paint.isFakeBoldText = true
        canvas.drawText("⚡ $genName ⚡", 180f, y, paint)

        y += 35f
        paint.textSize = 14f
        paint.color = Color.rgb(15, 23, 42)
        paint.isFakeBoldText = false
        canvas.drawText("صاحب المولدة: $ownerName | هاتف: $phone", 140f, y, paint)

        y += 25f
        paint.textSize = 12f
        paint.color = Color.GRAY
        canvas.drawText("تاريخ وساعة التسديد الفعلية: $dateStr", 170f, y, paint)

        y += 35f
        paint.color = Color.BLACK
        paint.textSize = 14f
        canvas.drawLine(40f, y, 555f, y, paint)

        y += 30f
        canvas.drawText("رقم الفاتورة: ${bill.billCode}", 50f, y, paint)
        canvas.drawText("اسم المشترك: ${bill.subscriberName}", 300f, y, paint)

        y += 30f
        canvas.drawText("رقم المشترك: ${bill.subscriberCode}", 50f, y, paint)
        canvas.drawText("الشهر والسنة: ${bill.month} / ${bill.year}", 300f, y, paint)

        y += 30f
        canvas.drawText("عدد الأمبيرات: ${bill.amperes} أمبير", 50f, y, paint)
        canvas.drawText("سعر الأمبير: ${formatCurrency(bill.pricePerAmpere)}", 300f, y, paint)

        y += 35f
        canvas.drawLine(40f, y, 555f, y, paint)

        y += 30f
        paint.textSize = 16f
        paint.isFakeBoldText = true
        canvas.drawText("المبلغ الإجمالي: ${formatCurrency(bill.totalAmount)}", 50f, y, paint)

        y += 30f
        paint.color = Color.rgb(5, 150, 105) // Emerald Green
        canvas.drawText("المبلغ المدفوع: ${formatCurrency(bill.paidAmount)}", 50f, y, paint)

        y += 30f
        paint.color = Color.rgb(220, 38, 38) // Crimson Red
        canvas.drawText("المبلغ المتبقي: ${formatCurrency(bill.remainingAmount)}", 50f, y, paint)

        val address = settings?.address?.takeIf { it.isNotBlank() }
        if (address != null) {
            y += 24f
            paint.color = Color.rgb(15, 23, 42)
            paint.textSize = 12f
            paint.isFakeBoldText = true
            canvas.drawText("العنوان: $address", 50f, y, paint)
        }

        val mastercard = settings?.mastercardNumber?.takeIf { it.isNotBlank() }
        if (mastercard != null) {
            y += 26f
            paint.color = Color.rgb(2, 132, 199)
            paint.textSize = 12f
            paint.isFakeBoldText = true
            canvas.drawText("الدفع بالماستر كارد / الحساب البنكي: $mastercard", 50f, y, paint)
        }

        y += 30f
        paint.color = Color.BLACK
        canvas.drawLine(40f, y, 555f, y, paint)

        y += 30f
        try {
            val barcodeBitmap = BarcodeGenerator.createBarcodeBitmap(bill.billCode, 380, 90)
            canvas.drawBitmap(barcodeBitmap, 107f, y, null)
            y += 105f
        } catch (e: Exception) {
            e.printStackTrace()
        }

        pdfDocument.finishPage(page)

        val file = File(context.cacheDir, "فاتورة_${bill.billCode}.pdf")
        try {
            FileOutputStream(file).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الفاتورة كـ PDF"))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "حدث خطأ أثناء تصدير PDF", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Triggers standard Android system print dialog for PDF/Thermal printer print.
     * يستخدم System Current Date & Time لحظة فتح الطباعة.
     */
    fun printBillAndroid(context: Context, bill: Bill, settings: GeneratorSettings?) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val jobName = "طباعة_فاتورة_${bill.billCode}"

        printManager.print(jobName, object : PrintDocumentAdapter() {
            private var pdfDoc: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()

                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                pdfDoc = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
                val page = pdfDoc?.startPage(pageInfo)

                if (page != null) {
                    val canvas = page.canvas
                    val paint = Paint().apply {
                        color = Color.BLACK
                        textSize = 18f
                        isAntiAlias = true
                    }
                    val genName = settings?.generatorName ?: "مولدة الكهرباء الأهلية"
                    val ownerName = settings?.ownerName?.takeIf { it.isNotBlank() } ?: "غير محدد"
                    val phone = settings?.phone?.takeIf { it.isNotBlank() } ?: "غير متوفر"
                    
                    // System Current Date & Time
                    val dateFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
                    val dateStr = dateFormat.format(Date())

                    var y = 60f
                    canvas.drawText("⚡ $genName ⚡", 180f, y, paint)
                    y += 35f
                    canvas.drawText("صاحب المولدة: $ownerName | هاتف: $phone", 120f, y, paint)
                    y += 30f
                    canvas.drawText("تاريخ وساعة التسديد: $dateStr", 160f, y, paint)
                    y += 30f
                    canvas.drawText("إيصال فاتورة رقم: ${bill.billCode}", 50f, y, paint)
                    y += 30f
                    canvas.drawText("المشترك: ${bill.subscriberName} (${bill.subscriberCode})", 50f, y, paint)
                    y += 30f
                    canvas.drawText("الفترة: شهر ${bill.month} / ${bill.year} | الأمبيرات: ${bill.amperes}", 50f, y, paint)
                    y += 30f
                    canvas.drawText("المبلغ الإجمالي: ${formatCurrency(bill.totalAmount)}", 50f, y, paint)
                    y += 30f
                    canvas.drawText("المبلغ المدفوع: ${formatCurrency(bill.paidAmount)}", 50f, y, paint)
                    y += 30f
                    canvas.drawText("المتبقي: ${formatCurrency(bill.remainingAmount)}", 50f, y, paint)
                    
                    val address = settings?.address?.takeIf { it.isNotBlank() }
                    if (address != null) {
                        y += 24f
                        paint.textSize = 12f
                        canvas.drawText("العنوان: $address", 50f, y, paint)
                        paint.textSize = 18f
                    }
                    
                    val mastercard = settings?.mastercardNumber?.takeIf { it.isNotBlank() }
                    if (mastercard != null) {
                        y += 30f
                        canvas.drawText("ماستر كارد / بنك: $mastercard", 50f, y, paint)
                    }
                    y += 40f

                    try {
                        val barcodeBitmap = BarcodeGenerator.createBarcodeBitmap(bill.billCode, 380, 90)
                        canvas.drawBitmap(barcodeBitmap, 107f, y, null)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    pdfDoc?.finishPage(page)
                }

                try {
                    FileOutputStream(destination?.fileDescriptor).use { out ->
                        pdfDoc?.writeTo(out)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    pdfDoc?.close()
                }
            }
        }, null)
    }

    /**
     * Print single-page account statement for a specific subscriber showing all monthly/yearly bills and total debts.
     */
    fun printSubscriberStatementAndroid(
        context: Context,
        subscriberName: String,
        subscriberCode: String,
        bills: List<Bill>,
        settings: GeneratorSettings?
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val jobName = "كشف_حساب_$subscriberName"

        printManager.print(jobName, object : PrintDocumentAdapter() {
            private var pdfDoc: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                pdfDoc = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
                val page = pdfDoc?.startPage(pageInfo)

                if (page != null) {
                    val canvas = page.canvas
                    val paint = Paint().apply {
                        color = Color.BLACK
                        textSize = 14f
                        isAntiAlias = true
                    }

                    val genName = settings?.generatorName ?: "مولدة الكهرباء الأهلية"
                    val ownerName = settings?.ownerName?.takeIf { it.isNotBlank() } ?: "غير محدد"
                    val phone = settings?.phone?.takeIf { it.isNotBlank() } ?: "غير متوفر"

                    var y = 50f
                    paint.textSize = 20f
                    paint.isFakeBoldText = true
                    paint.color = Color.rgb(30, 58, 138)
                    canvas.drawText("⚡ $genName ⚡", 180f, y, paint)

                    y += 30f
                    paint.textSize = 16f
                    paint.color = Color.BLACK
                    canvas.drawText("كشف حساب فواتير المشترك الشامل", 170f, y, paint)

                    y += 25f
                    paint.textSize = 12f
                    paint.isFakeBoldText = false
                    paint.color = Color.DKGRAY
                    canvas.drawText("صاحب المولدة: $ownerName | هاتف: $phone", 150f, y, paint)

                    y += 25f
                    canvas.drawLine(40f, y, 555f, y, paint)

                    y += 25f
                    paint.color = Color.BLACK
                    paint.textSize = 13f
                    paint.isFakeBoldText = true
                    canvas.drawText("اسم المشترك: $subscriberName", 50f, y, paint)
                    canvas.drawText("رمز المشترك: $subscriberCode", 350f, y, paint)

                    y += 25f
                    val totalBillsAmount = bills.sumOf { it.totalAmount }
                    val totalPaidAmount = bills.sumOf { it.paidAmount }
                    val totalRemainingDebt = bills.sumOf { it.remainingAmount }

                    canvas.drawText("إجمالي الفواتير: ${formatCurrency(totalBillsAmount)}", 50f, y, paint)
                    canvas.drawText("المدفوع: ${formatCurrency(totalPaidAmount)}", 230f, y, paint)
                    paint.color = Color.rgb(220, 38, 38)
                    canvas.drawText("الديون المتبقية: ${formatCurrency(totalRemainingDebt)}", 390f, y, paint)

                    val address = settings?.address?.takeIf { it.isNotBlank() }
                    if (address != null) {
                        y += 20f
                        paint.color = Color.DKGRAY
                        paint.textSize = 10f
                        canvas.drawText("العنوان: $address", 50f, y, paint)
                    }

                    y += 20f
                    paint.color = Color.BLACK
                    canvas.drawLine(40f, y, 555f, y, paint)

                    // Table Header
                    y += 25f
                    paint.textSize = 11f
                    paint.isFakeBoldText = true
                    canvas.drawText("الشهر/السنة", 50f, y, paint)
                    canvas.drawText("الأمبيرات", 150f, y, paint)
                    canvas.drawText("المبلغ الإجمالي", 240f, y, paint)
                    canvas.drawText("المدفوع", 360f, y, paint)
                    canvas.drawText("المتبقي", 460f, y, paint)

                    y += 10f
                    canvas.drawLine(40f, y, 555f, y, paint)

                    // Table Rows
                    paint.isFakeBoldText = false
                    bills.forEach { bill ->
                        y += 22f
                        if (y < 780f) {
                            canvas.drawText("${bill.month} / ${bill.year}", 50f, y, paint)
                            canvas.drawText("${bill.amperes} أمبير", 150f, y, paint)
                            canvas.drawText(formatCurrency(bill.totalAmount), 240f, y, paint)
                            canvas.drawText(formatCurrency(bill.paidAmount), 360f, y, paint)
                            canvas.drawText(formatCurrency(bill.remainingAmount), 460f, y, paint)
                        }
                    }

                    y += 25f
                    canvas.drawLine(40f, y, 555f, y, paint)

                    y += 30f
                    paint.textSize = 10f
                    paint.color = Color.GRAY
                    canvas.drawText("تاريخ طباعة الكشف: ${SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")).format(Date())}", 50f, y, paint)

                    pdfDoc?.finishPage(page)
                }

                try {
                    FileOutputStream(destination?.fileDescriptor).use { out ->
                        pdfDoc?.writeTo(out)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    pdfDoc?.close()
                }
            }
        }, null)
    }

    /**
     * Share subscriber account statement as formatted WhatsApp text.
     */
    fun shareSubscriberStatementWhatsApp(
        context: Context,
        subscriberName: String,
        subscriberCode: String,
        bills: List<Bill>,
        settings: GeneratorSettings?
    ) {
        val genName = settings?.generatorName ?: "مولدة الكهرباء الأهلية"
        val totalBillsAmount = bills.sumOf { it.totalAmount }
        val totalPaidAmount = bills.sumOf { it.paidAmount }
        val totalRemainingDebt = bills.sumOf { it.remainingAmount }

        val billsListText = bills.joinToString("\n") { b ->
            "▪️ *شهر ${b.month}/${b.year}*: إجمالي: ${formatCurrency(b.totalAmount)} | مدفوع: ${formatCurrency(b.paidAmount)} | *متبقي: ${formatCurrency(b.remainingAmount)}*"
        }
        val address = settings?.address?.takeIf { it.isNotBlank() }

        val text = """
            📋 *كشف حساب فواتير المشترك الشامل - $genName* 📋
            ------------------------------------
            👤 *المشترك:* $subscriberName ($subscriberCode)
            ------------------------------------
            💵 *إجمالي قيمة الفواتير:* ${formatCurrency(totalBillsAmount)}
            ✅ *إجمالي المبالغ المدفوعة:* ${formatCurrency(totalPaidAmount)}
            🔴 *إجمالي الديون المتبقية:* ${formatCurrency(totalRemainingDebt)}
            ------------------------------------
            ${if (address != null) "📍 *العنوان:* $address\n------------------------------------" else ""}📊 *تفاصيل الفواتير الشهرية:*
            $billsListText
            ------------------------------------
            تاريخ وساعة الكشف: ${SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")).format(Date())}
            شكراً لالتزامكم بالتسديد.
        """.trimIndent()

        shareTextWhatsApp(context, text)
    }
}
