package com.example.generator.data.dao

import androidx.room.*
import com.example.generator.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GeneratorDao {

    // --- SUBSCRIBERS ---
    @Query("SELECT * FROM subscribers ORDER BY id DESC")
    fun getAllSubscribersFlow(): Flow<List<Subscriber>>

    @Query("SELECT * FROM subscribers WHERE id = :id")
    suspend fun getSubscriberById(id: Long): Subscriber?

    @Query("SELECT * FROM subscribers WHERE subscriberCode = :code LIMIT 1")
    suspend fun getSubscriberByCode(code: String): Subscriber?

    @Query("SELECT * FROM subscribers WHERE isActive = 1 ORDER BY id DESC")
    suspend fun getActiveSubscribers(): List<Subscriber>

    @Query("""
        SELECT * FROM subscribers 
        WHERE name LIKE '%' || :query || '%' 
           OR subscriberCode LIKE '%' || :query || '%' 
           OR phone LIKE '%' || :query || '%'
           OR circuitBreakerNumber LIKE '%' || :query || '%'
        ORDER BY id DESC
    """)
    fun searchSubscribersFlow(query: String): Flow<List<Subscriber>>

    @Query("UPDATE subscribers SET defaultPricePerAmpere = :newPrice")
    suspend fun updateAllSubscribersDefaultPrice(newPrice: Double)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscriber(subscriber: Subscriber): Long

    @Update
    suspend fun updateSubscriber(subscriber: Subscriber)

    @Delete
    suspend fun deleteSubscriber(subscriber: Subscriber)

    @Query("DELETE FROM subscribers WHERE id = :id")
    suspend fun deleteSubscriberById(id: Long)

    @Query("SELECT COUNT(*) FROM subscribers")
    fun getSubscribersCountFlow(): Flow<Int>

    @Query("UPDATE subscribers SET defaultPricePerAmpere = :pricePerAmpere, fixedFee = :fixedFee WHERE groupName = :groupName")
    suspend fun updateSubscribersFeesForGroup(groupName: String, pricePerAmpere: Double, fixedFee: Double)

    @Query("UPDATE subscribers SET groupName = :newGroupName WHERE groupName = :oldGroupName")
    suspend fun updateSubscriberGroupName(oldGroupName: String, newGroupName: String)

    // --- SUBSCRIBER GROUPS / PHASES ---
    @Query("SELECT * FROM subscriber_groups ORDER BY id ASC")
    fun getAllSubscriberGroupsFlow(): Flow<List<SubscriberGroup>>

    @Query("SELECT * FROM subscriber_groups WHERE id = :id LIMIT 1")
    suspend fun getGroupById(id: Long): SubscriberGroup?

    @Query("SELECT * FROM subscriber_groups WHERE groupName = :groupName LIMIT 1")
    suspend fun getGroupByName(groupName: String): SubscriberGroup?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscriberGroup(group: SubscriberGroup): Long

    @Update
    suspend fun updateSubscriberGroup(group: SubscriberGroup)

    @Delete
    suspend fun deleteSubscriberGroup(group: SubscriberGroup)

    @Query("DELETE FROM subscriber_groups WHERE id = :id")
    suspend fun deleteSubscriberGroupById(id: Long)

    @Query("SELECT * FROM subscriber_groups")
    suspend fun getAllSubscriberGroupsDirect(): List<SubscriberGroup>

    @Query("DELETE FROM subscriber_groups")
    suspend fun deleteAllSubscriberGroups()

    // --- BILLS ---
    @Query("SELECT * FROM bills ORDER BY id DESC")
    fun getAllBillsFlow(): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE id = :id")
    suspend fun getBillById(id: Long): Bill?

    @Query("SELECT * FROM bills WHERE subscriberId = :subscriberId ORDER BY year DESC, month DESC")
    fun getBillsForSubscriberFlow(subscriberId: Long): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE subscriberId = :subscriberId ORDER BY year DESC, month DESC")
    suspend fun getBillsForSubscriber(subscriberId: Long): List<Bill>

    @Query("SELECT * FROM bills WHERE subscriberId = :subscriberId AND month = :month AND year = :year LIMIT 1")
    suspend fun getBillBySubscriberMonthYear(subscriberId: Long, month: Int, year: Int): Bill?

    @Query("SELECT * FROM bills WHERE remainingAmount > 0 ORDER BY remainingAmount DESC")
    fun getUnpaidBillsFlow(): Flow<List<Bill>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: Bill): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBillsBatch(bills: List<Bill>): List<Long>

    @Update
    suspend fun updateBill(bill: Bill)

    @Query("DELETE FROM bills WHERE id = :id")
    suspend fun deleteBillById(id: Long)

    // --- PAYMENTS ---
    @Query("SELECT * FROM payments ORDER BY paymentDate DESC")
    fun getAllPaymentsFlow(): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE id = :id LIMIT 1")
    suspend fun getPaymentById(id: Long): Payment?

    @Query("SELECT * FROM payments WHERE billId = :billId ORDER BY paymentDate DESC")
    fun getPaymentsForBillFlow(billId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE billId = :billId")
    suspend fun getPaymentsForBillDirect(billId: Long): List<Payment>

    @Query("SELECT * FROM payments WHERE subscriberId = :subscriberId ORDER BY paymentDate DESC")
    fun getPaymentsForSubscriberFlow(subscriberId: Long): Flow<List<Payment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment): Long

    @Query("DELETE FROM payments WHERE id = :id")
    suspend fun deletePaymentById(id: Long)

    @Query("DELETE FROM payments WHERE billId = :billId")
    suspend fun deletePaymentsForBill(billId: Long)

    // --- EXPENSES ---
    @Query("SELECT * FROM expenses ORDER BY expenseDate DESC")
    fun getAllExpensesFlow(): Flow<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Update
    suspend fun updateExpense(expense: Expense)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteExpenseById(id: Long)

    // --- USERS ---
    @Query("SELECT * FROM users ORDER BY id ASC")
    fun getAllUsersFlow(): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE username = :username AND pinCode = :pin LIMIT 1")
    suspend fun loginUser(username: String, pin: String): UserAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserAccount): Long

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUserById(id: Long)

    // --- SETTINGS ---
    @Query("SELECT * FROM generator_settings WHERE id = 1 LIMIT 1")
    fun getSettingsFlow(): Flow<GeneratorSettings?>

    @Query("SELECT * FROM generator_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettings(): GeneratorSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: GeneratorSettings)

    // --- FINANCIAL SUMMARY STATS ---
    @Query("SELECT COALESCE(SUM(totalAmount), 0.0) FROM bills")
    fun getTotalDueAmountFlow(): Flow<Double>

    @Query("SELECT COALESCE(SUM(paidAmount), 0.0) FROM bills")
    fun getTotalCollectedAmountFlow(): Flow<Double>

    @Query("SELECT COALESCE(SUM(remainingAmount), 0.0) FROM bills")
    fun getTotalDebtsAmountFlow(): Flow<Double>

    @Query("SELECT COALESCE(SUM(amount), 0.0) FROM expenses")
    fun getTotalExpensesAmountFlow(): Flow<Double>

    // Synchronous snapshot fetchers for backup/restore
    @Query("SELECT * FROM subscribers")
    suspend fun getAllSubscribersDirect(): List<Subscriber>

    @Query("SELECT * FROM bills")
    suspend fun getAllBillsDirect(): List<Bill>

    @Query("SELECT * FROM payments")
    suspend fun getAllPaymentsDirect(): List<Payment>

    @Query("SELECT * FROM expenses")
    suspend fun getAllExpensesDirect(): List<Expense>

    @Query("SELECT * FROM users")
    suspend fun getAllUsersDirect(): List<UserAccount>

    @Query("DELETE FROM subscribers")
    suspend fun deleteAllSubscribers()

    @Query("DELETE FROM bills")
    suspend fun deleteAllBills()

    @Query("DELETE FROM payments")
    suspend fun deleteAllPayments()

    @Query("DELETE FROM expenses")
    suspend fun deleteAllExpenses()

    @Query("DELETE FROM users")
    suspend fun deleteAllUsers()
}
