package com.example.generator.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserAccount(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val name: String,
    val pinCode: String,
    val role: String, // ADMIN (مدير), COLLECTOR (جابي)
    val canDelete: Boolean = false,
    val canViewFinancials: Boolean = false,
    val isActive: Boolean = true,
    val email: String? = null
)
