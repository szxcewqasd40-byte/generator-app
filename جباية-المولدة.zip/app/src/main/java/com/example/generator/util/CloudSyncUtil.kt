package com.example.generator.util

import com.example.generator.data.entity.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object CloudSyncUtil {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    /**
     * Uploads full database payload to JSONBlob cloud service.
     * Returns unique Sync Code ID or null if failed.
     */
    suspend fun uploadToCloud(
        subscribers: List<Subscriber>,
        subscriberGroups: List<SubscriberGroup>,
        bills: List<Bill>,
        payments: List<Payment>,
        expenses: List<Expense>,
        users: List<UserAccount>,
        settings: GeneratorSettings?
    ): String? = withContext(Dispatchers.IO) {
        try {
            val jsonContent = ExcelExporterImporter.buildJsonPayload(
                subscribers = subscribers,
                subscriberGroups = subscriberGroups,
                bills = bills,
                payments = payments,
                expenses = expenses,
                users = users,
                settings = settings
            )

            val request = Request.Builder()
                .url("https://jsonblob.com/api/jsonBlob")
                .post(jsonContent.toRequestBody(JSON_MEDIA_TYPE))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val locationHeader = response.header("Location")
                if (!locationHeader.isNullOrEmpty()) {
                    // Location header looks like: https://jsonblob.com/api/jsonBlob/1234567890
                    val blobId = locationHeader.substringAfterLast("/")
                    return@withContext blobId
                }
            }
            null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Downloads JSON backup payload from cloud using the Sync Code.
     * Returns BackupDataBundle or null if failed.
     */
    suspend fun downloadFromCloud(syncCode: String): BackupDataBundle? = withContext(Dispatchers.IO) {
        try {
            val cleanCode = syncCode.trim()
            if (cleanCode.isBlank()) return@withContext null
            val url = if (cleanCode.startsWith("http")) cleanCode else "https://jsonblob.com/api/jsonBlob/$cleanCode"

            val request = Request.Builder()
                .url(url)
                .get()
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val jsonContent = response.body?.string()
                if (!jsonContent.isNullOrEmpty()) {
                    return@withContext ExcelExporterImporter.parseJsonBackup(jsonContent)
                }
            }
            null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
