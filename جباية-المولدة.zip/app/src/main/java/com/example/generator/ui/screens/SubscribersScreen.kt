package com.example.generator.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.Subscriber
import com.example.generator.data.entity.SubscriberGroup
import com.example.generator.ui.components.GlassCard
import com.example.generator.ui.components.Glossy3DIcon
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.components.PosPrintDialog
import com.example.generator.ui.components.PosPrintTarget
import com.example.generator.ui.components.SubscriberAnnualHistoryDialog
import com.example.generator.ui.components.SubscriberPrintOptionsDialog
import com.example.generator.ui.components.SubscriberQuickPaymentDialog
import com.example.generator.ui.components.SubscriberStatusCard
import com.example.generator.ui.components.SubscriberTableHeader
import com.example.generator.ui.components.SubscriberTableRow
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.PrintHelper
import com.example.generator.util.VoiceIconButton
import com.example.generator.util.VoiceSearchTextField
import com.example.ui.theme.*
import java.util.Calendar
import java.util.Locale

enum class PaymentFilter {
    ALL, PAID, PARTIAL, UNPAID
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscribersScreen(viewModel: GeneratorViewModel) {
    val context = LocalContext.current
    val searchQuery by viewModel.searchQuery.collectAsState()
    val subscribers by viewModel.subscribers.collectAsState()
    val subscriberGroups by viewModel.subscriberGroups.collectAsState()
    val bills by viewModel.bills.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var selectedFilter by remember { mutableStateOf(PaymentFilter.ALL) }
    var selectedGroupFilter by remember { mutableStateOf<String?>(null) } // null = All Groups

    val calendar = Calendar.getInstance()
    val currentMonth = calendar.get(Calendar.MONTH) + 1
    val currentYear = calendar.get(Calendar.YEAR)

    var selectedMonth by remember { mutableIntStateOf(currentMonth) }
    var selectedYear by remember { mutableIntStateOf(currentYear) }
    var monthMenuExpanded by remember { mutableStateOf(false) }
    var yearMenuExpanded by remember { mutableStateOf(false) }
    var posPrintTarget by remember { mutableStateOf<PosPrintTarget?>(null) }
    var selectedSubscriberForPrint by remember { mutableStateOf<Subscriber?>(null) }

    val monthsList = remember {
        listOf(
            0 to "جميع الأشهر",
            1 to "شهر 1 (كانون الثاني / يناير)",
            2 to "شهر 2 (شباط / فبراير)",
            3 to "شهر 3 (آذار / مارس)",
            4 to "شهر 4 (نيسان / أبريل)",
            5 to "شهر 5 (أيار / مايو)",
            6 to "شهر 6 (حزيران / يونيو)",
            7 to "شهر 7 (تموز / يوليو)",
            8 to "شهر 8 (آب / أغسطس)",
            9 to "شهر 9 (أيلول / سبتمبر)",
            10 to "شهر 10 (تشرين الأول / أكتوبر)",
            11 to "شهر 11 (تشرين الثاني / نوفمبر)",
            12 to "شهر 12 (كانون الأول / ديسمبر)"
        )
    }

    // Dynamic Year Range: Fully open and extensible based on system current year and existing data (no fixed 2031 limit)
    val yearsList = remember(currentYear, selectedYear, bills) {
        val minYear = (bills.map { it.year } + listOf(2024, currentYear)).minOrNull() ?: 2024
        val maxYear = maxOf(currentYear + 15, selectedYear + 5)
        (minYear..maxYear).toList()
    }

    val activeBills = remember(bills, selectedMonth, selectedYear) {
        if (selectedMonth == 0) {
            bills.filter { it.year == selectedYear }
        } else {
            bills.filter { it.month == selectedMonth && it.year == selectedYear }
        }
    }

    var showAddSubscriberDialog by remember { mutableStateOf(false) }
    var subscriberToEdit by remember { mutableStateOf<Subscriber?>(null) }
    var subscriberDetails by remember { mutableStateOf<Subscriber?>(null) }
    var subscriberAnnualHistory by remember { mutableStateOf<Subscriber?>(null) }
    var subscriberToDelete by remember { mutableStateOf<Subscriber?>(null) }

    // Group Management Dialogs State
    var showManageGroupsDialog by remember { mutableStateOf(false) }
    var showAddGroupDialog by remember { mutableStateOf(false) }
    var groupToEdit by remember { mutableStateOf<SubscriberGroup?>(null) }

    // Quick Payment dialog state
    var subscriberToPay by remember { mutableStateOf<Subscriber?>(null) }

    // Compute stats for summary banner dynamically from active bills
    val subscriberStatusMap = remember(subscribers, activeBills) {
        subscribers.associateWith { sub ->
            val subBills = activeBills.filter { it.subscriberId == sub.id }
            val totalRemaining = subBills.sumOf { it.remainingAmount }
            val totalPaid = subBills.sumOf { it.paidAmount }

            when {
                subBills.isEmpty() -> PaymentFilter.ALL
                totalRemaining <= 0.0 -> PaymentFilter.PAID
                totalPaid > 0.0 -> PaymentFilter.PARTIAL
                else -> PaymentFilter.UNPAID
            }
        }
    }

    val countPaid = subscriberStatusMap.values.count { it == PaymentFilter.PAID }
    val countPartial = subscriberStatusMap.values.count { it == PaymentFilter.PARTIAL }
    val countUnpaid = subscriberStatusMap.values.count { it == PaymentFilter.UNPAID }

    val filteredSubscribers = remember(subscribers, selectedFilter, selectedGroupFilter, subscriberStatusMap) {
        subscribers.filter { sub ->
            val matchesPayment = if (selectedFilter == PaymentFilter.ALL) true else subscriberStatusMap[sub] == selectedFilter
            val matchesGroup = if (selectedGroupFilter.isNullOrBlank()) true else sub.groupName == selectedGroupFilter
            matchesPayment && matchesGroup
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Glossy3DIcon(
                            imageRes = R.drawable.icon_3d_users_1787310351541,
                            contentDescription = null,
                            size = 36.dp,
                            glowColor = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "إدارة المشتركين والتحصيل (${subscribers.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddSubscriberDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مشترك", modifier = Modifier.size(26.dp))
            }
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        MidnightCyberBackground {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Month & Year Selector Row - Compact
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1.5f)) {
                    OutlinedButton(
                        onClick = { monthMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = monthsList.firstOrNull { it.first == selectedMonth }?.second ?: "شهر $selectedMonth",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                    DropdownMenu(
                        expanded = monthMenuExpanded,
                        onDismissRequest = { monthMenuExpanded = false }
                    ) {
                        monthsList.forEach { (m, name) ->
                            DropdownMenuItem(
                                text = { Text(name, fontWeight = if (m == selectedMonth) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedMonth = m
                                    monthMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { yearMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "$selectedYear", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(
                        expanded = yearMenuExpanded,
                        onDismissRequest = { yearMenuExpanded = false }
                    ) {
                        yearsList.forEach { y ->
                            DropdownMenuItem(
                                text = { Text("$y", fontWeight = if (y == selectedYear) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedYear = y
                                    yearMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Voice Search Field - Compact
            VoiceSearchTextField(
                query = searchQuery,
                onQueryChange = { viewModel.updateSearchQuery(it) },
                placeholderText = "بحث صوتي أو كتابي باسم المشترك، الهاتف...",
                prompt = "تحدث الآن باسم المشترك للبحث...",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 2.dp)
            )

            // Payment Filter Chips - Compact
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 1.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedFilter == PaymentFilter.ALL,
                        onClick = { selectedFilter = PaymentFilter.ALL },
                        label = { Text("الكل (${subscribers.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == PaymentFilter.PAID,
                        onClick = { selectedFilter = PaymentFilter.PAID },
                        label = { Text("🟢 مدفوع ($countPaid)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(13.dp)) }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == PaymentFilter.PARTIAL,
                        onClick = { selectedFilter = PaymentFilter.PARTIAL },
                        label = { Text("🟡 دين ($countPartial)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Pending, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(13.dp)) }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == PaymentFilter.UNPAID,
                        onClick = { selectedFilter = PaymentFilter.UNPAID },
                        label = { Text("🔴 لم يدفع ($countUnpaid)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Cancel, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(13.dp)) }
                    )
                }
            }

            // Group / Phase Filter Chips - Compact
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    FilterChip(
                        selected = selectedGroupFilter == null,
                        onClick = { selectedGroupFilter = null },
                        label = { Text("⚡ كل الفيزات", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(13.dp)) }
                    )
                }
                items(subscriberGroups) { group ->
                    val groupCount = subscribers.count { it.groupName == group.groupName }
                    FilterChip(
                        selected = selectedGroupFilter == group.groupName,
                        onClick = { selectedGroupFilter = group.groupName },
                        label = { Text("${group.groupName} ($groupCount)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp)) }
                    )
                }
                item {
                    AssistChip(
                        onClick = { showManageGroupsDialog = true },
                        label = { Text("المجموعات ⚙️", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(13.dp)) }
                    )
                }
            }

            // Phase Specific Amperage Load & Collection Summary Card - Compact
            val activeSubscribersInFilter = filteredSubscribers.filter { it.isActive }
            val phaseAmperes = activeSubscribersInFilter.sumOf { it.amperes }
            val phaseSubIds = filteredSubscribers.map { it.id }.toSet()
            val phaseRemainingDebt = bills.filter { it.subscriberId in phaseSubIds }.sumOf { it.remainingAmount }

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                shape = RoundedCornerShape(14.dp),
                borderColor = ElectricCyan.copy(alpha = 0.4f),
                backgroundColor = Color(0xFF0F1B3E).copy(alpha = 0.75f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Glossy3DIcon(
                                imageRes = R.drawable.icon_3d_energy_1787310378195,
                                contentDescription = null,
                                size = 26.dp,
                                glowColor = ElectricCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = selectedGroupFilter ?: "إجمالي كافة الفيزات",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextWhitePrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "حمل: ${String.format(Locale.US, "%.1f", phaseAmperes)} أمبير • المشتركين: ${filteredSubscribers.size}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextCyanSecondary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "المستحق للجباية",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextMuted
                        )
                        Text(
                            text = PrintHelper.formatCurrency(phaseRemainingDebt),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (phaseRemainingDebt > 0) Color(0xFFF87171) else Color(0xFF4ADE80)
                        )
                    }
                }
            }

            if (filteredSubscribers.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.GroupOff,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا يوجد مشتركين مطابقين لهذا الفلتر",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            } else {
                // Table Header with exact required columns: (التسلسل | اسم المشترك | رقم الجوزة | الفيز | عدد الأمبيرات | حالة الدفع)
                SubscriberTableHeader()

                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredSubscribers.size, key = { filteredSubscribers[it].id }) { index ->
                        val subscriber = filteredSubscribers[index]
                        val subBills = activeBills.filter { it.subscriberId == subscriber.id }

                        SubscriberTableRow(
                            index = index + 1,
                            subscriber = subscriber,
                            subBills = subBills,
                            onClick = { subscriberDetails = subscriber },
                            onQuickPay = { subscriberToPay = subscriber },
                            onRevertPay = {
                                viewModel.revertSubscriberAllPayments(
                                    subscriberId = subscriber.id,
                                    targetMonth = selectedMonth,
                                    targetYear = selectedYear
                                )
                            },
                            onPrintOptions = {
                                selectedSubscriberForPrint = subscriber
                            },
                            onAnnualHistory = {
                                subscriberAnnualHistory = subscriber
                            }
                        )
                    }
                }
            }
        }
    }
}

    // Interactive Quick Payment Dialog
    if (subscriberToPay != null) {
        SubscriberQuickPaymentDialog(
            subscriber = subscriberToPay!!,
            bills = bills,
            settings = settings,
            viewModel = viewModel,
            onDismiss = { subscriberToPay = null },
            onPrintPos = { bill ->
                posPrintTarget = PosPrintTarget.SingleBill(bill)
            },
            targetMonth = selectedMonth,
            targetYear = selectedYear
        )
    }

    // Thermal POS Print Dialog
    if (posPrintTarget != null) {
        PosPrintDialog(
            target = posPrintTarget!!,
            settings = settings,
            onDismiss = { posPrintTarget = null }
        )
    }

    // Subscriber Print & Share Options Dialog
    if (selectedSubscriberForPrint != null) {
        SubscriberPrintOptionsDialog(
            subscriber = selectedSubscriberForPrint!!,
            subBills = activeBills.filter { it.subscriberId == selectedSubscriberForPrint!!.id },
            settings = settings,
            targetMonth = selectedMonth,
            targetYear = selectedYear,
            onDismiss = { selectedSubscriberForPrint = null },
            onThermalPosPrint = { bill ->
                posPrintTarget = PosPrintTarget.SingleBill(bill)
            }
        )
    }

    if (showManageGroupsDialog) {
        ManageGroupsDialog(
            groups = subscriberGroups,
            subscribers = subscribers,
            onDismiss = { showManageGroupsDialog = false },
            onAddGroup = {
                groupToEdit = null
                showAddGroupDialog = true
            },
            onEditGroup = { group ->
                groupToEdit = group
                showAddGroupDialog = true
            },
            onDeleteGroup = { groupId ->
                viewModel.deleteSubscriberGroup(groupId)
            },
            onApplyPricingToSubscribers = { groupName, price, fee ->
                viewModel.applyGroupPricingToSubscribers(groupName, price, fee)
            }
        )
    }

    if (showAddGroupDialog) {
        AddEditGroupDialog(
            group = groupToEdit,
            onDismiss = { showAddGroupDialog = false },
            onConfirm = { groupName, price, fee, notes, applyToExisting ->
                if (groupToEdit == null) {
                    viewModel.addSubscriberGroup(groupName, price, fee, notes, applyToExisting)
                } else {
                    val updated = groupToEdit!!.copy(
                        groupName = groupName,
                        pricePerAmpere = price,
                        fixedFee = fee,
                        notes = notes
                    )
                    viewModel.updateSubscriberGroup(updated, oldGroupName = groupToEdit!!.groupName, applyToSubscribers = applyToExisting)
                }
                showAddGroupDialog = false
            }
        )
    }

    if (showAddSubscriberDialog) {
        SubscriberAddEditDialog(
            subscriber = null,
            subscriberGroups = subscriberGroups,
            defaultGlobalPrice = settings?.defaultPricePerAmpere ?: 10000.0,
            onDismiss = { showAddSubscriberDialog = false },
            onConfirm = { name, phone, amperes, price, groupName, fixedFee, circuitBreakerNumber, notes ->
                viewModel.addSubscriber(name, phone, amperes, price, groupName, fixedFee, circuitBreakerNumber, notes)
                showAddSubscriberDialog = false
            }
        )
    }

    if (subscriberToEdit != null) {
        SubscriberAddEditDialog(
            subscriber = subscriberToEdit,
            subscriberGroups = subscriberGroups,
            defaultGlobalPrice = settings?.defaultPricePerAmpere ?: 10000.0,
            onDismiss = { subscriberToEdit = null },
            onConfirm = { name, phone, amperes, price, groupName, fixedFee, circuitBreakerNumber, notes ->
                subscriberToEdit?.let { current ->
                    val updated = current.copy(
                        name = name,
                        phone = phone,
                        amperes = amperes,
                        defaultPricePerAmpere = price,
                        groupName = groupName,
                        fixedFee = fixedFee,
                        circuitBreakerNumber = circuitBreakerNumber,
                        notes = notes
                    )
                    viewModel.updateSubscriber(updated)
                }
                subscriberToEdit = null
            }
        )
    }

    if (subscriberToDelete != null) {
        AlertDialog(
            onDismissRequest = { subscriberToDelete = null },
            title = { Text("حذف المشترك") },
            text = {
                Text("هل أنت تأكد من حذف المشترك \"${subscriberToDelete?.name}\"؟ سيؤدي ذلك لحذف الفواتير والسجلات الخاصة به.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        subscriberToDelete?.id?.let { viewModel.deleteSubscriber(it) }
                        subscriberToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { subscriberToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (subscriberDetails != null) {
        SubscriberDetailDialog(
            subscriber = subscriberDetails!!,
            bills = bills.filter { it.subscriberId == subscriberDetails!!.id },
            settings = settings,
            onDismiss = { subscriberDetails = null },
            onEdit = {
                val sub = subscriberDetails
                subscriberDetails = null
                subscriberToEdit = sub
            },
            onDelete = {
                val sub = subscriberDetails
                subscriberDetails = null
                subscriberToDelete = sub
            },
            onOpenAnnualHistory = {
                val sub = subscriberDetails
                subscriberDetails = null
                subscriberAnnualHistory = sub
            }
        )
    }

    if (subscriberAnnualHistory != null) {
        SubscriberAnnualHistoryDialog(
            subscriber = subscriberAnnualHistory!!,
            allBills = bills.filter { it.subscriberId == subscriberAnnualHistory!!.id },
            settings = settings,
            initialYear = selectedYear,
            onDismiss = { subscriberAnnualHistory = null },
            onQuickPayMonth = { month, year ->
                val sub = subscriberAnnualHistory
                subscriberAnnualHistory = null
                subscriberToPay = sub
                selectedMonth = month
                selectedYear = year
            }
        )
    }
}

@Composable
fun SubscriberCard(
    subscriber: Subscriber,
    totalDebt: Double,
    paymentStatus: PaymentFilter,
    subBills: List<Bill>,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onQuickPay: () -> Unit
) {
    val context = LocalContext.current

    val status = when (paymentStatus) {
        PaymentFilter.PAID -> com.example.generator.ui.components.SubscriberPaymentStatus.FULL_PAID
        PaymentFilter.PARTIAL -> com.example.generator.ui.components.SubscriberPaymentStatus.PARTIAL_PAID
        PaymentFilter.UNPAID -> com.example.generator.ui.components.SubscriberPaymentStatus.UNPAID
        else -> com.example.generator.ui.components.SubscriberPaymentStatus.NO_BILLS
    }

    val cardBg = status.containerColor
    val cardBorder = status.borderColor
    val badgeColor = status.contentColor
    val badgeBg = status.badgeBgColor
    val badgeIcon = status.icon
    val badgeText = when (paymentStatus) {
        PaymentFilter.PAID -> "🟢 دفع الاشتراك بالكامل (مستوفي)"
        PaymentFilter.PARTIAL -> "🟡 في ذمته دين متبقي: ${PrintHelper.formatCurrency(totalDebt)}"
        PaymentFilter.UNPAID -> "🔴 لم يدفع الاشتراك (${PrintHelper.formatCurrency(totalDebt)})"
        else -> "⚪ لا توجد فواتير صادرة بعد"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.2.dp, cardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = badgeBg,
                        contentColor = Color(0xFF000000)
                    ) {
                        Box(
                            modifier = Modifier.size(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = subscriber.subscriberCode.takeLast(3),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFF000000)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = subscriber.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF000000)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "هاتف: ${subscriber.phone.ifBlank { "غير محدد" }}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1F2937)
                            )
                        }
                    }
                }

                // Group/Phase Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeBg,
                    contentColor = Color(0xFF000000)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = subscriber.groupName,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF000000)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Payment Status Badge (GREEN / YELLOW / RED) with bold dark text
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = badgeBg.copy(alpha = 0.9f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(badgeIcon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = badgeText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF000000)
                    )
                }
            }

            Divider(modifier = Modifier.padding(vertical = 5.dp))

            // Ampere & Pricing details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "عدد الأمبيرات: ${subscriber.amperes} أمبير",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF000000)
                    )
                    val feeInfo = if (subscriber.fixedFee > 0) " (+ ${PrintHelper.formatCurrency(subscriber.fixedFee)} فيزة)" else ""
                    Text(
                        text = "تسعيرة الفيز: ${PrintHelper.formatCurrency(subscriber.defaultPricePerAmpere)} / أمبير$feeInfo",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1F2937)
                    )
                }

                if (totalDebt > 0) {
                    Button(
                        onClick = onQuickPay,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("تسديد جباية", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (subscriber.phone.isNotBlank()) {
                    Row {
                        IconButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${subscriber.phone}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "اتصال", tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun SubscriberAddEditDialog(
    subscriber: Subscriber?,
    subscriberGroups: List<SubscriberGroup>,
    defaultGlobalPrice: Double = 10000.0,
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String, amperes: Double, price: Double, groupName: String, fixedFee: Double, circuitBreakerNumber: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf(subscriber?.name ?: "") }
    var phone by remember { mutableStateOf(subscriber?.phone ?: "") }
    var amperesText by remember { mutableStateOf(subscriber?.amperes?.toString() ?: "") }
    var selectedGroup by remember { mutableStateOf(subscriber?.groupName ?: subscriberGroups.firstOrNull()?.groupName ?: "") }
    
    val currentGroupObj = subscriberGroups.find { it.groupName == selectedGroup }
    var priceText by remember { mutableStateOf(subscriber?.defaultPricePerAmpere?.toString() ?: (if ((currentGroupObj?.pricePerAmpere ?: 0.0) > 0) currentGroupObj?.pricePerAmpere?.toString() ?: "" else if (defaultGlobalPrice > 0) defaultGlobalPrice.toLong().toString() else "")) }
    var fixedFeeText by remember { mutableStateOf(subscriber?.fixedFee?.toString() ?: (if ((currentGroupObj?.fixedFee ?: 0.0) > 0) currentGroupObj?.fixedFee?.toString() ?: "" else "")) }
    var circuitBreakerNumber by remember { mutableStateOf(subscriber?.circuitBreakerNumber ?: "") }
    var notes by remember { mutableStateOf(subscriber?.notes ?: "") }

    // Focus management for streamlined auto-transitions
    val focusManager = LocalFocusManager.current
    val nameFocusRequester = remember { FocusRequester() }
    val phoneFocusRequester = remember { FocusRequester() }
    val ampsFocusRequester = remember { FocusRequester() }
    val breakerFocusRequester = remember { FocusRequester() }
    val notesFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (subscriber == null) {
            nameFocusRequester.requestFocus()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (subscriber == null) "إضافة مشترك جديد" else "تعديل بيانات المشترك") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // 1. الاسم الكامل (Name)
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("الاسم الكامل للمشترك") },
                    trailingIcon = {
                        VoiceIconButton(
                            onVoiceInput = { name = it },
                            prompt = "تحدث باسم المشترك..."
                        )
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { phoneFocusRequester.requestFocus() }
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(nameFocusRequester)
                )
                
                // 2. رقم الهاتف (Phone - with 11-digit auto jump to Amperes)
                OutlinedTextField(
                    value = phone,
                    onValueChange = { input ->
                        val digits = input.filter { it.isDigit() || it == '+' }
                        phone = digits
                        // Auto-transition to next field (Amperes) when Iraqi phone (11 digits e.g. 0770xxxxxxx) is completed
                        val pureDigits = digits.filter { it.isDigit() }
                        if (pureDigits.length == 11 || (pureDigits.startsWith("964") && pureDigits.length >= 13)) {
                            ampsFocusRequester.requestFocus()
                        }
                    },
                    label = { Text("رقم الهاتف (11 رقماً)") },
                    placeholder = { Text("07xxxxxxxxx") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { ampsFocusRequester.requestFocus() }
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(phoneFocusRequester)
                )

                // 3. عدد الأمبيرات وسعر الأمبير (Amperes & Price)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = amperesText,
                        onValueChange = { amperesText = it },
                        label = { Text("عدد الأمبيرات") },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { breakerFocusRequester.requestFocus() }
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(ampsFocusRequester)
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("سعر الأمبير (د.ع)") },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { breakerFocusRequester.requestFocus() }
                        ),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // 4. اسم الفيز / المجموعة (Phase Selection / Custom Phase Input)
                Text("اسم الفيز / المجموعة / الخط:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                
                if (subscriberGroups.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(subscriberGroups) { grp ->
                            FilterChip(
                                selected = selectedGroup == grp.groupName,
                                onClick = {
                                    selectedGroup = grp.groupName
                                    priceText = grp.pricePerAmpere.toString()
                                    fixedFeeText = grp.fixedFee.toString()
                                },
                                label = { Text(grp.groupName, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = selectedGroup,
                    onValueChange = { selectedGroup = it },
                    label = { Text("الفيز / اسم الخط أو الحي") },
                    placeholder = { Text("مثال: الخط الرئيسي، حي المعلمين، تجاري...") },
                    leadingIcon = {
                        Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // 5. رقم الجوزة (Circuit Breaker Number) ورسم الفيزة
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = circuitBreakerNumber,
                        onValueChange = { circuitBreakerNumber = it },
                        label = { Text("رقم الجوزة ⚡") },
                        placeholder = { Text("مثال: 12") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { notesFocusRequester.requestFocus() }
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(breakerFocusRequester)
                    )

                    OutlinedTextField(
                        value = fixedFeeText,
                        onValueChange = { fixedFeeText = it },
                        label = { Text("الفيزة الثابتة") },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { notesFocusRequester.requestFocus() }
                        ),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // 6. الملاحظات (Notes)
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("الملاحظات / العنوان") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { focusManager.clearFocus() }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(notesFocusRequester)
                )

                Text(
                    text = "💡 يُحسب إجمالي الفاتورة: (الأمبيرات × سعر الأمبير) + الفيزة الثابتة.",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amps = amperesText.toDoubleOrNull() ?: 5.0
                    val price = priceText.toDoubleOrNull() ?: 10000.0
                    val fee = fixedFeeText.toDoubleOrNull() ?: 0.0
                    onConfirm(name, phone, amps, price, selectedGroup, fee, circuitBreakerNumber, notes)
                }
            ) {
                Text(if (subscriber == null) "حفظ وإضافة" else "تحديث")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun ManageGroupsDialog(
    groups: List<SubscriberGroup>,
    subscribers: List<Subscriber>,
    onDismiss: () -> Unit,
    onAddGroup: () -> Unit,
    onEditGroup: (SubscriberGroup) -> Unit,
    onDeleteGroup: (Long) -> Unit,
    onApplyPricingToSubscribers: (groupName: String, price: Double, fee: Double) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("إدارة الفيزات ومجموعات المشتركين", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onAddGroup) {
                    Icon(Icons.Default.AddCircle, contentDescription = "إضافة فيز جديد", tint = MaterialTheme.colorScheme.primary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("يمكنك هنا إضافة أسعار وفيزات مستقلة لكل خط أو مجموعة مشتركون على حدى:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))

                if (groups.isEmpty()) {
                    Text("لا توجد مجموعات معرفة حالياً", fontSize = 12.sp, color = Color.Gray)
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.heightIn(max = 350.dp)
                    ) {
                        items(groups) { group ->
                            val subCount = subscribers.count { it.groupName == group.groupName }
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(group.groupName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Text(
                                                text = "$subCount مشترك",
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("• سعر الأمبير: ${PrintHelper.formatCurrency(group.pricePerAmpere)}", fontSize = 12.sp)
                                    Text("• رسم الفيزة الثابتة: ${PrintHelper.formatCurrency(group.fixedFee)}", fontSize = 12.sp)
                                    if (group.notes.isNotBlank()) {
                                        Text("• ملاحظات: ${group.notes}", fontSize = 11.sp, color = Color.Gray)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = { onApplyPricingToSubscribers(group.groupName, group.pricePerAmpere, group.fixedFee) }
                                        ) {
                                            Text("تطبيق السعر على مشتركيه", fontSize = 11.sp)
                                        }
                                        IconButton(onClick = { onEditGroup(group) }) {
                                            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                        }
                                        IconButton(onClick = { onDeleteGroup(group.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onAddGroup) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة فيز / مجموعة جديدة")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
fun AddEditGroupDialog(
    group: SubscriberGroup?,
    onDismiss: () -> Unit,
    onConfirm: (groupName: String, price: Double, fixedFee: Double, notes: String, applyToExisting: Boolean) -> Unit
) {
    var groupName by remember { mutableStateOf(group?.groupName ?: "") }
    var priceText by remember { mutableStateOf(group?.pricePerAmpere?.toString() ?: "") }
    var fixedFeeText by remember { mutableStateOf(group?.fixedFee?.toString() ?: "") }
    var notes by remember { mutableStateOf(group?.notes ?: "") }
    var applyToExisting by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (group == null) "إضافة فيز / مجموعة مشتركون جديدة" else "تعديل بيانات الفيز والمجموعة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = groupName,
                    onValueChange = { groupName = it },
                    label = { Text("اسم الفيز / المجموعة (مثال: فيز 1 الخط التجاري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("سعر الأمبير الخاص بالمجموعة (د.ع)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = fixedFeeText,
                    onValueChange = { fixedFeeText = it },
                    label = { Text("رسم الفيزة / الاشتراك الثابت للمجموعة (د.ع)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = applyToExisting,
                        onCheckedChange = { applyToExisting = it }
                    )
                    Text(
                        text = "تحديث تسعيرة وفيزة المشتركين الحاليين في هذه المجموعة فوراً",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = priceText.toDoubleOrNull() ?: 10000.0
                    val fee = fixedFeeText.toDoubleOrNull() ?: 0.0
                    onConfirm(groupName, price, fee, notes, applyToExisting)
                }
            ) {
                Text(if (group == null) "حفظ وإضافة" else "تحديث")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun SubscriberDetailDialog(
    subscriber: Subscriber,
    bills: List<Bill>,
    settings: com.example.generator.data.entity.GeneratorSettings?,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onOpenAnnualHistory: () -> Unit
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("كشف حساب وسجل المشترك: ${subscriber.name}") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(text = "رقم المشترك: ${subscriber.subscriberCode}", fontWeight = FontWeight.Bold)
                val breakerDisplay = if (subscriber.circuitBreakerNumber.isNotBlank()) subscriber.circuitBreakerNumber else "غير محدد"
                Text(
                    text = "⚡ رقم الجوزة / القاطع: $breakerDisplay",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB45309)
                )
                Text(text = "الهاتف: ${if (subscriber.phone.isNotBlank()) subscriber.phone else "غير متوفر"}")
                Text(text = "المجموعة/الفيز: ${subscriber.groupName}")
                val feeStr = if (subscriber.fixedFee > 0) " | الفيزة الثابتة: ${PrintHelper.formatCurrency(subscriber.fixedFee)}" else ""
                Text(text = "عدد الأمبيرات: ${subscriber.amperes} | سعر الأمبير: ${PrintHelper.formatCurrency(subscriber.defaultPricePerAmpere)}$feeStr")
                
                val totalRemaining = bills.sumOf { it.remainingAmount }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "إجمالي الديون المتبقية: ${PrintHelper.formatCurrency(totalRemaining)}",
                    fontWeight = FontWeight.Bold,
                    color = if (totalRemaining > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Button to open the 12-month Annual History Map
                FilledTonalButton(
                    onClick = onOpenAnnualHistory,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("عرض خريطة السجل السنوي (12 شهراً)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Buttons for Printing & Sharing Statement
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            PrintHelper.printSubscriberStatementAndroid(
                                context,
                                subscriber.name,
                                subscriber.subscriberCode,
                                bills,
                                settings
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("طباعة الكشف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            PrintHelper.shareSubscriberStatementWhatsApp(
                                context,
                                subscriber.name,
                                subscriber.subscriberCode,
                                bills,
                                settings
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مشاركة واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(text = "سجل الفواتير والديون الشهري والسنوي:", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                if (bills.isEmpty()) {
                    Text("لا توجد فواتير سابقة لهذا المشترك", fontSize = 12.sp, color = Color.Gray)
                } else {
                    bills.forEach { bill ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("شهر ${bill.month} / ${bill.year}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    val billFeeStr = if (bill.fixedFee > 0) " (فيزة: ${PrintHelper.formatCurrency(bill.fixedFee)})" else ""
                                    Text("الإجمالي: ${PrintHelper.formatCurrency(bill.totalAmount)}$billFeeStr", fontSize = 11.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("المدفوع: ${PrintHelper.formatCurrency(bill.paidAmount)}", fontSize = 11.sp, color = Color(0xFF16A34A))
                                    Text("المتبقي: ${PrintHelper.formatCurrency(bill.remainingAmount)}", fontSize = 11.sp, color = Color(0xFFDC2626))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = onEdit,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تعديل المشترك")
                }
                Button(onClick = onDismiss) {
                    Text("إغلاق")
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDelete,
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حذف")
            }
        }
    )
}
