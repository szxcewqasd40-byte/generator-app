package com.example.generator.util

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.generator.data.entity.*
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

object FullBackupPdfExporter {

    private fun formatCurrency(amount: Double): String {
        val formatter = NumberFormat.getInstance(Locale("ar"))
        return "${formatter.format(amount)} د.ع"
    }

    /**
     * دالة رسم النصوص العربية وRTL باستخدام StaticLayout و TextPaint لتفادي تقطع الحروف وانعكاس النصوص في Canvas PDF
     */
    fun drawRtlText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        width: Float,
        paint: Paint,
        alignment: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL,
        maxLines: Int = 1
    ) {
        if (text.isBlank() || width <= 0) return
        val textPaint = TextPaint(paint)
        
        canvas.save()
        canvas.translate(x, y)

        val layout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width.toInt().coerceAtLeast(10))
                .setAlignment(alignment)
                .setIncludePad(false)
                .setMaxLines(maxLines)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(
                text,
                textPaint,
                width.toInt().coerceAtLeast(10),
                alignment,
                1.0f,
                0.0f,
                false
            )
        }

        layout.draw(canvas)
        canvas.restore()
    }

    /**
     * Creates a multi-page comprehensive, beautifully styled PDF document containing all system data:
     * 1. Cover & Executive Summary (Totals, Revenue, Active Debts, Expenses, Net Profit).
     * 2. Full Subscribers Directory & Subscriptions (Group/Phase, Amperes, Breaker Number, Phone, Price).
     * 3. Comprehensive Billing History & Balances.
     * 4. Complete Receipts & Collection Logs (with collector names & timestamps).
     * 5. Detailed Expenses Ledger (categories, notes, amounts).
     * 6. User Accounts & Electrical Line / Phase Configuration.
     */
    fun generateFullBackupPdf(
        context: Context,
        subscribers: List<Subscriber>,
        subscriberGroups: List<SubscriberGroup>,
        bills: List<Bill>,
        payments: List<Payment>,
        expenses: List<Expense>,
        users: List<UserAccount>,
        settings: GeneratorSettings?
    ): File? {
        val pdfDocument = PdfDocument()
        val pageWidth = 595 // A4 standard width (points)
        val pageHeight = 842 // A4 standard height (points)
        var pageNumber = 1

        val dateFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
        val exportTimestamp = dateFormat.format(Date())

        val genName = settings?.generatorName?.ifBlank { "مولدة الكهرباء الأهلية" } ?: "مولدة الكهرباء الأهلية"
        val ownerName = settings?.ownerName?.ifBlank { "غير محدد" } ?: "غير محدد"
        val phone = settings?.phone?.ifBlank { "غير متوفر" } ?: "غير متوفر"
        val address = settings?.address?.takeIf { it.isNotBlank() }
        val mastercard = settings?.mastercardNumber?.ifBlank { "غير محدد" } ?: "غير محدد"

        // Financial Computations
        val totalSubscribers = subscribers.size
        val totalAmperes = subscribers.sumOf { it.amperes }
        val totalBilled = bills.sumOf { it.totalAmount }
        val totalCollected = payments.sumOf { it.amountPaid }
        val totalRemainingDebts = bills.sumOf { it.remainingAmount }
        val totalExpenses = expenses.sumOf { it.amount }
        val netBalance = totalCollected - totalExpenses

        // Common Paints
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 41, 59)
            textSize = 9.5f
        }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 10f
            isFakeBoldText = true
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 16f
            isFakeBoldText = true
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(71, 85, 105)
            textSize = 10f
        }
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1f
        }

        fun drawHeaderFooter(canvas: Canvas, currentPage: Int, sectionTitle: String) {
            // Header Top Bar
            bgPaint.color = Color.rgb(30, 58, 138) // Deep Blue
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 40f, bgPaint)

            headerPaint.color = Color.WHITE
            headerPaint.textSize = 12f
            headerPaint.isFakeBoldText = true
            drawRtlText(canvas, "⚡ $genName - تقرير النسخة الاحتياطية الشاملة للبيانات", 24f, 12f, 380f, headerPaint)

            headerPaint.textSize = 9f
            headerPaint.isFakeBoldText = false
            drawRtlText(canvas, exportTimestamp, (pageWidth - 170).toFloat(), 14f, 150f, headerPaint)

            // Section Subheader line
            if (sectionTitle.isNotEmpty()) {
                bgPaint.color = Color.rgb(241, 245, 249)
                canvas.drawRect(0f, 40f, pageWidth.toFloat(), 62f, bgPaint)
                subtitlePaint.color = Color.rgb(15, 23, 42)
                subtitlePaint.textSize = 11f
                subtitlePaint.isFakeBoldText = true
                drawRtlText(canvas, "📑 $sectionTitle", 24f, 44f, (pageWidth - 48).toFloat(), subtitlePaint)
            }

            // Footer Bottom Bar
            linePaint.color = Color.rgb(203, 213, 225)
            canvas.drawLine(24f, (pageHeight - 32).toFloat(), (pageWidth - 24).toFloat(), (pageHeight - 32).toFloat(), linePaint)
            
            textPaint.color = Color.rgb(100, 116, 139)
            textPaint.textSize = 9f
            val addressSuffix = if (address != null) " | العنوان: $address" else ""
            drawRtlText(canvas, "صاحب المولدة: $ownerName | هاتف: $phone$addressSuffix", 24f, (pageHeight - 24).toFloat(), 450f, textPaint)
            drawRtlText(canvas, "صفحة $currentPage", (pageWidth - 80).toFloat(), (pageHeight - 24).toFloat(), 60f, textPaint)
        }

        // ==========================================
        // PAGE 1: COVER & EXECUTIVE FINANCIAL SUMMARY
        // ==========================================
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        drawHeaderFooter(canvas, pageNumber, "ملخص الأداء والمؤشرات المالية والتشغيلية")

        var y = 80f

        // System Branding Box
        bgPaint.color = Color.rgb(238, 242, 255)
        canvas.drawRoundRect(24f, y, (pageWidth - 24).toFloat(), y + 84f, 12f, 12f, bgPaint)
        
        titlePaint.color = Color.rgb(30, 58, 138)
        titlePaint.textSize = 15f
        titlePaint.isFakeBoldText = true
        drawRtlText(canvas, "نظام إدارة المولدات الأهلية - السجل المحاسبي والتشغيلي المعتمد", 38f, y + 12f, 500f, titlePaint)
        
        subtitlePaint.color = Color.rgb(51, 65, 85)
        subtitlePaint.textSize = 9.5f
        drawRtlText(canvas, "• تاريخ التصدير: $exportTimestamp", 38f, y + 36f, 260f, subtitlePaint)
        drawRtlText(canvas, "• رقم الحساب البنكي / الماستر: $mastercard", 38f, y + 54f, 260f, subtitlePaint)
        drawRtlText(canvas, "• عدد الخطوط / الفيزات: ${subscriberGroups.size}", 310f, y + 36f, 240f, subtitlePaint)
        drawRtlText(canvas, "• إجمالي القدرة المشتركة: $totalAmperes أمبير", 310f, y + 54f, 240f, subtitlePaint)

        y += 98f

        // Financial KPIs Cards Grid (2x3)
        data class KpiBox(val title: String, val value: String, val bg: Int, val textColor: Int)
        val kpis = listOf(
            KpiBox("إجمالي عدد المشتركين", "$totalSubscribers مشترك", Color.rgb(238, 242, 255), Color.rgb(30, 58, 138)),
            KpiBox("مجموع الأمبيرات المسحوبة", "$totalAmperes أمبير", Color.rgb(240, 253, 244), Color.rgb(22, 101, 52)),
            KpiBox("إجمالي الفواتير الصادرة", formatCurrency(totalBilled), Color.rgb(254, 243, 199), Color.rgb(180, 83, 9)),
            KpiBox("المبالغ المقبوضة فعلياً", formatCurrency(totalCollected), Color.rgb(220, 252, 231), Color.rgb(21, 128, 61)),
            KpiBox("الديون المتبقية بذمة المشتركين", formatCurrency(totalRemainingDebts), Color.rgb(254, 226, 226), Color.rgb(185, 28, 28)),
            KpiBox("إجمالي المصروفات التشغيلية", formatCurrency(totalExpenses), Color.rgb(255, 237, 213), Color.rgb(194, 65, 12)),
            KpiBox("صافي الأرباح المحققة", formatCurrency(netBalance), if (netBalance >= 0) Color.rgb(209, 250, 229) else Color.rgb(254, 226, 226), if (netBalance >= 0) Color.rgb(4, 120, 87) else Color.rgb(185, 28, 28)),
            KpiBox("عدد سجلات الإيصالات", "${payments.size} إيصال تسديد", Color.rgb(243, 244, 246), Color.rgb(55, 65, 81))
        )

        val boxWidth = (pageWidth - 48 - 16) / 2f
        val boxHeight = 44f

        for (i in kpis.indices) {
            val kpi = kpis[i]
            val col = i % 2
            val row = i / 2
            val bx = 24f + col * (boxWidth + 16f)
            val by = y + row * (boxHeight + 10f)

            bgPaint.color = kpi.bg
            canvas.drawRoundRect(bx, by, bx + boxWidth, by + boxHeight, 8f, 8f, bgPaint)

            subtitlePaint.color = Color.rgb(71, 85, 105)
            subtitlePaint.textSize = 9f
            subtitlePaint.isFakeBoldText = false
            drawRtlText(canvas, kpi.title, bx + 12f, by + 8f, boxWidth - 24f, subtitlePaint)

            titlePaint.color = kpi.textColor
            titlePaint.textSize = 12f
            titlePaint.isFakeBoldText = true
            drawRtlText(canvas, kpi.value, bx + 12f, by + 22f, boxWidth - 24f, titlePaint)
        }

        y += ((kpis.size + 1) / 2) * (boxHeight + 10f) + 14f

        // Electrical Lines / Groups Summary Table on Cover Page
        titlePaint.color = Color.rgb(15, 23, 42)
        titlePaint.textSize = 12f
        drawRtlText(canvas, "⚡ ملخص الخطوط ومجموعات التوزيع (الفيزات):", 24f, y, 400f, titlePaint)
        y += 18f

        // Table Header
        bgPaint.color = Color.rgb(51, 65, 85)
        canvas.drawRoundRect(24f, y, (pageWidth - 24).toFloat(), y + 22f, 4f, 4f, bgPaint)
        headerPaint.textSize = 9f
        drawRtlText(canvas, "اسم الخط / المجموعة", 30f, y + 4f, 150f, headerPaint)
        drawRtlText(canvas, "سعر الأمبير", 190f, y + 4f, 90f, headerPaint)
        drawRtlText(canvas, "الفيزة الثابتة", 290f, y + 4f, 80f, headerPaint)
        drawRtlText(canvas, "المشتركين", 380f, y + 4f, 70f, headerPaint)
        drawRtlText(canvas, "إجمالي الأمبيرات", 460f, y + 4f, 80f, headerPaint)
        y += 24f

        if (subscriberGroups.isEmpty()) {
            textPaint.color = Color.GRAY
            drawRtlText(canvas, "لا توجد مجموعات معرفة حالياً (تعتمد المنظومة السعر العام الموحد)", 30f, y + 4f, 500f, textPaint)
            y += 22f
        } else {
            subscriberGroups.forEachIndexed { idx, grp ->
                val grpSubs = subscribers.filter { it.groupName == grp.groupName }
                val grpAmps = grpSubs.sumOf { it.amperes }

                if (idx % 2 == 0) {
                    bgPaint.color = Color.rgb(248, 250, 252)
                    canvas.drawRect(24f, y, (pageWidth - 24).toFloat(), y + 18f, bgPaint)
                }
                textPaint.color = Color.rgb(30, 41, 59)
                textPaint.textSize = 8.5f
                drawRtlText(canvas, grp.groupName, 30f, y + 3f, 150f, textPaint)
                drawRtlText(canvas, formatCurrency(grp.pricePerAmpere), 190f, y + 3f, 90f, textPaint)
                drawRtlText(canvas, formatCurrency(grp.fixedFee), 290f, y + 3f, 80f, textPaint)
                drawRtlText(canvas, "${grpSubs.size} مشترك", 380f, y + 3f, 70f, textPaint)
                drawRtlText(canvas, "$grpAmps A", 460f, y + 3f, 80f, textPaint)
                y += 18f
            }
        }

        // Users & Roles Section
        y += 14f
        titlePaint.color = Color.rgb(15, 23, 42)
        titlePaint.textSize = 12f
        drawRtlText(canvas, "👥 حسابات النظام وصلاحيات الوصول:", 24f, y, 400f, titlePaint)
        y += 18f

        bgPaint.color = Color.rgb(51, 65, 85)
        canvas.drawRoundRect(24f, y, (pageWidth - 24).toFloat(), y + 22f, 4f, 4f, bgPaint)
        drawRtlText(canvas, "اسم المستخدم", 30f, y + 4f, 140f, headerPaint)
        drawRtlText(canvas, "الاسم الظاهر", 180f, y + 4f, 130f, headerPaint)
        drawRtlText(canvas, "الدور / الصلاحية", 320f, y + 4f, 110f, headerPaint)
        drawRtlText(canvas, "صلاحية الحذف / المالية", 440f, y + 4f, 120f, headerPaint)
        y += 24f

        users.forEachIndexed { idx, user ->
            if (idx % 2 == 0) {
                bgPaint.color = Color.rgb(248, 250, 252)
                canvas.drawRect(24f, y, (pageWidth - 24).toFloat(), y + 18f, bgPaint)
            }
            textPaint.color = Color.rgb(30, 41, 59)
            textPaint.textSize = 8.5f
            drawRtlText(canvas, user.username, 30f, y + 3f, 140f, textPaint)
            drawRtlText(canvas, user.name, 180f, y + 3f, 130f, textPaint)
            drawRtlText(canvas, if (user.role == "ADMIN") "صاحب المولدة (مدير عام)" else "جابي أموال", 320f, y + 3f, 110f, textPaint)
            drawRtlText(canvas, "${if (user.canDelete) "حذف: نعم" else "حذف: لا"} | ${if (user.canViewFinancials) "مالية: نعم" else "مالية: لا"}", 440f, y + 3f, 120f, textPaint)
            y += 18f
        }

        pdfDocument.finishPage(page)
        pageNumber++

        // ==========================================
        // PAGE 2+: FULL SUBSCRIBERS DIRECTORY
        // ==========================================
        pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        page = pdfDocument.startPage(pageInfo)
        canvas = page.canvas
        drawHeaderFooter(canvas, pageNumber, "سجل المشتركين الكامل وتفاصيل الاشتراكات والجوزات (${subscribers.size} مشترك)")

        y = 75f

        fun drawSubscribersTableHeader(c: Canvas, currentY: Float): Float {
            bgPaint.color = Color.rgb(30, 58, 138)
            c.drawRoundRect(24f, currentY, (pageWidth - 24).toFloat(), currentY + 22f, 4f, 4f, bgPaint)
            headerPaint.textSize = 9f
            drawRtlText(c, "الرمز", 30f, currentY + 4f, 40f, headerPaint)
            drawRtlText(c, "اسم المشترك", 75f, currentY + 4f, 140f, headerPaint)
            drawRtlText(c, "الهاتف", 220f, currentY + 4f, 85f, headerPaint)
            drawRtlText(c, "الأمبيرات", 310f, currentY + 4f, 50f, headerPaint)
            drawRtlText(c, "سعر الأمبير", 365f, currentY + 4f, 70f, headerPaint)
            drawRtlText(c, "الجوزة", 440f, currentY + 4f, 45f, headerPaint)
            drawRtlText(c, "المجموعة / الفيز", 490f, currentY + 4f, 75f, headerPaint)
            return currentY + 24f
        }

        y = drawSubscribersTableHeader(canvas, y)

        if (subscribers.isEmpty()) {
            textPaint.color = Color.GRAY
            drawRtlText(canvas, "لا يوجد أي مشتركين مسجلين في قاعدة البيانات حالياً.", 30f, y + 6f, 500f, textPaint)
        } else {
            subscribers.forEachIndexed { idx, sub ->
                if (y > pageHeight - 50) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    drawHeaderFooter(canvas, pageNumber, "تابع - سجل المشتركين وتفاصيل الجوزات")
                    y = drawSubscribersTableHeader(canvas, 75f)
                }

                if (idx % 2 == 0) {
                    bgPaint.color = Color.rgb(248, 250, 252)
                    canvas.drawRect(24f, y, (pageWidth - 24).toFloat(), y + 18f, bgPaint)
                }

                textPaint.color = Color.rgb(30, 41, 59)
                textPaint.textSize = 8.5f
                drawRtlText(canvas, sub.subscriberCode, 30f, y + 3f, 40f, textPaint)
                drawRtlText(canvas, sub.name, 75f, y + 3f, 140f, textPaint)
                drawRtlText(canvas, sub.phone.ifBlank { "-" }, 220f, y + 3f, 85f, textPaint)
                drawRtlText(canvas, "${sub.amperes} A", 310f, y + 3f, 50f, textPaint)
                drawRtlText(canvas, formatCurrency(sub.defaultPricePerAmpere), 365f, y + 3f, 70f, textPaint)
                drawRtlText(canvas, sub.circuitBreakerNumber.ifBlank { "-" }, 440f, y + 3f, 45f, textPaint)
                drawRtlText(canvas, sub.groupName.ifBlank { "افتراضي" }, 490f, y + 3f, 75f, textPaint)
                y += 18f
            }
        }

        pdfDocument.finishPage(page)
        pageNumber++

        // ==========================================
        // PAGE 3+: BILLING & DEBT HISTORY
        // ==========================================
        pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        page = pdfDocument.startPage(pageInfo)
        canvas = page.canvas
        drawHeaderFooter(canvas, pageNumber, "سجل الفواتير التاريخية والديون والمستحقات (${bills.size} فاتورة)")

        y = 75f

        fun drawBillsTableHeader(c: Canvas, currentY: Float): Float {
            bgPaint.color = Color.rgb(30, 58, 138)
            c.drawRoundRect(24f, currentY, (pageWidth - 24).toFloat(), currentY + 22f, 4f, 4f, bgPaint)
            headerPaint.textSize = 9f
            drawRtlText(c, "رقم الفاتورة", 30f, currentY + 4f, 70f, headerPaint)
            drawRtlText(c, "المشترك", 105f, currentY + 4f, 130f, headerPaint)
            drawRtlText(c, "الشهر/السنة", 240f, currentY + 4f, 65f, headerPaint)
            drawRtlText(c, "الأمبيرات", 310f, currentY + 4f, 50f, headerPaint)
            drawRtlText(c, "المبلغ الإجمالي", 365f, currentY + 4f, 70f, headerPaint)
            drawRtlText(c, "المدفوع", 440f, currentY + 4f, 60f, headerPaint)
            drawRtlText(c, "المتبقي (الدين)", 505f, currentY + 4f, 60f, headerPaint)
            return currentY + 24f
        }

        y = drawBillsTableHeader(canvas, y)

        if (bills.isEmpty()) {
            textPaint.color = Color.GRAY
            drawRtlText(canvas, "لا توجد فواتير مصدرة مسجلة في قاعدة البيانات حالياً.", 30f, y + 6f, 500f, textPaint)
        } else {
            bills.forEachIndexed { idx, bill ->
                if (y > pageHeight - 50) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    drawHeaderFooter(canvas, pageNumber, "تابع - سجل الفواتير والمستحقات المالية")
                    y = drawBillsTableHeader(canvas, 75f)
                }

                if (idx % 2 == 0) {
                    bgPaint.color = Color.rgb(248, 250, 252)
                    canvas.drawRect(24f, y, (pageWidth - 24).toFloat(), y + 18f, bgPaint)
                }

                textPaint.color = Color.rgb(30, 41, 59)
                textPaint.textSize = 8.5f
                drawRtlText(canvas, bill.billCode, 30f, y + 3f, 70f, textPaint)
                drawRtlText(canvas, bill.subscriberName, 105f, y + 3f, 130f, textPaint)
                drawRtlText(canvas, "${bill.month} / ${bill.year}", 240f, y + 3f, 65f, textPaint)
                drawRtlText(canvas, "${bill.amperes} A", 310f, y + 3f, 50f, textPaint)
                drawRtlText(canvas, formatCurrency(bill.totalAmount), 365f, y + 3f, 70f, textPaint)

                // Paid in green
                textPaint.color = Color.rgb(22, 101, 52)
                drawRtlText(canvas, formatCurrency(bill.paidAmount), 440f, y + 3f, 60f, textPaint)

                // Remaining in red if > 0
                textPaint.color = if (bill.remainingAmount > 0) Color.rgb(185, 28, 28) else Color.rgb(100, 116, 139)
                drawRtlText(canvas, formatCurrency(bill.remainingAmount), 505f, y + 3f, 60f, textPaint)

                y += 18f
            }
        }

        pdfDocument.finishPage(page)
        pageNumber++

        // ==========================================
        // PAGE 4+: RECEIPTS & COLLECTION LOG
        // ==========================================
        pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        page = pdfDocument.startPage(pageInfo)
        canvas = page.canvas
        drawHeaderFooter(canvas, pageNumber, "سجل إيصالات القبض والتحصيلات النقدية والبنكية (${payments.size} إيصال)")

        y = 75f

        fun drawPaymentsTableHeader(c: Canvas, currentY: Float): Float {
            bgPaint.color = Color.rgb(30, 58, 138)
            c.drawRoundRect(24f, currentY, (pageWidth - 24).toFloat(), currentY + 22f, 4f, 4f, bgPaint)
            headerPaint.textSize = 9f
            drawRtlText(c, "رقم الإيصال", 30f, currentY + 4f, 75f, headerPaint)
            drawRtlText(c, "المشترك", 110f, currentY + 4f, 135f, headerPaint)
            drawRtlText(c, "المبلغ المقبوض", 250f, currentY + 4f, 85f, headerPaint)
            drawRtlText(c, "تاريخ وساعة القبض", 340f, currentY + 4f, 125f, headerPaint)
            drawRtlText(c, "المستلم / الجابي", 470f, currentY + 4f, 95f, headerPaint)
            return currentY + 24f
        }

        y = drawPaymentsTableHeader(canvas, y)

        val rowDateFormat = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar"))

        if (payments.isEmpty()) {
            textPaint.color = Color.GRAY
            drawRtlText(canvas, "لا توجد إيصالات أو سندات قبض مسجلة حالياً.", 30f, y + 6f, 500f, textPaint)
        } else {
            payments.forEachIndexed { idx, payment ->
                if (y > pageHeight - 50) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    drawHeaderFooter(canvas, pageNumber, "تابع - سجل إيصالات القبض والتسديدات")
                    y = drawPaymentsTableHeader(canvas, 75f)
                }

                if (idx % 2 == 0) {
                    bgPaint.color = Color.rgb(248, 250, 252)
                    canvas.drawRect(24f, y, (pageWidth - 24).toFloat(), y + 18f, bgPaint)
                }

                textPaint.color = Color.rgb(30, 41, 59)
                textPaint.textSize = 8.5f
                drawRtlText(canvas, payment.receiptCode, 30f, y + 3f, 75f, textPaint)
                drawRtlText(canvas, payment.subscriberName, 110f, y + 3f, 135f, textPaint)
                
                textPaint.color = Color.rgb(21, 128, 61)
                drawRtlText(canvas, formatCurrency(payment.amountPaid), 250f, y + 3f, 85f, textPaint)

                textPaint.color = Color.rgb(71, 85, 105)
                val paymentDateStr = try { rowDateFormat.format(Date(payment.paymentDate)) } catch (e: Exception) { "" }
                drawRtlText(canvas, paymentDateStr, 340f, y + 3f, 125f, textPaint)
                drawRtlText(canvas, payment.collectedBy, 470f, y + 3f, 95f, textPaint)
                y += 18f
            }
        }

        pdfDocument.finishPage(page)
        pageNumber++

        // ==========================================
        // PAGE 5+: EXPENSES & OUTLAYS LEDGER
        // ==========================================
        pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        page = pdfDocument.startPage(pageInfo)
        canvas = page.canvas
        drawHeaderFooter(canvas, pageNumber, "سجل المصروفات التشغيلية والوقود والصيانة (${expenses.size} حركة صرف)")

        y = 75f

        fun drawExpensesTableHeader(c: Canvas, currentY: Float): Float {
            bgPaint.color = Color.rgb(30, 58, 138)
            c.drawRoundRect(24f, currentY, (pageWidth - 24).toFloat(), currentY + 22f, 4f, 4f, bgPaint)
            headerPaint.textSize = 9f
            drawRtlText(c, "التصنيف", 30f, currentY + 4f, 95f, headerPaint)
            drawRtlText(c, "البيان / الوصف", 130f, currentY + 4f, 165f, headerPaint)
            drawRtlText(c, "المبلغ", 300f, currentY + 4f, 75f, headerPaint)
            drawRtlText(c, "تاريخ الصرف", 380f, currentY + 4f, 85f, headerPaint)
            drawRtlText(c, "ملاحظات إضافية", 470f, currentY + 4f, 95f, headerPaint)
            return currentY + 24f
        }

        y = drawExpensesTableHeader(canvas, y)

        if (expenses.isEmpty()) {
            textPaint.color = Color.GRAY
            drawRtlText(canvas, "لا توجد حركات مصروفات مسجلة في قاعدة البيانات حالياً.", 30f, y + 6f, 500f, textPaint)
        } else {
            expenses.forEachIndexed { idx, exp ->
                if (y > pageHeight - 50) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    drawHeaderFooter(canvas, pageNumber, "تابع - سجل المصروفات والتشغيل")
                    y = drawExpensesTableHeader(canvas, 75f)
                }

                if (idx % 2 == 0) {
                    bgPaint.color = Color.rgb(248, 250, 252)
                    canvas.drawRect(24f, y, (pageWidth - 24).toFloat(), y + 18f, bgPaint)
                }

                textPaint.color = Color.rgb(30, 41, 59)
                textPaint.textSize = 8.5f
                drawRtlText(canvas, exp.category, 30f, y + 3f, 95f, textPaint)
                drawRtlText(canvas, exp.description, 130f, y + 3f, 165f, textPaint)

                textPaint.color = Color.rgb(185, 28, 28)
                drawRtlText(canvas, formatCurrency(exp.amount), 300f, y + 3f, 75f, textPaint)

                textPaint.color = Color.rgb(71, 85, 105)
                val expDateStr = try { rowDateFormat.format(Date(exp.expenseDate)) } catch (e: Exception) { "" }
                drawRtlText(canvas, expDateStr, 380f, y + 3f, 85f, textPaint)
                drawRtlText(canvas, exp.notes.ifBlank { "-" }, 470f, y + 3f, 95f, textPaint)
                y += 18f
            }
        }

        pdfDocument.finishPage(page)

        // Write PDF to cache directory for immediate sharing & backup
        val safeGenName = genName.replace(" ", "_").replace("/", "-")
        val fileName = "نسخة_احتياطية_شاملة_${safeGenName}_${System.currentTimeMillis()}.pdf"
        val backupFile = File(context.cacheDir, fileName)

        return try {
            FileOutputStream(backupFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()
            backupFile
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDocument.close()
            null
        }
    }
}
