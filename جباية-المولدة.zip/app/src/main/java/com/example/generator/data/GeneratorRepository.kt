package com.example.generator.data

import com.example.generator.data.dao.GeneratorDao
import com.example.generator.data.entity.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GeneratorRepository(val dao: GeneratorDao) {

    val subscribers: Flow<List<Subscriber>> = dao.getAllSubscribersFlow()
    val subscriberGroups: Flow<List<SubscriberGroup>> = dao.getAllSubscriberGroupsFlow()
    val bills: Flow<List<Bill>> = dao.getAllBillsFlow()
    val payments: Flow<List<Payment>> = dao.getAllPaymentsFlow()
    val expenses: Flow<List<Expense>> = dao.getAllExpensesFlow()
    val users: Flow<List<UserAccount>> = dao.getAllUsersFlow()
    val settings: Flow<GeneratorSettings?> = dao.getSettingsFlow()
    val subscribersCount: Flow<Int> = dao.getSubscribersCountFlow()

    val totalDueAmount: Flow<Double> = dao.getTotalDueAmountFlow()
    val totalCollectedAmount: Flow<Double> = dao.getTotalCollectedAmountFlow()
    val totalDebtsAmount: Flow<Double> = dao.getTotalDebtsAmountFlow()
    val totalExpensesAmount: Flow<Double> = dao.getTotalExpensesAmountFlow()

    fun searchSubscribers(query: String): Flow<List<Subscriber>> {
        return if (query.isBlank()) dao.getAllSubscribersFlow() else dao.searchSubscribersFlow(query)
    }

    suspend fun getSubscriberById(id: Long): Subscriber? = dao.getSubscriberById(id)

    suspend fun addSubscriber(
        name: String,
        phone: String,
        amperes: Double,
        pricePerAmpere: Double,
        groupName: String = "",
        fixedFee: Double = 0.0,
        circuitBreakerNumber: String = "",
        notes: String = ""
    ): Long {
        val count = dao.getAllSubscribersDirect().size + 1001
        val code = "SUB-$count"
        val subscriber = Subscriber(
            subscriberCode = code,
            name = name,
            phone = phone,
            amperes = amperes,
            defaultPricePerAmpere = pricePerAmpere,
            groupName = groupName,
            fixedFee = fixedFee,
            circuitBreakerNumber = circuitBreakerNumber,
            isActive = true,
            notes = notes
        )
        return dao.insertSubscriber(subscriber)
    }

    suspend fun updateSubscriber(subscriber: Subscriber) {
        dao.updateSubscriber(subscriber)
    }

    suspend fun updateAllSubscribersDefaultPrice(newPrice: Double) {
        dao.updateAllSubscribersDefaultPrice(newPrice)
    }

    suspend fun deleteSubscriber(subscriberId: Long) {
        dao.deleteSubscriberById(subscriberId)
    }

    // --- SUBSCRIBER GROUPS / PHASES MANAGEMENT ---
    suspend fun addSubscriberGroup(
        groupName: String,
        pricePerAmpere: Double,
        fixedFee: Double,
        notes: String,
        applyToExistingSubscribers: Boolean = false
    ): Long {
        val group = SubscriberGroup(
            groupName = groupName,
            pricePerAmpere = pricePerAmpere,
            fixedFee = fixedFee,
            notes = notes
        )
        val id = dao.insertSubscriberGroup(group)
        if (applyToExistingSubscribers) {
            dao.updateSubscribersFeesForGroup(groupName, pricePerAmpere, fixedFee)
        }
        return id
    }

    suspend fun updateSubscriberGroup(
        group: SubscriberGroup,
        oldGroupName: String? = null,
        applyToSubscribers: Boolean = false
    ) {
        dao.updateSubscriberGroup(group)
        if (oldGroupName != null && oldGroupName != group.groupName) {
            dao.updateSubscriberGroupName(oldGroupName, group.groupName)
        }
        if (applyToSubscribers) {
            dao.updateSubscribersFeesForGroup(group.groupName, group.pricePerAmpere, group.fixedFee)
        }
    }

    suspend fun deleteSubscriberGroup(groupId: Long) {
        dao.deleteSubscriberGroupById(groupId)
    }

    suspend fun applyGroupPricingToSubscribers(groupName: String, pricePerAmpere: Double, fixedFee: Double) {
        dao.updateSubscribersFeesForGroup(groupName, pricePerAmpere, fixedFee)
    }

    // --- BILLING LOGIC ---
    suspend fun generateMonthlyBillsForActiveSubscribers(month: Int, year: Int): Int {
        val activeSubscribers = dao.getActiveSubscribers()
        var createdCount = 0

        for (sub in activeSubscribers) {
            val existing = dao.getBillBySubscriberMonthYear(sub.id, month, year)
            if (existing == null) {
                val total = (sub.amperes * sub.defaultPricePerAmpere) + sub.fixedFee
                val billCode = "INV-$year${String.format(Locale.US, "%02d", month)}-${sub.id}"
                val bill = Bill(
                    billCode = billCode,
                    subscriberId = sub.id,
                    subscriberName = sub.name,
                    subscriberCode = sub.subscriberCode,
                    month = month,
                    year = year,
                    amperes = sub.amperes,
                    pricePerAmpere = sub.defaultPricePerAmpere,
                    fixedFee = sub.fixedFee,
                    totalAmount = total,
                    paidAmount = 0.0,
                    remainingAmount = total,
                    status = "UNPAID"
                )
                dao.insertBill(bill)
                createdCount++
            }
        }
        return createdCount
    }

    suspend fun addSingleBillForSubscriber(
        subscriberId: Long,
        month: Int,
        year: Int,
        amperes: Double,
        pricePerAmpere: Double,
        customTotal: Double? = null
    ): Boolean {
        val subscriber = dao.getSubscriberById(subscriberId) ?: return false
        val existing = dao.getBillBySubscriberMonthYear(subscriberId, month, year)
        if (existing != null) {
            return false
        }
        val total = customTotal ?: ((amperes * pricePerAmpere) + subscriber.fixedFee)
        val billCode = "INV-$year${String.format(Locale.US, "%02d", month)}-${subscriber.id}"
        val bill = Bill(
            billCode = billCode,
            subscriberId = subscriber.id,
            subscriberName = subscriber.name,
            subscriberCode = subscriber.subscriberCode,
            month = month,
            year = year,
            amperes = amperes,
            pricePerAmpere = pricePerAmpere,
            fixedFee = subscriber.fixedFee,
            totalAmount = total,
            paidAmount = 0.0,
            remainingAmount = total,
            status = "UNPAID"
        )
        dao.insertBill(bill)
        return true
    }

    suspend fun recordPayment(
        billId: Long,
        amountPaidNow: Double,
        collectorName: String,
        notes: String
    ): Payment? {
        val bill = dao.getBillById(billId) ?: return null
        val newPaid = bill.paidAmount + amountPaidNow
        val newRemaining = (bill.totalAmount - newPaid).coerceAtLeast(0.0)
        val newStatus = when {
            newRemaining <= 0.0 -> "PAID"
            newPaid > 0.0 -> "PARTIAL"
            else -> "UNPAID"
        }

        val updatedBill = bill.copy(
            paidAmount = newPaid,
            remainingAmount = newRemaining,
            status = newStatus
        )
        dao.updateBill(updatedBill)

        val timeStamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        val receiptCode = "REC-$timeStamp-${bill.subscriberId}"

        val payment = Payment(
            receiptCode = receiptCode,
            billId = bill.id,
            subscriberId = bill.subscriberId,
            subscriberName = bill.subscriberName,
            amountPaid = amountPaidNow,
            paymentDate = System.currentTimeMillis(),
            collectedBy = collectorName,
            notes = notes
        )
        val id = dao.insertPayment(payment)
        return payment.copy(id = id)
    }

    /**
     * Reverts all payments for a given bill, resetting it back to UNPAID status
     * and restoring the full remaining amount to debts/receivables.
     */
    suspend fun revertBillPayment(billId: Long): Boolean {
        val bill = dao.getBillById(billId) ?: return false
        dao.deletePaymentsForBill(billId)
        val resetBill = bill.copy(
            paidAmount = 0.0,
            remainingAmount = bill.totalAmount,
            status = "UNPAID"
        )
        dao.updateBill(resetBill)
        return true
    }

    /**
     * Reverts a single specific payment receipt and recalculates the bill's balance.
     */
    suspend fun revertSinglePayment(paymentId: Long): Boolean {
        val payment = dao.getPaymentById(paymentId) ?: return false
        val bill = dao.getBillById(payment.billId)
        dao.deletePaymentById(paymentId)

        if (bill != null) {
            val remainingPayments = dao.getPaymentsForBillDirect(bill.id)
            val newPaid = remainingPayments.sumOf { it.amountPaid }
            val newRemaining = (bill.totalAmount - newPaid).coerceAtLeast(0.0)
            val newStatus = when {
                newPaid <= 0.0 -> "UNPAID"
                newRemaining <= 0.0 -> "PAID"
                else -> "PARTIAL"
            }
            dao.updateBill(
                bill.copy(
                    paidAmount = newPaid,
                    remainingAmount = newRemaining,
                    status = newStatus
                )
            )
        }
        return true
    }

    suspend fun addExpense(
        category: String,
        amount: Double,
        description: String,
        notes: String,
        recordedBy: String
    ): Long {
        val expense = Expense(
            category = category,
            amount = amount,
            expenseDate = System.currentTimeMillis(),
            description = description,
            notes = notes,
            recordedBy = recordedBy
        )
        return dao.insertExpense(expense)
    }

    suspend fun deleteExpense(id: Long) {
        dao.deleteExpenseById(id)
    }

    suspend fun saveSettings(settings: GeneratorSettings) {
        dao.saveSettings(settings)
    }

    suspend fun login(username: String, pin: String): UserAccount? {
        return dao.loginUser(username, pin)
    }

    suspend fun addUser(user: UserAccount): Long {
        return dao.insertUser(user)
    }

    suspend fun deleteUser(id: Long) {
        dao.deleteUserById(id)
    }

    suspend fun clearAllDataAndResetAccount() {
        dao.deleteAllPayments()
        dao.deleteAllBills()
        dao.deleteAllSubscribers()
        dao.deleteAllSubscriberGroups()
        dao.deleteAllExpenses()
        dao.deleteAllUsers()

        // Create clean initial admin user and collector
        dao.insertUser(
            UserAccount(
                id = 1,
                username = "admin",
                name = "المدير العام",
                pinCode = "1234",
                role = "ADMIN",
                canDelete = true,
                canViewFinancials = true,
                isActive = true
            )
        )
        dao.insertUser(
            UserAccount(
                id = 2,
                username = "gabi",
                name = "الجابي",
                pinCode = "0000",
                role = "COLLECTOR",
                canDelete = false,
                canViewFinancials = false,
                isActive = true
            )
        )

        // Reset blank settings with no dummy names/addresses/phones
        dao.saveSettings(
            GeneratorSettings(
                id = 1,
                generatorName = "",
                ownerName = "",
                phone = "",
                address = "",
                defaultPricePerAmpere = 0.0,
                mastercardNumber = "",
                isOnlineSyncEnabled = true
            )
        )
    }

    // Direct data export/import helpers
    suspend fun getAllSubscribersDirect() = dao.getAllSubscribersDirect()
    suspend fun getAllBillsDirect() = dao.getAllBillsDirect()
    suspend fun getAllPaymentsDirect() = dao.getAllPaymentsDirect()
    suspend fun getAllExpensesDirect() = dao.getAllExpensesDirect()
    suspend fun getAllUsersDirect() = dao.getAllUsersDirect()
    suspend fun getSettingsDirect() = dao.getSettings()

    suspend fun restoreDatabase(
        subscribersList: List<Subscriber>,
        subscriberGroupsList: List<SubscriberGroup>,
        billsList: List<Bill>,
        paymentsList: List<Payment>,
        expensesList: List<Expense>,
        usersList: List<UserAccount>,
        settingsObj: GeneratorSettings?
    ) {
        dao.deleteAllPayments()
        dao.deleteAllBills()
        dao.deleteAllSubscribers()
        dao.deleteAllSubscriberGroups()
        dao.deleteAllExpenses()
        dao.deleteAllUsers()

        // 1. Restore all subscriber groups / phases (الفيزات والخطوط)
        if (subscriberGroupsList.isNotEmpty()) {
            subscriberGroupsList.forEach { dao.insertSubscriberGroup(it) }
        } else {
            // Reconstruct groups dynamically from subscribers list if restoring older backup
            val distinctGroups = subscribersList.map { it.groupName }.filter { it.isNotBlank() }.distinct()
            if (distinctGroups.isNotEmpty()) {
                distinctGroups.forEach { grpName ->
                    val matching = subscribersList.firstOrNull { it.groupName == grpName }
                    dao.insertSubscriberGroup(
                        SubscriberGroup(
                            groupName = grpName,
                            pricePerAmpere = matching?.defaultPricePerAmpere ?: 0.0,
                            fixedFee = matching?.fixedFee ?: 0.0,
                            notes = "مستعادة من بيانات المشتركين"
                        )
                    )
                }
            }
        }

        // 2. Restore all subscribers
        subscribersList.forEach { dao.insertSubscriber(it) }

        // 3. Restore all bills, payments, expenses, users, and settings
        billsList.forEach { dao.insertBill(it) }
        paymentsList.forEach { dao.insertPayment(it) }
        expensesList.forEach { dao.insertExpense(it) }
        usersList.forEach { dao.insertUser(it) }
        if (settingsObj != null) dao.saveSettings(settingsObj)
    }
}
