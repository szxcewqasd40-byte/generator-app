package com.example.generator.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subscribers")
data class Subscriber(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subscriberCode: String, // e.g. SUB-1001
    val name: String,
    val phone: String,
    val amperes: Double, // عدد الأمبيرات
    val defaultPricePerAmpere: Double, // سعر الأمبير
    val groupName: String = "", // اسم المجموعة / الفيز / الخط
    val fixedFee: Double = 0.0, // رسوم الفيزة الثابتة / الاشتراك للمجموعة
    val circuitBreakerNumber: String = "", // رقم الجوزة / القاطع في لوحة التوزيع
    val isActive: Boolean = true, // حالة الاشتراك
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
