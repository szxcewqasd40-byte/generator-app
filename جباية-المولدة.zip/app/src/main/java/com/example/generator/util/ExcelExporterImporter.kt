package com.example.generator.util

import android.content.Context
import com.example.generator.data.entity.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object ExcelExporterImporter {

    /**
     * Exports all database entities to a formatted UTF-8 CSV file (with BOM) for seamless opening in Excel.
     * Saves to phone Downloads and cacheDir for instant sharing/opening.
     */
    fun exportToExcelCsv(
        context: Context,
        subscribers: List<Subscriber>,
        subscriberGroups: List<SubscriberGroup>,
        bills: List<Bill>,
        payments: List<Payment>,
        expenses: List<Expense>,
        settings: GeneratorSettings?
    ): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "جباية_المولدة_التقرير_المالي_الشامل_$timestamp.csv"
        val file = File(context.cacheDir, fileName)
        
        val stringWriter = java.io.StringWriter()
        val writer = stringWriter

        writer.write("=== معلومات المولدة والإعدادات ===\n")
        writer.write("اسم المولدة,صاحب المولدة,رقم الهاتف,العنوان,سعر الأمبير الافتراضي,رقم الماستر كارد\n")
        writer.write("\"${settings?.generatorName ?: ""}\",\"${settings?.ownerName ?: ""}\",\"${settings?.phone ?: ""}\",\"${settings?.address ?: ""}\",${settings?.defaultPricePerAmpere ?: 10000.0},\"${settings?.mastercardNumber ?: ""}\"\n\n")

        writer.write("=== جدول الفيزات والخطوط والمجموعات ===\n")
        writer.write("المعرف,اسم الفيز / المجموعة,سعر الأمبير,رسوم الفيزة الثابتة,ملاحظات\n")
        for (grp in subscriberGroups) {
            writer.write("${grp.id},\"${grp.groupName}\",${grp.pricePerAmpere},${grp.fixedFee},\"${grp.notes.replace("\n", " ")}\"\n")
        }
        writer.write("\n")

        writer.write("=== جدول المشتركين ===\n")
        writer.write("المعرف,رقم المشترك,اسم المشترك,رقم الهاتف,رقم الجوزة,عدد الأمبيرات,سعر الأمبير,اسم الفيز / المجموعة,رسوم الفيزة,حالة الاشتراك,ملاحظات\n")
        for (sub in subscribers) {
            val statusStr = if (sub.isActive) "فعال" else "متوقف"
            writer.write("${sub.id},\"${sub.subscriberCode}\",\"${sub.name}\",\"${sub.phone}\",\"${sub.circuitBreakerNumber}\",${sub.amperes},${sub.defaultPricePerAmpere},\"${sub.groupName}\",${sub.fixedFee},\"$statusStr\",\"${sub.notes.replace("\n", " ")}\"\n")
        }
        writer.write("\n")

        writer.write("=== جدول الفواتير ===\n")
        writer.write("المعرف,رقم الفواتير,رقم المشترك,اسم المشترك,الشهر,السنة,عدد الأمبيرات,سعر الأمبير,الرسوم الثابتة,المبلغ الإجمالي,المبلغ المدفوع,المبلغ المتبقي,الحالة\n")
        for (bill in bills) {
            val statusAr = when (bill.status) {
                "PAID" -> "مدفوعة"
                "PARTIAL" -> "مدفوعة جزئياً"
                else -> "غير مدفوعة"
            }
            writer.write("${bill.id},\"${bill.billCode}\",\"${bill.subscriberCode}\",\"${bill.subscriberName}\",${bill.month},${bill.year},${bill.amperes},${bill.pricePerAmpere},${bill.fixedFee},${bill.totalAmount},${bill.paidAmount},${bill.remainingAmount},\"$statusAr\"\n")
        }
        writer.write("\n")

        writer.write("=== جدول المقبوضات والدفعات ===\n")
        writer.write("المعرف,رقم الإيصال,معرف الفاتورة,اسم المشترك,المبلغ المدفوع,تاريخ الدفع,الجابي,ملاحظات\n")
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar"))
        for (p in payments) {
            val dateStr = dateFormat.format(Date(p.paymentDate))
            writer.write("${p.id},\"${p.receiptCode}\",${p.billId},\"${p.subscriberName}\",${p.amountPaid},\"$dateStr\",\"${p.collectedBy}\",\"${p.notes.replace("\n", " ")}\"\n")
        }
        writer.write("\n")

        writer.write("=== جدول المصروفات ===\n")
        writer.write("المعرف,نوع المصروف,المبلغ,التاريخ,الوصف,ملاحظات,المسجل\n")
        for (exp in expenses) {
            val dateStr = dateFormat.format(Date(exp.expenseDate))
            writer.write("${exp.id},\"${exp.category}\",${exp.amount},\"$dateStr\",\"${exp.description.replace("\n", " ")}\",\"${exp.notes.replace("\n", " ")}\",\"${exp.recordedBy}\"\n")
        }
        writer.flush()

        val textContent = stringWriter.toString()
        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        val contentBytes = bom + textContent.toByteArray(Charsets.UTF_8)

        // 1. Write to cacheDir
        FileOutputStream(file).use { fos ->
            fos.write(contentBytes)
            fos.flush()
        }

        // 2. Save directly to public Downloads folder in phone storage!
        FileDownloadHelper.saveToDownloads(
            context = context,
            fileName = fileName,
            mimeType = "text/csv",
            contentBytes = contentBytes
        )

        return file
    }

    /**
     * Exports Debts & Arrears report directly to Excel CSV and Downloads folder.
     */
    fun exportDebtsToExcelCsv(
        context: Context,
        bills: List<Bill>,
        settings: GeneratorSettings?
    ): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "كشف_الديون_والمتأخرات_$timestamp.csv"
        val file = File(context.cacheDir, fileName)

        val stringWriter = java.io.StringWriter()
        val writer = stringWriter

        val unpaidBills = bills.filter { it.remainingAmount > 0 }
        val totalDebts = unpaidBills.sumOf { it.remainingAmount }

        writer.write("=== كشف الديون والمتأخرات - ${settings?.generatorName ?: "المولدة"} ===\n")
        writer.write("إجمالي الديون غير المسددة: ${totalDebts.toLong()} د.ع\n")
        writer.write("عدد الفواتير غير المسددة: ${unpaidBills.size}\n\n")
        writer.write("رقم المشترك,اسم المشترك,الشهر/السنة,الأمبيرات,المبلغ الإجمالي,المدفوع,المبلغ المتبقي (الدين),حالة الفاتورة\n")

        for (b in unpaidBills) {
            val st = if (b.paidAmount > 0) "مدفوعة جزئياً" else "غير مسددة"
            writer.write("\"${b.subscriberCode}\",\"${b.subscriberName}\",\"${b.month}/${b.year}\",${b.amperes},${b.totalAmount},${b.paidAmount},${b.remainingAmount},\"$st\"\n")
        }
        writer.flush()

        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        val contentBytes = bom + stringWriter.toString().toByteArray(Charsets.UTF_8)

        FileOutputStream(file).use { fos ->
            fos.write(contentBytes)
            fos.flush()
        }

        FileDownloadHelper.saveToDownloads(
            context = context,
            fileName = fileName,
            mimeType = "text/csv",
            contentBytes = contentBytes
        )
        return file
    }

    /**
     * Exports Daily Collection payments report to Excel CSV and Downloads folder.
     */
    fun exportDailyPaymentsToExcelCsv(
        context: Context,
        payments: List<Payment>,
        dateLabel: String,
        settings: GeneratorSettings?
    ): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "كشف_المقبوضات_اليومية_$timestamp.csv"
        val file = File(context.cacheDir, fileName)

        val stringWriter = java.io.StringWriter()
        val writer = stringWriter

        val totalAmount = payments.sumOf { it.amountPaid }
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar"))

        writer.write("=== كشف المقبوضات والجباية ($dateLabel) - ${settings?.generatorName ?: "المولدة"} ===\n")
        writer.write("إجمالي المقبوضات: ${totalAmount.toLong()} د.ع | عدد الإيصالات: ${payments.size}\n\n")
        writer.write("ت,رقم الإيصال,اسم المشترك,المبلغ المقبوض (د.ع),تاريخ وساعة القبض,الجابي المستلم,ملاحظات\n")

        payments.forEachIndexed { idx, p ->
            val dStr = dateFormat.format(Date(p.paymentDate))
            writer.write("${idx + 1},\"${p.receiptCode}\",\"${p.subscriberName}\",${p.amountPaid},\"$dStr\",\"${p.collectedBy}\",\"${p.notes.replace("\n", " ")}\"\n")
        }
        writer.flush()

        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        val contentBytes = bom + stringWriter.toString().toByteArray(Charsets.UTF_8)

        FileOutputStream(file).use { fos ->
            fos.write(contentBytes)
            fos.flush()
        }

        FileDownloadHelper.saveToDownloads(
            context = context,
            fileName = fileName,
            mimeType = "text/csv",
            contentBytes = contentBytes
        )
        return file
    }

    /**
     * Exports Expenses report to Excel CSV and Downloads folder.
     */
    fun exportExpensesToExcelCsv(
        context: Context,
        expenses: List<Expense>,
        settings: GeneratorSettings?
    ): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "كشف_المصروفات_التشغيلية_$timestamp.csv"
        val file = File(context.cacheDir, fileName)

        val stringWriter = java.io.StringWriter()
        val writer = stringWriter

        val totalExp = expenses.sumOf { it.amount }
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar"))

        writer.write("=== كشف المصروفات التشغيلية - ${settings?.generatorName ?: "المولدة"} ===\n")
        writer.write("إجمالي المصروفات: ${totalExp.toLong()} د.ع | عدد السجلات: ${expenses.size}\n\n")
        writer.write("ت,نوع المصروف,المبلغ (د.ع),التاريخ,وصف وتفاصيل المصروف,المسجل,ملاحظات\n")

        expenses.forEachIndexed { idx, e ->
            val dStr = dateFormat.format(Date(e.expenseDate))
            writer.write("${idx + 1},\"${e.category}\",${e.amount},\"$dStr\",\"${e.description.replace("\n", " ")}\",\"${e.recordedBy}\",\"${e.notes.replace("\n", " ")}\"\n")
        }
        writer.flush()

        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        val contentBytes = bom + stringWriter.toString().toByteArray(Charsets.UTF_8)

        FileOutputStream(file).use { fos ->
            fos.write(contentBytes)
            fos.flush()
        }

        FileDownloadHelper.saveToDownloads(
            context = context,
            fileName = fileName,
            mimeType = "text/csv",
            contentBytes = contentBytes
        )
        return file
    }

    /**
     * Builds complete JSON String for backup.
     */
    fun buildJsonPayload(
        subscribers: List<Subscriber>,
        subscriberGroups: List<SubscriberGroup>,
        bills: List<Bill>,
        payments: List<Payment>,
        expenses: List<Expense>,
        users: List<UserAccount>,
        settings: GeneratorSettings?
    ): String {
        val root = JSONObject()
        val timestamp = System.currentTimeMillis()
        root.put("version", 2)
        root.put("timestamp", timestamp)

        // Settings
        val setObj = JSONObject()
        setObj.put("generatorName", settings?.generatorName ?: "")
        setObj.put("ownerName", settings?.ownerName ?: "")
        setObj.put("phone", settings?.phone ?: "")
        setObj.put("address", settings?.address ?: "")
        setObj.put("defaultPricePerAmpere", settings?.defaultPricePerAmpere ?: 10000.0)
        setObj.put("mastercardNumber", settings?.mastercardNumber ?: "")
        setObj.put("isOnlineSyncEnabled", settings?.isOnlineSyncEnabled ?: true)
        root.put("settings", setObj)

        // Subscriber Groups / Phases (اسماء الفيزات والخطوط والمجموعات)
        val grpArr = JSONArray()
        for (g in subscriberGroups) {
            val gi = JSONObject()
            gi.put("id", g.id)
            gi.put("groupName", g.groupName)
            gi.put("pricePerAmpere", g.pricePerAmpere)
            gi.put("fixedFee", g.fixedFee)
            gi.put("notes", g.notes)
            gi.put("createdAt", g.createdAt)
            grpArr.put(gi)
        }
        root.put("subscriberGroups", grpArr)

        // Subscribers
        val subArr = JSONArray()
        for (sub in subscribers) {
            val s = JSONObject()
            s.put("id", sub.id)
            s.put("subscriberCode", sub.subscriberCode)
            s.put("name", sub.name)
            s.put("phone", sub.phone)
            s.put("amperes", sub.amperes)
            s.put("defaultPricePerAmpere", sub.defaultPricePerAmpere)
            s.put("groupName", sub.groupName)
            s.put("fixedFee", sub.fixedFee)
            s.put("circuitBreakerNumber", sub.circuitBreakerNumber)
            s.put("isActive", sub.isActive)
            s.put("notes", sub.notes)
            s.put("createdAt", sub.createdAt)
            subArr.put(s)
        }
        root.put("subscribers", subArr)

        // Bills
        val billArr = JSONArray()
        for (b in bills) {
            val bi = JSONObject()
            bi.put("id", b.id)
            bi.put("billCode", b.billCode)
            bi.put("subscriberId", b.subscriberId)
            bi.put("subscriberName", b.subscriberName)
            bi.put("subscriberCode", b.subscriberCode)
            bi.put("month", b.month)
            bi.put("year", b.year)
            bi.put("amperes", b.amperes)
            bi.put("pricePerAmpere", b.pricePerAmpere)
            bi.put("fixedFee", b.fixedFee)
            bi.put("totalAmount", b.totalAmount)
            bi.put("paidAmount", b.paidAmount)
            bi.put("remainingAmount", b.remainingAmount)
            bi.put("status", b.status)
            bi.put("createdAt", b.createdAt)
            billArr.put(bi)
        }
        root.put("bills", billArr)

        // Payments
        val payArr = JSONArray()
        for (p in payments) {
            val py = JSONObject()
            py.put("id", p.id)
            py.put("receiptCode", p.receiptCode)
            py.put("billId", p.billId)
            py.put("subscriberId", p.subscriberId)
            py.put("subscriberName", p.subscriberName)
            py.put("amountPaid", p.amountPaid)
            py.put("paymentDate", p.paymentDate)
            py.put("collectedBy", p.collectedBy)
            py.put("notes", p.notes)
            payArr.put(py)
        }
        root.put("payments", payArr)

        // Expenses
        val expArr = JSONArray()
        for (e in expenses) {
            val ex = JSONObject()
            ex.put("id", e.id)
            ex.put("category", e.category)
            ex.put("amount", e.amount)
            ex.put("expenseDate", e.expenseDate)
            ex.put("description", e.description)
            ex.put("notes", e.notes)
            ex.put("recordedBy", e.recordedBy)
            expArr.put(ex)
        }
        root.put("expenses", expArr)

        // Users
        val usrArr = JSONArray()
        for (u in users) {
            val us = JSONObject()
            us.put("id", u.id)
            us.put("username", u.username)
            us.put("name", u.name)
            us.put("pinCode", u.pinCode)
            us.put("role", u.role)
            us.put("canDelete", u.canDelete)
            us.put("canViewFinancials", u.canViewFinancials)
            us.put("isActive", u.isActive)
            us.put("email", u.email ?: "")
            usrArr.put(us)
        }
        root.put("users", usrArr)

        return root.toString(2)
    }

    /**
     * Creates a complete JSON backup payload for 100% structured restoration.
     */
    fun exportToJsonBackup(
        context: Context,
        subscribers: List<Subscriber>,
        subscriberGroups: List<SubscriberGroup>,
        bills: List<Bill>,
        payments: List<Payment>,
        expenses: List<Expense>,
        users: List<UserAccount>,
        settings: GeneratorSettings?
    ): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "مولدتي_نسخة_احتياطية_$timestamp.json"
        val jsonString = buildJsonPayload(subscribers, subscriberGroups, bills, payments, expenses, users, settings)
        val file = File(context.cacheDir, fileName)
        file.writeText(jsonString, Charsets.UTF_8)
        
        // Also write a copy to external Downloads directory so uninstalls won't delete it
        FileDownloadHelper.saveToDownloads(
            context = context,
            fileName = fileName,
            mimeType = "application/json",
            contentBytes = jsonString.toByteArray(Charsets.UTF_8)
        )

        autoSaveBackupToDownloads(context, subscribers, subscriberGroups, bills, payments, expenses, users, settings)
        return file
    }

    /**
     * Automatically saves a JSON backup copy in device public Downloads directory and internal storage.
     * Stored in Downloads/مولدتي_نسخة_احتياطية_تلقائية.json so it persists after app uninstallation!
     */
    fun autoSaveBackupToDownloads(
        context: Context,
        subscribers: List<Subscriber>,
        subscriberGroups: List<SubscriberGroup>,
        bills: List<Bill>,
        payments: List<Payment>,
        expenses: List<Expense>,
        users: List<UserAccount>,
        settings: GeneratorSettings?
    ): File? {
        return try {
            val jsonString = buildJsonPayload(subscribers, subscriberGroups, bills, payments, expenses, users, settings)
            
            // 1. Internal app storage backup
            val internalFile = File(context.filesDir, "Generator_AutoBackup.json")
            internalFile.writeText(jsonString, Charsets.UTF_8)

            // 2. Public Downloads folder via Scoped Storage
            FileDownloadHelper.saveToDownloads(
                context = context,
                fileName = "مولدتي_نسخة_احتياطية_تلقائية.json",
                mimeType = "application/json",
                contentBytes = jsonString.toByteArray(Charsets.UTF_8)
            )

            internalFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Checks if a persistent auto-backup file exists in phone memory (Downloads or internal files).
     */
    fun checkForAutoBackupFile(context: Context): String? {
        return try {
            // Check Downloads directory first (survives app uninstall)
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            val pubFile = File(downloadsDir, "مولدتي_نسخة_احتياطية_تلقائية.json")
            if (pubFile.exists() && pubFile.length() > 0) {
                return pubFile.readText(Charsets.UTF_8)
            }

            // Check internal filesDir
            val internalFile = File(context.filesDir, "Generator_AutoBackup.json")
            if (internalFile.exists() && internalFile.length() > 0) {
                return internalFile.readText(Charsets.UTF_8)
            }
            null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Parses JSON backup content and converts into domain entities with 100% preservation of all fields.
     */
    fun parseJsonBackup(jsonContent: String): BackupDataBundle {
        val root = JSONObject(jsonContent)
        
        val settingsObj = if (root.has("settings")) {
            val s = root.getJSONObject("settings")
            GeneratorSettings(
                id = 1,
                generatorName = s.optString("generatorName", "مولدة البركة"),
                ownerName = s.optString("ownerName", ""),
                phone = s.optString("phone", ""),
                address = s.optString("address", ""),
                defaultPricePerAmpere = s.optDouble("defaultPricePerAmpere", 10000.0),
                mastercardNumber = s.optString("mastercardNumber", "5324 8899 7766 5544"),
                isOnlineSyncEnabled = s.optBoolean("isOnlineSyncEnabled", true)
            )
        } else null

        // Parse Groups / Phases (الفيزات والمجموعات)
        val groupsList = mutableListOf<SubscriberGroup>()
        if (root.has("subscriberGroups")) {
            val arr = root.getJSONArray("subscriberGroups")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                groupsList.add(
                    SubscriberGroup(
                        id = o.optLong("id", 0),
                        groupName = o.getString("groupName"),
                        pricePerAmpere = o.optDouble("pricePerAmpere", 10000.0),
                        fixedFee = o.optDouble("fixedFee", 0.0),
                        notes = o.optString("notes", ""),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }

        val subscribersList = mutableListOf<Subscriber>()
        if (root.has("subscribers")) {
            val arr = root.getJSONArray("subscribers")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val groupName = o.optString("groupName", "فيز 1 (السكني العام)")
                val fixedFee = o.optDouble("fixedFee", 0.0)
                val circuitBreaker = o.optString("circuitBreakerNumber", "")
                subscribersList.add(
                    Subscriber(
                        id = o.optLong("id", 0),
                        subscriberCode = o.optString("subscriberCode", "SUB-$i"),
                        name = o.getString("name"),
                        phone = o.optString("phone", ""),
                        amperes = o.optDouble("amperes", 5.0),
                        defaultPricePerAmpere = o.optDouble("defaultPricePerAmpere", 10000.0),
                        groupName = groupName,
                        fixedFee = fixedFee,
                        circuitBreakerNumber = circuitBreaker,
                        isActive = o.optBoolean("isActive", true),
                        notes = o.optString("notes", ""),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Backward compatibility: If older backup file had no subscriberGroups array, reconstruct from subscribers list
        if (groupsList.isEmpty() && subscribersList.isNotEmpty()) {
            val distinctGroupNames = subscribersList.map { it.groupName }.filter { it.isNotBlank() }.distinct()
            distinctGroupNames.forEachIndexed { idx, grpName ->
                val matchingSub = subscribersList.firstOrNull { it.groupName == grpName }
                groupsList.add(
                    SubscriberGroup(
                        id = (idx + 1).toLong(),
                        groupName = grpName,
                        pricePerAmpere = matchingSub?.defaultPricePerAmpere ?: 10000.0,
                        fixedFee = matchingSub?.fixedFee ?: 0.0,
                        notes = "مستعادة من بيانات المشتركين"
                    )
                )
            }
        }

        val billsList = mutableListOf<Bill>()
        if (root.has("bills")) {
            val arr = root.getJSONArray("bills")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                billsList.add(
                    Bill(
                        id = o.optLong("id", 0),
                        billCode = o.optString("billCode", "INV-$i"),
                        subscriberId = o.getLong("subscriberId"),
                        subscriberName = o.optString("subscriberName", ""),
                        subscriberCode = o.optString("subscriberCode", ""),
                        month = o.optInt("month", 8),
                        year = o.optInt("year", 2026),
                        amperes = o.optDouble("amperes", 5.0),
                        pricePerAmpere = o.optDouble("pricePerAmpere", 10000.0),
                        fixedFee = o.optDouble("fixedFee", 0.0),
                        totalAmount = o.optDouble("totalAmount", 50000.0),
                        paidAmount = o.optDouble("paidAmount", 0.0),
                        remainingAmount = o.optDouble("remainingAmount", 50000.0),
                        status = o.optString("status", "UNPAID"),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }

        val paymentsList = mutableListOf<Payment>()
        if (root.has("payments")) {
            val arr = root.getJSONArray("payments")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                paymentsList.add(
                    Payment(
                        id = o.optLong("id", 0),
                        receiptCode = o.optString("receiptCode", "REC-$i"),
                        billId = o.getLong("billId"),
                        subscriberId = o.getLong("subscriberId"),
                        subscriberName = o.optString("subscriberName", ""),
                        amountPaid = o.getDouble("amountPaid"),
                        paymentDate = o.optLong("paymentDate", System.currentTimeMillis()),
                        collectedBy = o.optString("collectedBy", "الجابي"),
                        notes = o.optString("notes", "")
                    )
                )
            }
        }

        val expensesList = mutableListOf<Expense>()
        if (root.has("expenses")) {
            val arr = root.getJSONArray("expenses")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                expensesList.add(
                    Expense(
                        id = o.optLong("id", 0),
                        category = o.optString("category", "مصروفات أخرى"),
                        amount = o.getDouble("amount"),
                        expenseDate = o.optLong("expenseDate", System.currentTimeMillis()),
                        description = o.optString("description", ""),
                        notes = o.optString("notes", ""),
                        recordedBy = o.optString("recordedBy", "المدير")
                    )
                )
            }
        }

        val usersList = mutableListOf<UserAccount>()
        if (root.has("users")) {
            val arr = root.getJSONArray("users")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val emailVal = if (o.has("email") && !o.isNull("email")) o.optString("email", "").ifBlank { null } else null
                usersList.add(
                    UserAccount(
                        id = o.optLong("id", 0),
                        username = o.getString("username"),
                        name = o.optString("name", "مستخدم"),
                        pinCode = o.optString("pinCode", "1234"),
                        role = o.optString("role", "COLLECTOR"),
                        canDelete = o.optBoolean("canDelete", false),
                        canViewFinancials = o.optBoolean("canViewFinancials", false),
                        isActive = o.optBoolean("isActive", true),
                        email = emailVal
                    )
                )
            }
        }

        return BackupDataBundle(
            subscribers = subscribersList,
            subscriberGroups = groupsList,
            bills = billsList,
            payments = paymentsList,
            expenses = expensesList,
            users = usersList,
            settings = settingsObj
        )
    }
}

data class BackupDataBundle(
    val subscribers: List<Subscriber>,
    val subscriberGroups: List<SubscriberGroup>,
    val bills: List<Bill>,
    val payments: List<Payment>,
    val expenses: List<Expense>,
    val users: List<UserAccount>,
    val settings: GeneratorSettings?
)
