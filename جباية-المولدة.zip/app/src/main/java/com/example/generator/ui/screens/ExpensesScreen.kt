package com.example.generator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.generator.data.entity.Expense
import com.example.generator.ui.components.GlassCard
import com.example.generator.ui.components.Glossy3DIcon
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.PrintHelper
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

val EXPENSE_CATEGORIES = listOf(
    "الوقود والكاز",
    "الزيوت والدهن",
    "قطع الغيار",
    "الصيانة",
    "أجور العاملين",
    "الإيجار",
    "الكهرباء والماء",
    "الضرائب والرسوم",
    "مصروفات أخرى"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(viewModel: GeneratorViewModel) {
    val expenses by viewModel.expenses.collectAsState()
    val totalExpenses by viewModel.totalExpensesAmount.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }

    val filteredExpenses = remember(expenses, searchQuery) {
        if (searchQuery.isBlank()) {
            expenses
        } else {
            expenses.filter {
                it.description.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true) ||
                it.notes.contains(searchQuery, ignoreCase = true) ||
                it.recordedBy.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Glossy3DIcon(
                            imageRes = R.drawable.icon_3d_money_1787310364133,
                            contentDescription = null,
                            size = 36.dp,
                            glowColor = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("سجل المصروفات التشغيلية", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddExpenseDialog = true },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مصروف", modifier = Modifier.size(26.dp))
            }
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        MidnightCyberBackground {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Total Header Card
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    borderColor = MetallicGold.copy(alpha = 0.5f),
                    backgroundColor = Color(0xFF0F1B3E).copy(alpha = 0.78f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "إجمالي المصروفات الكلية",
                                fontSize = 13.sp,
                                color = TextMuted
                            )
                            Text(
                                text = if (currentUser?.role == "ADMIN" || currentUser?.canViewFinancials == true) PrintHelper.formatCurrency(totalExpenses) else "مخفي لخصوصية صاحب المولدة ****",
                                fontSize = if (currentUser?.role == "ADMIN" || currentUser?.canViewFinancials == true) 20.sp else 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MetallicGold
                            )
                        }
                        Glossy3DIcon(
                            imageRes = R.drawable.icon_3d_money_1787310364133,
                            contentDescription = null,
                            size = 44.dp,
                            glowColor = MetallicGold
                        )
                    }
                }

                // Search Bar for Expenses
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث بالمصروفات، النوع، الوصف...", fontSize = 13.sp, color = TextMuted) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = ElectricCyan
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "مسح",
                                    tint = TextWhitePrimary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = ElectricCyan.copy(alpha = 0.3f),
                        focusedTextColor = TextWhitePrimary,
                        unfocusedTextColor = TextWhitePrimary,
                        focusedContainerColor = Color(0xFF0F1B3E).copy(alpha = 0.6f),
                        unfocusedContainerColor = Color(0xFF0F1B3E).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )

                if (currentUser?.role != "ADMIN" && currentUser?.canViewFinancials != true) {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = ElectricCyan
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "خصوصية الماليّة والمصروفات",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextWhitePrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "سجل المصروفات التشغيلية وصافي الأرباح محصور بصاحب المولدة (المدير العام) لحماية الخصوصية المالية.",
                                color = TextCyanSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else if (filteredExpenses.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Receipt,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = TextMuted.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (searchQuery.isNotBlank()) "لا توجد نتائج بحث مطابقة" else "لم يتم تسجيل أي مصروفات حتى الآن",
                                color = TextCyanSecondary
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredExpenses) { expense ->
                            ExpenseItemCard(
                                expense = expense,
                                canDelete = currentUser?.role == "ADMIN",
                                onDelete = { expenseToDelete = expense }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddExpenseDialog) {
        AddExpenseDialog(
            onDismiss = { showAddExpenseDialog = false },
            onConfirm = { category, amount, description, notes ->
                viewModel.addExpense(category, amount, description, notes)
                showAddExpenseDialog = false
            }
        )
    }

    if (expenseToDelete != null) {
        AlertDialog(
            onDismissRequest = { expenseToDelete = null },
            title = { Text("حذف المصروف") },
            text = { Text("هل أنت تأكد من حذف المصروف \"${expenseToDelete?.description}\" بالمبلغ ${PrintHelper.formatCurrency(expenseToDelete?.amount ?: 0.0)}؟") },
            confirmButton = {
                Button(
                    onClick = {
                        expenseToDelete?.id?.let { viewModel.deleteExpense(it) }
                        expenseToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { expenseToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun ExpenseItemCard(
    expense: Expense,
    canDelete: Boolean,
    onDelete: () -> Unit
) {
    val dateFormat = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar"))
    val dateStr = dateFormat.format(Date(expense.expenseDate))

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        borderColor = ElectricCyan.copy(alpha = 0.3f),
        backgroundColor = Color(0xFF0F1B3E).copy(alpha = 0.7f)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Surface(
                    shape = CircleShape,
                    color = MetallicGold.copy(alpha = 0.18f),
                    contentColor = MetallicGold
                ) {
                    Box(
                        modifier = Modifier.size(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (expense.category) {
                                "الوقود والكاز" -> Icons.Default.LocalGasStation
                                "الصيانة", "قطع الغيار" -> Icons.Default.Build
                                "أجور العاملين" -> Icons.Default.Badge
                                else -> Icons.Default.Payments
                            },
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MetallicGold
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = expense.category,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = expense.description,
                        fontSize = 13.sp,
                        color = TextCyanSecondary
                    )
                    Text(
                        text = "$dateStr • المسجل: ${expense.recordedBy}",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = PrintHelper.formatCurrency(expense.amount),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MetallicGold
                )
                if (canDelete) {
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف المصروف",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onConfirm: (category: String, amount: Double, description: String, notes: String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(EXPENSE_CATEGORIES[0]) }
    var amountText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل مصروف جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("نوع المصروف") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        EXPENSE_CATEGORIES.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category) },
                                onClick = {
                                    selectedCategory = category
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("المبلغ (د.ع)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("وصف المصروف") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات إضافية (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    onConfirm(selectedCategory, amount, description, notes)
                }
            ) {
                Text("حفظ المصروف")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

