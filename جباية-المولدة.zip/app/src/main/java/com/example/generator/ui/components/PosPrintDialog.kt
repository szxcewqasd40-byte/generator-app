package com.example.generator.ui.components

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.GeneratorSettings
import com.example.generator.data.entity.Payment
import com.example.generator.util.BluetoothPosDevice
import com.example.generator.util.PosPaperSize
import com.example.generator.util.PosPrinterHelper
import kotlinx.coroutines.launch

sealed class PosPrintTarget {
    data class SingleBill(val bill: Bill) : PosPrintTarget()
    data class SinglePayment(val payment: Payment, val bill: Bill?) : PosPrintTarget()
    data class DailySummary(val payments: List<Payment>, val dateLabel: String) : PosPrintTarget()
    object TestPrint : PosPrintTarget()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosPrintDialog(
    target: PosPrintTarget,
    settings: GeneratorSettings?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedPaperSize by remember { mutableStateOf(PosPrinterHelper.getSavedPaperSize(context)) }
    var pairedDevices by remember { mutableStateOf<List<BluetoothPosDevice>>(emptyList()) }
    var selectedDevice by remember { mutableStateOf<BluetoothPosDevice?>(PosPrinterHelper.getLastSavedDevice(context)) }
    var isPrinting by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf<Boolean?>(null) }
    var hasBtPermission by remember { mutableStateOf(PosPrinterHelper.hasBluetoothPermissions(context)) }

    // Launcher for Bluetooth Permissions (Android 12+)
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        hasBtPermission = granted
        if (granted) {
            pairedDevices = PosPrinterHelper.getPairedBluetoothDevices(context)
            if (selectedDevice == null && pairedDevices.isNotEmpty()) {
                selectedDevice = pairedDevices.first()
            }
        } else {
            Toast.makeText(context, "يرجى منح إذن البلوتوث للاتصال بطابعات POS", Toast.LENGTH_LONG).show()
        }
    }

    // Refresh paired devices list
    fun refreshDevices() {
        if (hasBtPermission) {
            pairedDevices = PosPrinterHelper.getPairedBluetoothDevices(context)
            if (selectedDevice == null || pairedDevices.none { it.address == selectedDevice?.address }) {
                selectedDevice = pairedDevices.firstOrNull()
            }
        }
    }

    LaunchedEffect(hasBtPermission) {
        if (hasBtPermission) {
            refreshDevices()
        }
    }

    // Render receipt bitmap based on target & paper size
    val receiptBitmap by remember(target, settings, selectedPaperSize) {
        derivedStateOf {
            when (target) {
                is PosPrintTarget.SingleBill -> {
                    PosPrinterHelper.generateBillReceiptBitmap(target.bill, settings, selectedPaperSize)
                }
                is PosPrintTarget.SinglePayment -> {
                    PosPrinterHelper.generatePaymentReceiptBitmap(target.payment, target.bill, settings, selectedPaperSize)
                }
                is PosPrintTarget.DailySummary -> {
                    PosPrinterHelper.generateDailySummaryReceiptBitmap(target.payments, target.dateLabel, settings, selectedPaperSize)
                }
                is PosPrintTarget.TestPrint -> {
                    PosPrinterHelper.generateTestReceiptBitmap(settings, selectedPaperSize)
                }
            }
        }
    }

    val dialogTitle = when (target) {
        is PosPrintTarget.SingleBill -> "طباعة فاتورة عبر أجهزة POS 🖨️"
        is PosPrintTarget.SinglePayment -> "طباعة إيصال دفع POS 🖨️"
        is PosPrintTarget.DailySummary -> "طباعة تقرير الجباية POS 📊"
        is PosPrintTarget.TestPrint -> "فحص وتجربة طابعة POS 🖨️"
    }

    Dialog(
        onDismissRequest = { if (!isPrinting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Print, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(dialogTitle, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss, enabled = !isPrinting) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    )
                }
            ) { paddingValues ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    // 1. Paper Size Selector
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("مقاس رول ورق الطابعة الحرارية (POS):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                PosPaperSize.values().forEach { size ->
                                    val isSelected = selectedPaperSize == size
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.5.dp,
                                            if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                selectedPaperSize = size
                                                PosPrinterHelper.savePaperSize(context, size)
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = {
                                                    selectedPaperSize = size
                                                    PosPrinterHelper.savePaperSize(context, size)
                                                }
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(size.labelAr, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 2. Bluetooth POS Printer Selection
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Color(0xFF0284C7))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("طابعات POS عبر البلوتوث (Bluetooth):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                IconButton(
                                    onClick = {
                                        if (hasBtPermission) {
                                            refreshDevices()
                                        } else {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                                permissionLauncher.launch(
                                                    arrayOf(
                                                        Manifest.permission.BLUETOOTH_CONNECT,
                                                        Manifest.permission.BLUETOOTH_SCAN
                                                    )
                                                )
                                            } else {
                                                permissionLauncher.launch(
                                                    arrayOf(
                                                        Manifest.permission.BLUETOOTH,
                                                        Manifest.permission.BLUETOOTH_ADMIN
                                                    )
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = MaterialTheme.colorScheme.primary)
                                }
                            }

                            if (!hasBtPermission) {
                                Button(
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                            permissionLauncher.launch(
                                                arrayOf(
                                                    Manifest.permission.BLUETOOTH_CONNECT,
                                                    Manifest.permission.BLUETOOTH_SCAN
                                                )
                                            )
                                        } else {
                                            permissionLauncher.launch(
                                                arrayOf(
                                                    Manifest.permission.BLUETOOTH,
                                                    Manifest.permission.BLUETOOTH_ADMIN
                                                )
                                            )
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                ) {
                                    Icon(Icons.Default.BluetoothSearching, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("منح إذن البلوتوث للبحث عن الطابعات")
                                }
                            } else if (pairedDevices.isEmpty()) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                        .padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "لا توجد طابعة POS مقترنة حالياً بالبلوتوث.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    OutlinedButton(
                                        onClick = {
                                            try {
                                                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "يرجى فتح إعدادات البلوتوث واقتران الطابعة", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.SettingsBluetooth, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("فتح إعدادات البلوتوث لربط طابعة POS", fontSize = 12.sp)
                                    }
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    pairedDevices.forEach { dev ->
                                        val isSelected = selectedDevice?.address == dev.address
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    selectedDevice = dev
                                                    PosPrinterHelper.saveLastDevice(context, dev)
                                                }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                    RadioButton(
                                                        selected = isSelected,
                                                        onClick = {
                                                            selectedDevice = dev
                                                            PosPrinterHelper.saveLastDevice(context, dev)
                                                        }
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Column {
                                                        Text(dev.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                        Text(dev.address, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                }

                                                if (isSelected) {
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.primary,
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "الطابعة المختارة",
                                                            color = Color.White,
                                                            fontSize = 10.sp,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Direct Bluetooth Print Button
                                Button(
                                    onClick = {
                                        if (selectedDevice == null) {
                                            Toast.makeText(context, "يرجى اختيار طابعة POS أولاً", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        isPrinting = true
                                        statusMessage = "جاري الاتصال بطابعة ${selectedDevice?.name} وإرسال أمر الطباعة..."
                                        isSuccess = null

                                        coroutineScope.launch {
                                            val result = PosPrinterHelper.printBitmapViaBluetooth(
                                                selectedDevice!!.address,
                                                receiptBitmap
                                            )
                                            isPrinting = false
                                            if (result.isSuccess) {
                                                isSuccess = true
                                                statusMessage = "تمت الطباعة بنجاح عبر طابعة POS! ✅"
                                            } else {
                                                isSuccess = false
                                                statusMessage = result.exceptionOrNull()?.message ?: "فشل الاتصال بالطابعة"
                                            }
                                        }
                                    },
                                    enabled = !isPrinting && selectedDevice != null,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                                ) {
                                    if (isPrinting) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("جاري الطباعة...", fontSize = 13.sp)
                                    } else {
                                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("طباعة فورية عبر بلوتوث POS 🖨️", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Status Banner
                            if (statusMessage != null) {
                                Surface(
                                    color = if (isSuccess == true) Color(0xFF16A34A).copy(alpha = 0.12f) else if (isSuccess == false) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (isSuccess == true) Icons.Default.CheckCircle else if (isSuccess == false) Icons.Default.Error else Icons.Default.Info,
                                            contentDescription = null,
                                            tint = if (isSuccess == true) Color(0xFF16A34A) else if (isSuccess == false) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = statusMessage!!,
                                            fontSize = 12.sp,
                                            color = if (isSuccess == true) Color(0xFF16A34A) else if (isSuccess == false) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 3. Alternative Printing & POS Terminals
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("طرق طباعة إضافية وأجهزة POS الذكية:", fontWeight = FontWeight.Bold, fontSize = 12.sp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // Built-in POS (Sunmi, PAX, Android Print Spooler)
                                FilledTonalButton(
                                    onClick = {
                                        val jobName = when (target) {
                                            is PosPrintTarget.SingleBill -> "فاتورة_${target.bill.billCode}"
                                            is PosPrintTarget.SinglePayment -> "إيصال_${target.payment.receiptCode}"
                                            is PosPrintTarget.DailySummary -> "تقرير_الجباية"
                                            is PosPrintTarget.TestPrint -> "فحص_POS"
                                        }
                                        PosPrinterHelper.printBitmapViaAndroidSystem(context, receiptBitmap, jobName)
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Devices, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("طابعة POS المدمجة / أندرويد", fontSize = 11.sp, textAlign = TextAlign.Center)
                                }

                                // External POS App (RawBT / Bluetooth Print)
                                OutlinedButton(
                                    onClick = {
                                        PosPrinterHelper.shareReceiptImageToPosApp(context, receiptBitmap)
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.SendToMobile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تطبيق طابعة خارجي (RawBT)", fontSize = 11.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }

                    // 4. Live Receipt Preview
                    Text("معاينة الإيصال الحراري الفعلي (Thermal Receipt Preview):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = receiptBitmap.asImageBitmap(),
                                contentDescription = "معاينة الفاتورة الحرارية",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}
