package com.example.generator.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.GeneratorSettings
import com.example.generator.data.entity.Subscriber
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.PrintHelper
import java.util.Locale

/**
 * دمج وتوحيد خيارات الدفع والطباعة في نافذة واحدة سريعة مع لوحة مفاتيح رقمية سريعة:
 * - دفع كامل الفاتورة أو جزء منها
 * - لوحة أرقام سريعة لتسديد مبالغ دقيقة بسهولة ميدانية
 * - خيارات فورية: طباعة حرارية POS مباشرة، إرسال وصل عبر واتساب، أو طباعة النظام
 */
@Composable
fun SubscriberQuickPaymentDialog(
    subscriber: Subscriber,
    bills: List<Bill>,
    settings: GeneratorSettings?,
    viewModel: GeneratorViewModel,
    onDismiss: () -> Unit,
    onPrintPos: (Bill) -> Unit,
    targetMonth: Int = 0,
    targetYear: Int = 0
) {
    val context = LocalContext.current
    val cal = java.util.Calendar.getInstance()
    val activeMonth = if (targetMonth > 0) targetMonth else (cal.get(java.util.Calendar.MONTH) + 1)
    val activeYear = if (targetYear > 0) targetYear else cal.get(java.util.Calendar.YEAR)

    val subBills = if (targetMonth > 0) {
        bills.filter { it.subscriberId == subscriber.id && it.month == targetMonth && (targetYear == 0 || it.year == targetYear) }
    } else {
        bills.filter { it.subscriberId == subscriber.id }
    }

    val totalRemaining = subBills.sumOf { it.remainingAmount }
    val totalPaid = subBills.sumOf { it.paidAmount }
    val totalBillAmount = if (subBills.isNotEmpty()) subBills.sumOf { it.totalAmount } else (subscriber.amperes * subscriber.defaultPricePerAmpere + subscriber.fixedFee)
    val status = SubscriberPaymentStatus.calculate(subBills)

    var partialAmountInput by remember {
        val defaultAmt = if (totalRemaining > 0) (totalRemaining / 2).toInt() else (totalBillAmount / 2).toInt()
        mutableStateOf(defaultAmt.toString())
    }
    var showPartialInput by remember { mutableStateOf(false) }
    var notesInput by remember { mutableStateOf("") }
    var showConfirmRevertDialog by remember { mutableStateOf(false) }

    // Representing current or target bill
    val currentBill = subBills.firstOrNull() ?: run {
        val total = (subscriber.amperes * subscriber.defaultPricePerAmpere) + subscriber.fixedFee
        val billCode = "INV-$activeYear${String.format(Locale.US, "%02d", activeMonth)}-${subscriber.id}"
        Bill(
            billCode = billCode,
            subscriberId = subscriber.id,
            subscriberName = subscriber.name,
            subscriberCode = subscriber.subscriberCode,
            month = activeMonth,
            year = activeYear,
            amperes = subscriber.amperes,
            pricePerAmpere = subscriber.defaultPricePerAmpere,
            fixedFee = subscriber.fixedFee,
            totalAmount = total,
            paidAmount = 0.0,
            remainingAmount = total,
            status = "UNPAID"
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val isDark = androidx.compose.foundation.isSystemInDarkTheme()
                val statusBg = status.getBackgroundColor(isDark)
                val statusBorder = status.getBorderColor(isDark)
                val statusText = status.getTextColor(isDark)
                val statusIndicator = status.getIndicatorColor(isDark)

                // Header: Status Icon & Title
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(statusBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = status.icon,
                        contentDescription = null,
                        tint = statusIndicator,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = subscriber.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                val breakerText = if (subscriber.circuitBreakerNumber.isNotBlank()) " • ⚡ جوزة: ${subscriber.circuitBreakerNumber}" else ""
                Text(
                    text = "كود: ${subscriber.subscriberCode} • ${subscriber.groupName} (${String.format(Locale.US, "%.1f", subscriber.amperes)} أمبير)$breakerText",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Status Banner with Dynamic Color & Amounts
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusBg,
                    border = BorderStroke(1.2.dp, statusBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = status.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusText
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("إجمالي الفاتورة", fontSize = 10.sp, color = statusText.copy(alpha = 0.8f))
                                Text(PrintHelper.formatCurrency(totalBillAmount), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = statusText)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("المدفوع", fontSize = 10.sp, color = statusText.copy(alpha = 0.8f))
                                Text(PrintHelper.formatCurrency(totalPaid), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (isDark) Color(0xFF4ADE80) else Color(0xFF15803D))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("المتبقي بذمته", fontSize = 10.sp, color = statusText.copy(alpha = 0.8f))
                                Text(PrintHelper.formatCurrency(totalRemaining), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (totalRemaining > 0) (if (isDark) Color(0xFFF87171) else Color(0xFFB91C1C)) else (if (isDark) Color(0xFF4ADE80) else Color(0xFF15803D)))
                            }
                        }
                        val address = settings?.address?.takeIf { it.isNotBlank() }
                        if (address != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "📍 $address",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color.White else Color(0xFF0F172A),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action 1: FULL PAYMENT BUTTON (سداد كامل الفاتورة)
                if (totalRemaining > 0 || subBills.isEmpty()) {
                    val payLabel = if (totalRemaining > 0) {
                        "سداد كامل الفاتورة (${PrintHelper.formatCurrency(totalRemaining)}) 🟢"
                    } else {
                        "إصدار وسداد شهر $activeMonth / $activeYear بالكامل (${PrintHelper.formatCurrency(totalBillAmount)}) 🟢"
                    }
                    Button(
                        onClick = {
                            viewModel.paySubscriberInFull(
                                subscriberId = subscriber.id,
                                notes = notesInput,
                                targetMonth = activeMonth,
                                targetYear = activeYear
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = payLabel,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Action 2: PARTIAL PAYMENT (دفع جزئي مخصص)
                    if (!showPartialInput) {
                        OutlinedButton(
                            onClick = { showPartialInput = true },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFD97706)
                            ),
                            border = BorderStroke(1.2.dp, Color(0xFFD97706)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تسجيل سداد جزئي مخصص 🟡", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7).copy(alpha = 0.7f)),
                            border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "تحديد المبلغ المسدد جزئياً:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF78350F)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = partialAmountInput,
                                    onValueChange = { partialAmountInput = it },
                                    label = { Text("المبلغ الواصل") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                // Quick Numeric Preset Keypad / Chips (5,000, 10,000, 15,000, 20,000, 25,000, 50,000)
                                Text("مبالغ سريعة:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF78350F))
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    listOf(5000, 10000, 15000, 20000, 25000).forEach { preset ->
                                        SuggestionChip(
                                            onClick = { partialAmountInput = preset.toString() },
                                            label = { Text("${preset / 1000} ألف", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = {
                                        val amt = partialAmountInput.toDoubleOrNull() ?: 0.0
                                        if (amt > 0) {
                                            viewModel.recordSubscriberPartialPayment(
                                                subscriberId = subscriber.id,
                                                amount = amt,
                                                notes = notesInput,
                                                targetMonth = activeMonth,
                                                targetYear = activeYear
                                            )
                                            onDismiss()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تأكيد الدفع الجزئي (تحويل للأصفر 🟡)")
                                }
                            }
                        }
                    }
                }

                // Action 3: REVERT PAYMENT (تراجع عن السداد)
                if (totalPaid > 0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showConfirmRevertDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFFDC2626)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تراجع عن السداد وإلغاء الدفعات 🔴", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // Unified Print & Share Quick Options (خيارات الطباعة والمشاركة المباشرة)
                Text(
                    text = "خيارات الطباعة والمشاركة الفورية للوصل",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Thermal POS
                    FilledTonalButton(
                        onClick = {
                            onPrintPos(currentBill)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF0D9488).copy(alpha = 0.15f), contentColor = Color(0xFF0D9488)),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("طباعة POS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // WhatsApp
                    FilledTonalButton(
                        onClick = {
                            if (subBills.isNotEmpty()) {
                                PrintHelper.shareBillWhatsApp(context, subBills.first(), settings)
                            } else {
                                val text = "مرحباً ${subscriber.name}، نود إعلامكم بحساب اشتراك المولدة: ${subscriber.amperes} أمبير بقيمة ${PrintHelper.formatCurrency(totalBillAmount)}."
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    data = Uri.parse("https://api.whatsapp.com/send?phone=${subscriber.phone}&text=${Uri.encode(text)}")
                                }
                                try { context.startActivity(intent) } catch (e: Exception) { /* ignore */ }
                            }
                        },
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF16A34A).copy(alpha = 0.15f), contentColor = Color(0xFF16A34A)),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Call
                    if (subscriber.phone.isNotBlank()) {
                        FilledTonalButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${subscriber.phone}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF0284C7).copy(alpha = 0.15f), contentColor = Color(0xFF0284C7)),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("اتصال", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إغلاق", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    // Confirmation Alert for Reverting Payments
    if (showConfirmRevertDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmRevertDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626)) },
            title = { Text("تأكيد التراجع عن السداد") },
            text = {
                Text("هل أنت متأكد من إلغاء سداد دفعات المشترك (${subscriber.name})؟ ستعود الفاتورة كـ غير مسددة بالكامل (حمراء 🔴) وسيتم تحديث إجمالي المقبوضات فوراً.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.revertSubscriberAllPayments(
                            subscriberId = subscriber.id,
                            targetMonth = activeMonth,
                            targetYear = activeYear
                        )
                        showConfirmRevertDialog = false
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("نعم، إلغاء السداد فوراً")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showConfirmRevertDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
