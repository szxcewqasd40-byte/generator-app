package com.example.generator.util

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

data class UserAuthProfile(
    val uid: String,
    val displayName: String,
    val email: String? = null,
    val phoneNumber: String? = null,
    val photoUrl: String? = null,
    val provider: String, // "GOOGLE", "PHONE", "GUEST"
    val registrationDateTimestamp: Long
)

enum class LockType {
    NONE,
    PIN,
    BIOMETRIC,
    PATTERN
}

/**
 * Manages User Authentication (Google One-Tap / Phone Auth / Fast Start),
 * 7-Day Free Trial Tracking, and Optional Security App Locks (PIN / Biometric / Pattern).
 */
class AuthAndSecurityManager(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "generator_auth_security_prefs"
        private const val KEY_IS_LOGGED_IN = "key_is_logged_in"
        private const val KEY_USER_UID = "key_user_uid"
        private const val KEY_DISPLAY_NAME = "key_display_name"
        private const val KEY_EMAIL = "key_email"
        private const val KEY_PHONE = "key_phone"
        private const val KEY_PHOTO_URL = "key_photo_url"
        private const val KEY_AUTH_PROVIDER = "key_auth_provider"
        private const val KEY_REGISTRATION_TIMESTAMP = "key_registration_timestamp"

        // App Lock Preferences
        private const val KEY_APP_LOCK_ENABLED = "key_app_lock_enabled"
        private const val KEY_LOCK_TYPE = "key_lock_type" // PIN, BIOMETRIC, PATTERN
        private const val KEY_SECURITY_PIN = "key_security_pin"
        private const val KEY_SECURITY_PATTERN = "key_security_pattern"

        const val TRIAL_DURATION_DAYS = 7
        const val TRIAL_DURATION_MILLIS = TRIAL_DURATION_DAYS * 24L * 60L * 60L * 1000L
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Current logged in user profile
    private val _currentUserProfile = MutableStateFlow<UserAuthProfile?>(loadUserProfile())
    val currentUserProfile: StateFlow<UserAuthProfile?> = _currentUserProfile.asStateFlow()

    // App Lock Preferences
    private val _isAppLockEnabled = MutableStateFlow(prefs.getBoolean(KEY_APP_LOCK_ENABLED, false))
    val isAppLockEnabled: StateFlow<Boolean> = _isAppLockEnabled.asStateFlow()

    private val _lockType = MutableStateFlow(
        try {
            LockType.valueOf(prefs.getString(KEY_LOCK_TYPE, LockType.PIN.name) ?: LockType.PIN.name)
        } catch (e: Exception) {
            LockType.PIN
        }
    )
    val lockType: StateFlow<LockType> = _lockType.asStateFlow()

    private val _securityPin = MutableStateFlow(prefs.getString(KEY_SECURITY_PIN, "1234") ?: "1234")
    val securityPin: StateFlow<String> = _securityPin.asStateFlow()

    private val _securityPattern = MutableStateFlow(prefs.getString(KEY_SECURITY_PATTERN, "0,1,2") ?: "0,1,2")
    val securityPattern: StateFlow<String> = _securityPattern.asStateFlow()

    private fun loadUserProfile(): UserAuthProfile? {
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        if (!isLoggedIn) return null

        val uid = prefs.getString(KEY_USER_UID, null) ?: return null
        val displayName = prefs.getString(KEY_DISPLAY_NAME, "صاحب المولدة") ?: "صاحب المولدة"
        val email = prefs.getString(KEY_EMAIL, null)
        val phone = prefs.getString(KEY_PHONE, null)
        val photoUrl = prefs.getString(KEY_PHOTO_URL, null)
        val provider = prefs.getString(KEY_AUTH_PROVIDER, "GOOGLE") ?: "GOOGLE"
        val regTime = prefs.getLong(KEY_REGISTRATION_TIMESTAMP, System.currentTimeMillis())

        return UserAuthProfile(
            uid = uid,
            displayName = displayName,
            email = email,
            phoneNumber = phone,
            photoUrl = photoUrl,
            provider = provider,
            registrationDateTimestamp = regTime
        )
    }

    /**
     * Sign In with Google Account (One-Tap / Fast Single-Click)
     */
    fun signInWithGoogle(displayName: String, email: String, photoUrl: String? = null, uid: String? = null): UserAuthProfile {
        val finalUid = uid ?: "google_${UUID.randomUUID().toString().take(12)}"
        val regTime = prefs.getLong(KEY_REGISTRATION_TIMESTAMP, 0L).let {
            if (it > 0L) it else System.currentTimeMillis()
        }

        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_USER_UID, finalUid)
            .putString(KEY_DISPLAY_NAME, displayName)
            .putString(KEY_EMAIL, email)
            .putString(KEY_PHOTO_URL, photoUrl)
            .putString(KEY_AUTH_PROVIDER, "GOOGLE")
            .putLong(KEY_REGISTRATION_TIMESTAMP, regTime)
            .apply()

        val profile = UserAuthProfile(
            uid = finalUid,
            displayName = displayName,
            email = email,
            photoUrl = photoUrl,
            provider = "GOOGLE",
            registrationDateTimestamp = regTime
        )
        _currentUserProfile.value = profile
        return profile
    }

    /**
     * Sign In with Phone Number & SMS Code
     */
    fun signInWithPhone(phoneNumber: String, displayName: String = "صاحب المولدة", uid: String? = null): UserAuthProfile {
        val finalUid = uid ?: "phone_${phoneNumber.filter { it.isDigit() }.takeLast(10)}"
        val regTime = prefs.getLong(KEY_REGISTRATION_TIMESTAMP, 0L).let {
            if (it > 0L) it else System.currentTimeMillis()
        }

        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_USER_UID, finalUid)
            .putString(KEY_DISPLAY_NAME, displayName)
            .putString(KEY_PHONE, phoneNumber)
            .putString(KEY_AUTH_PROVIDER, "PHONE")
            .putLong(KEY_REGISTRATION_TIMESTAMP, regTime)
            .apply()

        val profile = UserAuthProfile(
            uid = finalUid,
            displayName = displayName,
            phoneNumber = phoneNumber,
            provider = "PHONE",
            registrationDateTimestamp = regTime
        )
        _currentUserProfile.value = profile
        return profile
    }

    /**
     * Calculate remaining free trial days (7 days free trial)
     * Returns:
     * - positive number (1..7): days remaining in active free trial
     * - 0: trial expired today or in grace
     * - negative number: trial has expired
     */
    fun getRemainingTrialDays(): Int {
        val profile = _currentUserProfile.value ?: return TRIAL_DURATION_DAYS
        val regTime = profile.registrationDateTimestamp
        val now = System.currentTimeMillis()
        val elapsedMillis = now - regTime

        val remainingMillis = TRIAL_DURATION_MILLIS - elapsedMillis
        if (remainingMillis <= 0) return 0

        val remainingDays = (remainingMillis / (24L * 60L * 60L * 1000L)).toInt() + 1
        return remainingDays.coerceIn(0, TRIAL_DURATION_DAYS)
    }

    fun isTrialActive(): Boolean {
        return getRemainingTrialDays() > 0
    }

    /**
     * App Lock Settings
     */
    fun setAppLockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_APP_LOCK_ENABLED, enabled).apply()
        _isAppLockEnabled.value = enabled
    }

    fun setLockType(type: LockType) {
        prefs.edit().putString(KEY_LOCK_TYPE, type.name).apply()
        _lockType.value = type
    }

    fun setSecurityPin(pin: String) {
        prefs.edit().putString(KEY_SECURITY_PIN, pin).apply()
        _securityPin.value = pin
    }

    fun setSecurityPattern(pattern: String) {
        prefs.edit().putString(KEY_SECURITY_PATTERN, pattern).apply()
        _securityPattern.value = pattern
    }

    fun signOut() {
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .remove(KEY_USER_UID)
            .remove(KEY_DISPLAY_NAME)
            .remove(KEY_EMAIL)
            .remove(KEY_PHONE)
            .remove(KEY_PHOTO_URL)
            .apply()
        _currentUserProfile.value = null
    }
}
