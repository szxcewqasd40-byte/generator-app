package com.example.generator.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.GeneratorSettings
import com.example.generator.data.entity.Subscriber
import com.example.generator.util.PrintHelper
import java.text.SimpleDateFormat
import java.util.*

/**
 * نافذة السجل السنوي الشامل وخريطة الدفع لـ 12 شهراً للمشترك:
 * - تتيح اختيار أي سنة (ديناميكية مفتوحة دون حدود).
 * - تعرض خريطة بيانية لجميع أشهر السنة (12 شهر) مع حالة الدفع (مدفوع أخضر / غير مدفوع أحمر / دين أصفر).
 * - توضح تفاصيل كل شهر: تاريخ الدفع، المبلغ المطلوب، المبلغ المسدد، المتبقي كدين.
 * - أزرار طباعة ومشاركة السجل السنوي.
 */
@Composable
fun SubscriberAnnualHistoryDialog(
    subscriber: Subscriber,
    allBills: List<Bill>,
    settings: GeneratorSettings?,
    initialYear: Int = Calendar.getInstance().get(Calendar.YEAR),
    onDismiss: () -> Unit,
    onQuickPayMonth: (month: Int, year: Int) -> Unit
) {
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()

    val currentRealYear = Calendar.getInstance().get(Calendar.YEAR)
    var selectedYear by remember { mutableIntStateOf(initialYear) }
    var yearDropdownExpanded by remember { mutableStateOf(false) }

    // Dynamic Year Range: Starts from earliest bill or 2024 up to currentYear + 15 (fully extensible)
    val earliestYear = (allBills.map { it.year } + listOf(2024, currentRealYear)).minOrNull() ?: 2024
    val latestYear = maxOf(currentRealYear + 15, selectedYear + 5)
    val availableYears = (earliestYear..latestYear).toList()

    // Filter bills for selected year
    val yearBills = remember(allBills, selectedYear) {
        allBills.filter { it.subscriberId == subscriber.id && it.year == selectedYear }
    }

    val monthNames = listOf(
        1 to "كانون 2 (1)",
        2 to "شباط (2)",
        3 to "آذار (3)",
        4 to "نيسان (4)",
        5 to "أيار (5)",
        6 to "حزيران (6)",
        7 to "تموز (7)",
        8 to "آب (8)",
        9 to "أيلول (9)",
        10 to "تشرين 1 (10)",
        11 to "تشرين 2 (11)",
        12 to "كانون 1 (12)"
    )

    // Summary calculations for the selected year
    val totalYearDue = yearBills.sumOf { it.totalAmount }
    val totalYearPaid = yearBills.sumOf { it.paidAmount }
    val totalYearRemaining = yearBills.sumOf { it.remainingAmount }
    val paidMonthsCount = yearBills.count { it.remainingAmount <= 0.0 && it.paidAmount > 0.0 }
    val unpaidMonthsCount = (1..12).count { m ->
        val bill = yearBills.find { it.month == m }
        bill != null && bill.remainingAmount > 0.0
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "السجل السنوي: ${subscriber.name}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "كود: ${subscriber.subscriberCode} • ${subscriber.groupName} (${subscriber.amperes} A)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Dynamic Year Selector Dropdown
                Box {
                    OutlinedButton(
                        onClick = { yearDropdownExpanded = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "سنة $selectedYear", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                    }

                    DropdownMenu(
                        expanded = yearDropdownExpanded,
                        onDismissRequest = { yearDropdownExpanded = false }
                    ) {
                        availableYears.forEach { yr ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (yr == currentRealYear) "سنة $yr (السنة الحالية)" else "سنة $yr",
                                        fontWeight = if (yr == selectedYear) FontWeight.Bold else FontWeight.Normal,
                                        color = if (yr == selectedYear) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                onClick = {
                                    selectedYear = yr
                                    yearDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Annual Summary Card
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9),
                    border = BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("أشهر مسددة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$paidMonthsCount من 12", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color(0xFF4ADE80) else Color(0xFF16A34A))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("إجمالي المسدد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(PrintHelper.formatCurrency(totalYearPaid), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color(0xFF4ADE80) else Color(0xFF16A34A))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ديون السنة ($selectedYear)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(PrintHelper.formatCurrency(totalYearRemaining), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (totalYearRemaining > 0) (if (isDark) Color(0xFFF87171) else Color(0xFFDC2626)) else (if (isDark) Color(0xFF4ADE80) else Color(0xFF16A34A)))
                        }
                    }
                    val address = settings?.address?.takeIf { it.isNotBlank() }
                    if (address != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "📍 $address",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "خريطة الدفع السنوية (12 شهراً لعام $selectedYear):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 12 Months Grid (2 columns x 6 rows)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in 1..12 step 2) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val month1 = i
                            val month2 = i + 1

                            AnnualMonthItem(
                                month = month1,
                                monthName = monthNames[month1 - 1].second,
                                year = selectedYear,
                                bill = yearBills.find { it.month == month1 },
                                isDark = isDark,
                                onQuickPay = { onQuickPayMonth(month1, selectedYear) },
                                modifier = Modifier.weight(1f)
                            )

                            AnnualMonthItem(
                                month = month2,
                                monthName = monthNames[month2 - 1].second,
                                year = selectedYear,
                                bill = yearBills.find { it.month == month2 },
                                isDark = isDark,
                                onQuickPay = { onQuickPayMonth(month2, selectedYear) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Actions: Print & Share Full Annual Statement
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            PrintHelper.printSubscriberStatementAndroid(
                                context,
                                subscriber.name,
                                subscriber.subscriberCode,
                                yearBills,
                                settings
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("طباعة كشف سنة $selectedYear", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            PrintHelper.shareSubscriberStatementWhatsApp(
                                context,
                                subscriber.name,
                                subscriber.subscriberCode,
                                yearBills,
                                settings
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مشاركة واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
private fun AnnualMonthItem(
    month: Int,
    monthName: String,
    year: Int,
    bill: Bill?,
    isDark: Boolean,
    onQuickPay: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hasBill = bill != null
    val isPaid = hasBill && bill!!.remainingAmount <= 0.0 && bill.paidAmount > 0.0
    val isPartial = hasBill && bill!!.paidAmount > 0.0 && bill.remainingAmount > 0.0
    val isUnpaid = hasBill && bill!!.paidAmount == 0.0

    val cardBg = when {
        isPaid -> if (isDark) Color(0xFF14532D).copy(alpha = 0.35f) else Color(0xFFE8F5E9)
        isPartial -> if (isDark) Color(0xFF78350F).copy(alpha = 0.35f) else Color(0xFFFFFBEB)
        isUnpaid -> if (isDark) Color(0xFF7F1D1D).copy(alpha = 0.35f) else Color(0xFFFEF2F2)
        else -> if (isDark) Color(0xFF1E293B).copy(alpha = 0.4f) else Color(0xFFF8FAFC)
    }

    val cardBorder = when {
        isPaid -> if (isDark) Color(0xFF166534) else Color(0xFFA5D6A7)
        isPartial -> if (isDark) Color(0xFF92400E) else Color(0xFFFDE68A)
        isUnpaid -> if (isDark) Color(0xFF991B1B) else Color(0xFFFECACA)
        else -> if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
    }

    val statusTitle = when {
        isPaid -> "مسدد 🟢"
        isPartial -> "دين جزئي 🟡"
        isUnpaid -> "غير مسدد 🔴"
        else -> "لم تُصدر ⚪"
    }

    val statusTextColor = when {
        isPaid -> if (isDark) Color(0xFFBBF7D0) else Color(0xFF1B5E20)
        isPartial -> if (isDark) Color(0xFFFDE68A) else Color(0xFF92400E)
        isUnpaid -> if (isDark) Color(0xFFFECACA) else Color(0xFF991B1B)
        else -> if (isDark) Color(0xFF94A3B8) else Color(0xFF475569)
    }

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.dp, cardBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = monthName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color(0xFF0F172A)
                )
                Text(
                    text = statusTitle,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusTextColor
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (hasBill) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المطلوب:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(PrintHelper.formatCurrency(bill!!.totalAmount), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المدفوع:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(PrintHelper.formatCurrency(bill.paidAmount), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color(0xFF4ADE80) else Color(0xFF16A34A))
                }

                if (bill.remainingAmount > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("المتبقي:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(PrintHelper.formatCurrency(bill.remainingAmount), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color(0xFFF87171) else Color(0xFFDC2626))
                    }
                }

                if (bill.createdAt > 0) {
                    val dateFormatted = remember(bill.createdAt) {
                        SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(bill.createdAt))
                    }
                    Text(
                        text = "التاريخ: $dateFormatted",
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            } else {
                Text(
                    text = "لم يتم إنشاء فاتورة لهذا الشهر",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }

            if (hasBill && bill!!.remainingAmount > 0) {
                Spacer(modifier = Modifier.height(4.dp))
                FilledTonalButton(
                    onClick = onQuickPay,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = if (isDark) Color(0xFF15803D) else Color(0xFF16A34A),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                ) {
                    Text("تسديد", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
