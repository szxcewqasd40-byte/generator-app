package com.example.generator.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.ui.theme.*

/**
 * خلفية التطبيق التكيفية: تدعم الوضع الليلي والنهاري والألوان المختارة (أبيض وأسود، أصلي سيبراني، أزرق، زمردي)
 */
@Composable
fun MidnightCyberBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val bg = MaterialTheme.colorScheme.background
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    val gradientColors = if (isDark) {
        listOf(
            bg.copy(alpha = 0.95f),
            bg,
            bg
        )
    } else {
        listOf(
            Color(0xFFF8FAFC),
            Color(0xFFF1F5F9),
            Color(0xFFE2E8F0)
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = gradientColors))
    ) {
        // خلفية خطوط الدوائر والشبكة الكهربائية
        if (isDark) {
            Image(
                painter = painterResource(id = R.drawable.bg_circuit_dark_1787310334519),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .blur(1.dp),
                contentScale = ContentScale.Crop,
                alpha = 0.25f
            )

            // إضاءة متدرجة دائرية
            Box(
                modifier = Modifier
                    .size(320.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 80.dp, y = (-60).dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                primary.copy(alpha = 0.12f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            Box(
                modifier = Modifier
                    .size(280.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-80).dp, y = 60.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                secondary.copy(alpha = 0.08f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )
        }

        content()
    }
}

/**
 * بطاقة زجاجية طافية تتكيف تلقائياً مع نظام الألوان المختار (Cyber / BW / Light / Dark)
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    borderColor: Color? = null,
    borderWidth: Dp = 1.dp,
    elevation: Dp = 6.dp,
    backgroundColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val effectiveBorderColor = borderColor ?: MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.35f else 0.8f)
    val effectiveBgColor = backgroundColor ?: (if (isDark) MaterialTheme.colorScheme.surface.copy(alpha = 0.85f) else MaterialTheme.colorScheme.surface)

    val clickableModifier = if (onClick != null) {
        Modifier.clickable(onClick = onClick)
    } else Modifier

    Surface(
        modifier = modifier
            .shadow(
                elevation = elevation,
                shape = shape,
                ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
            )
            .border(
                border = BorderStroke(borderWidth, effectiveBorderColor),
                shape = shape
            )
            .clip(shape)
            .then(clickableModifier),
        color = effectiveBgColor,
        shape = shape
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

/**
 * أيقونة مجسمة ثلاثية الأبعاد (3D Glossy Sphere Icon) مع إضاءة حافة نيون متوهجة (Rim Lighting)
 */
@Composable
fun Glossy3DIcon(
    imageRes: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    glowColor: Color = MaterialTheme.colorScheme.primary,
    isGlowing: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "iconGlow")
    val animatedGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        if (isGlowing) {
            // تأثير الهالة المضيئة الخلفية (Rim Light Glow)
            Box(
                modifier = Modifier
                    .size(size * 0.95f)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                glowColor.copy(alpha = animatedGlowAlpha * 0.5f),
                                glowColor.copy(alpha = 0.1f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )
        }

        // الأيقونة المجسمة ثلاثية الأبعاد
        Image(
            painter = painterResource(id = imageRes),
            contentDescription = contentDescription,
            modifier = Modifier
                .size(size)
                .shadow(
                    elevation = 6.dp,
                    shape = CircleShape,
                    ambientColor = glowColor.copy(alpha = 0.4f),
                    spotColor = glowColor.copy(alpha = 0.6f)
                )
                .clip(CircleShape)
                .border(
                    BorderStroke(1.2.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.6f), glowColor.copy(alpha = 0.8f), Color.Transparent))),
                    CircleShape
                ),
            contentScale = ContentScale.Crop
        )
    }
}

/**
 * كبسولة إحصائية متوهجة (Electric KPI Chip)
 */
@Composable
fun ElectricBadge(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    color: Color = MaterialTheme.colorScheme.primary
) {
    Surface(
        modifier = modifier
            .wrapContentWidth()
            .border(BorderStroke(1.dp, color.copy(alpha = 0.5f)), RoundedCornerShape(12.dp)),
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = text,
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

