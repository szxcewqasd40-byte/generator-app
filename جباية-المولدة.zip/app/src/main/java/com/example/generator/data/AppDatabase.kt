package com.example.generator.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.generator.data.dao.GeneratorDao
import com.example.generator.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Subscriber::class,
        SubscriberGroup::class,
        Bill::class,
        Payment::class,
        Expense::class,
        UserAccount::class,
        GeneratorSettings::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun generatorDao(): GeneratorDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "generator_billing_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                populateInitialData(getDatabase(context).generatorDao())
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        /**
         * تفريغ قاعدة البيانات الأولية من أي بيانات وهمية أو افتراضية:
         * - لا يتم إدخال أي مشتركين (0 مشتركين).
         * - لا يتم إدخال أي فواتير (0 فواتير).
         * - لا يتم إدخال أي سجلات دفعات (0 دفعات).
         * - لا يتم إدخال أي مصروفات (0 مصروفات).
         * - لا يتم إدخال أي فيزات أو مجموعات (0 فيزات) ليدخل المستخدم فيزاته الخاصة.
         * - الحقول الخاصة بالاسم والعنوان ورقم الهاتف وسعر الأمبير تكون فارغة تماماً.
         */
        private suspend fun populateInitialData(dao: GeneratorDao) {
            // 1. Clean blank generator settings
            dao.saveSettings(
                GeneratorSettings(
                    id = 1,
                    generatorName = "",
                    ownerName = "",
                    phone = "",
                    address = "",
                    defaultPricePerAmpere = 0.0,
                    mastercardNumber = "",
                    isOnlineSyncEnabled = true
                )
            )

            // 2. Default initial system accounts (Admin & Collector) for login authentication
            dao.insertUser(
                UserAccount(
                    id = 1,
                    username = "admin",
                    name = "المدير العام",
                    pinCode = "1234",
                    role = "ADMIN",
                    canDelete = true,
                    canViewFinancials = true,
                    isActive = true
                )
            )
            dao.insertUser(
                UserAccount(
                    id = 2,
                    username = "gabi",
                    name = "الجابي",
                    pinCode = "0000",
                    role = "COLLECTOR",
                    canDelete = false,
                    canViewFinancials = false,
                    isActive = true
                )
            )
        }
    }
}
