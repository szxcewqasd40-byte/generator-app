package com.example.generator.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.GeneratorSettings
import com.example.generator.data.entity.Subscriber
import com.example.generator.ui.components.PosPrintDialog
import com.example.generator.ui.components.PosPrintTarget
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.PrintHelper
import com.example.generator.util.VoiceSearchTextField
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillsScreen(viewModel: GeneratorViewModel) {
    val context = LocalContext.current
    val bills by viewModel.bills.collectAsState()
    val subscribers by viewModel.subscribers.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val users by viewModel.users.collectAsState()
    val availableCollectors = remember(users, currentUser) {
        val names = users.map { it.name }.toMutableList()
        if (currentUser != null && !names.contains(currentUser!!.name)) {
            names.add(0, currentUser!!.name)
        }
        if (!names.contains("مدير النظام")) names.add("مدير النظام")
        names.distinct()
    }

    var statusFilter by remember { mutableStateOf("ALL") } // ALL, UNPAID, PARTIAL, PAID
    var searchQuery by remember { mutableStateOf("") }

    var billToCollect by remember { mutableStateOf<Bill?>(null) }
    var billForDetailsAndPayment by remember { mutableStateOf<Bill?>(null) }
    var billToRevert by remember { mutableStateOf<Bill?>(null) }
    var posPrintTarget by remember { mutableStateOf<PosPrintTarget?>(null) }
    var showBatchDialog by remember { mutableStateOf(false) }
    var showSingleBillDialog by remember { mutableStateOf(false) }

    val isOnline by viewModel.isOnline.collectAsState()
    val lastSyncTime by viewModel.lastSyncTimestamp.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()

    val realCalendar = remember { Calendar.getInstance() }
    val currentRealMonth = realCalendar.get(Calendar.MONTH) + 1
    val currentRealYear = realCalendar.get(Calendar.YEAR)

    // selectedMonth = 0 means "ALL Months in selectedYear"
    var selectedMonth by remember { mutableIntStateOf(currentRealMonth) }
    var selectedYear by remember { mutableIntStateOf(currentRealYear) }

    var monthMenuExpanded by remember { mutableStateOf(false) }
    var yearMenuExpanded by remember { mutableStateOf(false) }

    val monthsList = remember {
        listOf(
            0 to "جميع الأشهر",
            1 to "شهر 1 (كانون الثاني / يناير)",
            2 to "شهر 2 (شباط / فبراير)",
            3 to "شهر 3 (آذار / مارس)",
            4 to "شهر 4 (نيسان / أبريل)",
            5 to "شهر 5 (أيار / مايو)",
            6 to "شهر 6 (حزيران / يونيو)",
            7 to "شهر 7 (تموز / يوليو)",
            8 to "شهر 8 (آب / أغسطس)",
            9 to "شهر 9 (أيلول / سبتمبر)",
            10 to "شهر 10 (تشرين الأول / أكتوبر)",
            11 to "شهر 11 (تشرين الثاني / نوفمبر)",
            12 to "شهر 12 (كانون الأول / ديسمبر)"
        )
    }

    val startYear = remember(bills, currentRealYear) {
        (bills.map { it.year } + listOf(2024, currentRealYear)).minOrNull() ?: 2024
    }
    val maxYear = remember(currentRealYear, selectedYear, bills) {
        (bills.map { it.year } + listOf(currentRealYear + 15, selectedYear + 5)).maxOrNull() ?: (currentRealYear + 15)
    }
    val yearsList = remember(startYear, maxYear) {
        (startYear..maxYear).toList()
    }

    val filteredBills = remember(bills, statusFilter, selectedMonth, selectedYear, searchQuery) {
        bills.filter { bill ->
            val matchesSearch = searchQuery.isBlank() ||
                bill.subscriberName.contains(searchQuery, ignoreCase = true) ||
                bill.billCode.contains(searchQuery, ignoreCase = true)
            val matchesStatus = when (statusFilter) {
                "UNPAID" -> bill.remainingAmount > 0 && bill.paidAmount == 0.0
                "PARTIAL" -> bill.paidAmount > 0 && bill.remainingAmount > 0
                "PAID" -> bill.remainingAmount == 0.0
                else -> true
            }
            val matchesDate = if (selectedMonth == 0) {
                bill.year == selectedYear
            } else {
                bill.month == selectedMonth && bill.year == selectedYear
            }
            matchesSearch && matchesStatus && matchesDate
        }
    }

    val totalAmountPeriod = filteredBills.sumOf { it.totalAmount }
    val totalPaidPeriod = filteredBills.sumOf { it.paidAmount }
    val totalRemainingPeriod = filteredBills.sumOf { it.remainingAmount }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الفواتير والجباية", fontWeight = FontWeight.Bold) },
                actions = {
                    Row(
                        modifier = Modifier.padding(end = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showSingleBillDialog = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.AddCard, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("دين/فاتورة مخصصة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showBatchDialog = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("توليد الفواتير", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Online/Offline & Sync Status Banner
            Surface(
                color = if (isOnline) Color(0xFF16A34A).copy(alpha = 0.10f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isOnline) Color(0xFF16A34A) else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(10.dp)
                        ) {}
                        Text(
                            text = if (isOnline) "🟢 متصل بالإنترنت (الحفظ محلي فوري والمزامنة نشطة)" else "🔴 وضع أوفلاين بدون إنترنت (الحفظ فوري محلي)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isOnline) Color(0xFF16A34A) else MaterialTheme.colorScheme.error
                        )
                    }

                    if (isSyncing) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp)
                            Text("جارٍ المزامنة...", fontSize = 10.sp)
                        }
                    } else if (lastSyncTime != null) {
                        Text(
                            text = "آخر حفظ: ${java.text.SimpleDateFormat("hh:mm a", java.util.Locale("ar")).format(java.util.Date(lastSyncTime!!))}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Period Selector Banner & Presets
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Title and Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            val periodTitle = if (selectedMonth == 0) {
                                "سنة $selectedYear (جميع الأشهر)"
                            } else {
                                "شهر $selectedMonth / $selectedYear"
                            }
                            Text(
                                text = "تصفية الفواتير: $periodTitle",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    if (selectedMonth > 1) {
                                        selectedMonth--
                                    } else if (selectedMonth == 1) {
                                        selectedMonth = 12
                                        selectedYear--
                                    } else {
                                        selectedYear--
                                    }
                                }
                            ) {
                                Icon(Icons.Default.ChevronRight, contentDescription = "السابق")
                            }

                            IconButton(
                                onClick = {
                                    if (selectedMonth in 1..11) {
                                        selectedMonth++
                                    } else if (selectedMonth == 12) {
                                        selectedMonth = 1
                                        selectedYear++
                                    } else {
                                        selectedYear++
                                    }
                                }
                            ) {
                                Icon(Icons.Default.ChevronLeft, contentDescription = "التالي")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Dropdowns for Month and Year selection (Side-by-side)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Month Dropdown
                        ExposedDropdownMenuBox(
                            expanded = monthMenuExpanded,
                            onExpandedChange = { monthMenuExpanded = !monthMenuExpanded },
                            modifier = Modifier.weight(1f)
                        ) {
                            val selectedMonthText = monthsList.firstOrNull { it.first == selectedMonth }?.second ?: "شهر $selectedMonth"
                            OutlinedTextField(
                                value = selectedMonthText,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("الشهر") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthMenuExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                singleLine = true
                            )

                            ExposedDropdownMenu(
                                expanded = monthMenuExpanded,
                                onDismissRequest = { monthMenuExpanded = false },
                                modifier = Modifier.heightIn(max = 260.dp)
                            ) {
                                monthsList.forEach { (mNum, mName) ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = mName,
                                                fontSize = 13.sp,
                                                fontWeight = if (selectedMonth == mNum) FontWeight.Bold else FontWeight.Normal,
                                                color = if (selectedMonth == mNum) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            selectedMonth = mNum
                                            monthMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Year Dropdown
                        ExposedDropdownMenuBox(
                            expanded = yearMenuExpanded,
                            onExpandedChange = { yearMenuExpanded = !yearMenuExpanded },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = "سنة $selectedYear",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("السنة") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = yearMenuExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                singleLine = true
                            )

                            ExposedDropdownMenu(
                                expanded = yearMenuExpanded,
                                onDismissRequest = { yearMenuExpanded = false },
                                modifier = Modifier.heightIn(max = 260.dp)
                            ) {
                                yearsList.forEach { yr ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = "سنة $yr",
                                                fontSize = 13.sp,
                                                fontWeight = if (selectedYear == yr) FontWeight.Bold else FontWeight.Normal,
                                                color = if (selectedYear == yr) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            selectedYear = yr
                                            yearMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Voice Search Field by Subscriber Name
                    VoiceSearchTextField(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholderText = "بحث صوتي أو كتابي باسم المشترك...",
                        prompt = "تحدث باسم المشترك للبحث...",
                        modifier = Modifier.fillMaxWidth()
                    )

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    // Status Chips (All, Unpaid, Partial, Paid)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(
                                selected = statusFilter == "ALL",
                                onClick = { statusFilter = "ALL" },
                                label = { Text("الكل (${filteredBills.size})") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = statusFilter == "UNPAID",
                                onClick = { statusFilter = "UNPAID" },
                                label = { Text("غير مدفوعة") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = statusFilter == "PARTIAL",
                                onClick = { statusFilter = "PARTIAL" },
                                label = { Text("مدفوعة جزئياً") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = statusFilter == "PAID",
                                onClick = { statusFilter = "PAID" },
                                label = { Text("مدفوعة بالكامل") }
                            )
                        }
                    }

                    // Mini totals bar for selected period
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "الإجمالي: ${PrintHelper.formatCurrency(totalAmountPeriod)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "المدفوع: ${PrintHelper.formatCurrency(totalPaidPeriod)}",
                            fontSize = 11.sp,
                            color = Color(0xFF16A34A),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "المتبقي: ${PrintHelper.formatCurrency(totalRemainingPeriod)}",
                            fontSize = 11.sp,
                            color = Color(0xFFDC2626),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (filteredBills.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد فواتير لهذه الفترة أو التصفية المختارة",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredBills) { bill ->
                        BillCard(
                            bill = bill,
                            settings = settings,
                            onOpenDetails = { billForDetailsAndPayment = bill },
                            onCollect = { billToCollect = bill },
                            onRevert = { billToRevert = bill },
                            onShareWhatsApp = { PrintHelper.shareBillWhatsApp(context, bill, settings) },
                            onExportPdf = { PrintHelper.generateAndSharePdfBill(context, bill, settings) },
                            onPrint = { PrintHelper.printBillAndroid(context, bill, settings) },
                            onPrintPos = { posPrintTarget = PosPrintTarget.SingleBill(bill) }
                        )
                    }
                }
            }
        }
    }

    // POS Printer Dialog
    if (posPrintTarget != null) {
        PosPrintDialog(
            target = posPrintTarget!!,
            settings = settings,
            onDismiss = { posPrintTarget = null }
        )
    }

    // Confirmation Dialog for Reverting Payment
    if (billToRevert != null) {
        val b = billToRevert!!
        AlertDialog(
            onDismissRequest = { billToRevert = null },
            icon = { Icon(Icons.Default.Undo, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("تأكيد التراجع عن الدفع", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("المشترك: ${b.subscriberName}", fontWeight = FontWeight.Bold)
                    Text("المبلغ المسدد حالياً: ${PrintHelper.formatCurrency(b.paidAmount)}", color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                    Text("هل ترغب بالتراجع عن سداد هذه الفاتورة وإلغاء عملية القبض؟")
                    Text("سيتم حذف سجلات القبض التابعة للفاتورة وإعادتها فوراً إلى قائمة الديون غير المسددة مع تحديث الإجماليات الحسابية تلقائياً.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.revertBillPayment(b.id)
                        billToRevert = null
                        if (billForDetailsAndPayment?.id == b.id) {
                            billForDetailsAndPayment = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تأكيد التراجع وإعادة الفاتورة كدين")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { billToRevert = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Bill Details and Electronic Payment Dialog
    if (billForDetailsAndPayment != null) {
        BillDetailsAndPaymentDialog(
            bill = billForDetailsAndPayment!!,
            settings = settings,
            onDismiss = { billForDetailsAndPayment = null },
            onCollect = {
                val b = billForDetailsAndPayment!!
                billForDetailsAndPayment = null
                billToCollect = b
            },
            onRevert = {
                val b = billForDetailsAndPayment!!
                billForDetailsAndPayment = null
                billToRevert = b
            },
            onShareWhatsApp = { PrintHelper.shareBillWhatsApp(context, billForDetailsAndPayment!!, settings) },
            onExportPdf = { PrintHelper.generateAndSharePdfBill(context, billForDetailsAndPayment!!, settings) },
            onPrint = { PrintHelper.printBillAndroid(context, billForDetailsAndPayment!!, settings) },
            onPrintPos = {
                val b = billForDetailsAndPayment!!
                billForDetailsAndPayment = null
                posPrintTarget = PosPrintTarget.SingleBill(b)
            }
        )
    }

    // Record Payment Dialog
    if (billToCollect != null) {
        RecordPaymentDialog(
            bill = billToCollect!!,
            settings = settings,
            currentUserName = currentUser?.name ?: "الجابي",
            availableCollectors = availableCollectors,
            onDismiss = { billToCollect = null },
            onConfirm = { amount, collector, notes ->
                viewModel.recordPayment(billToCollect!!.id, amount, collector, notes)
                billToCollect = null
            }
        )
    }

    // Batch Bills Dialog with Custom Month & Year Pickers
    if (showBatchDialog) {
        BatchBillsMonthYearDialog(
            initialMonth = if (selectedMonth != 0) selectedMonth else currentRealMonth,
            initialYear = selectedYear,
            onDismiss = { showBatchDialog = false },
            onConfirm = { m, y ->
                viewModel.generateMonthlyBills(m, y)
                showBatchDialog = false
            }
        )
    }

    // Single Custom Bill Dialog with Subscriber & Custom Month/Year Pickers
    if (showSingleBillDialog) {
        SingleBillMonthYearDialog(
            subscribers = subscribers,
            initialMonth = if (selectedMonth != 0) selectedMonth else currentRealMonth,
            initialYear = selectedYear,
            onDismiss = { showSingleBillDialog = false },
            onConfirm = { subId, m, y, amps, price, customTotal ->
                viewModel.addSingleBillForSubscriber(subId, m, y, amps, price, customTotal)
                showSingleBillDialog = false
            }
        )
    }
}

@Composable
fun BatchBillsMonthYearDialog(
    initialMonth: Int,
    initialYear: Int,
    onDismiss: () -> Unit,
    onConfirm: (month: Int, year: Int) -> Unit
) {
    var month by remember { mutableIntStateOf(initialMonth) }
    var year by remember { mutableIntStateOf(initialYear) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.PostAdd, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text("إصدار فواتير شهرية عامة", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "حدد الشهر والسنة المراد إصدار الفواتير والاشتراكات لجميع المشتركين الفعالين عنها:",
                    fontSize = 13.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Month Picker
                    OutlinedTextField(
                        value = month.toString(),
                        onValueChange = { input ->
                            val valInt = input.toIntOrNull()
                            if (valInt != null && valInt in 1..12) month = valInt
                        },
                        label = { Text("الشهر (1 - 12)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    // Year Picker
                    OutlinedTextField(
                        value = year.toString(),
                        onValueChange = { input ->
                            val valInt = input.toIntOrNull()
                            if (valInt != null && valInt in 2020..2040) year = valInt
                        },
                        label = { Text("السنة (2024..)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Month Quick Pick Buttons
                Text("اختيار سريع للشهر:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items((1..12).toList()) { mVal ->
                        FilterChip(
                            selected = month == mVal,
                            onClick = { month = mVal },
                            label = { Text("$mVal") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(month, year) }) {
                Text("إصدار الفواتير لشهر $month / $year")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SingleBillMonthYearDialog(
    subscribers: List<Subscriber>,
    initialMonth: Int,
    initialYear: Int,
    onDismiss: () -> Unit,
    onConfirm: (subscriberId: Long, month: Int, year: Int, amperes: Double, pricePerAmpere: Double, customTotal: Double?) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedSubscriber by remember { mutableStateOf<Subscriber?>(subscribers.firstOrNull()) }
    var expandedDropdown by remember { mutableStateOf(false) }

    var month by remember { mutableIntStateOf(initialMonth) }
    var year by remember { mutableIntStateOf(initialYear) }

    var amperesText by remember { mutableStateOf(selectedSubscriber?.amperes?.toString() ?: "5") }
    var priceText by remember { mutableStateOf(selectedSubscriber?.defaultPricePerAmpere?.toString() ?: "10000") }
    var customTotalText by remember { mutableStateOf("") }

    val filteredSubscribers = remember(subscribers, searchQuery) {
        if (searchQuery.isBlank()) {
            subscribers
        } else {
            val q = searchQuery.trim().lowercase()
            subscribers.filter { sub ->
                sub.name.lowercase().contains(q) ||
                sub.subscriberCode.lowercase().contains(q) ||
                sub.phone.contains(q)
            }
        }
    }

    // Synchronize defaults when subscriber changes
    LaunchedEffect(selectedSubscriber) {
        selectedSubscriber?.let { sub ->
            amperesText = sub.amperes.toString()
            priceText = sub.defaultPricePerAmpere.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.AddCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text("إصدار فاتورة / دين لمشترك معين", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ابحث عن المشترك بالاسم وحدد الشهر والسنة لإصدار الفاتورة:", fontSize = 12.sp)

                // Search Field for Subscriber Name
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        expandedDropdown = true
                    },
                    label = { Text("البحث عن اسم المشترك أو الكود") },
                    placeholder = { Text("اكتب اسم المشترك للبحث السريع...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "بحث") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = {
                                searchQuery = ""
                                expandedDropdown = true
                            }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Subscriber Dropdown Menu
                ExposedDropdownMenuBox(
                    expanded = expandedDropdown,
                    onExpandedChange = { expandedDropdown = !expandedDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedSubscriber?.let { "${it.name} (${it.subscriberCode}) - ${it.amperes} أمبير" } ?: "اختر المشترك من القائمة",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("المشترك المحدد") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false },
                        modifier = Modifier.heightIn(max = 220.dp)
                    ) {
                        if (filteredSubscribers.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("لا يوجد مشترك مطابق للبحث", color = MaterialTheme.colorScheme.error, fontSize = 12.sp) },
                                onClick = { }
                            )
                        } else {
                            filteredSubscribers.forEach { sub ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text("${sub.name} (${sub.subscriberCode})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("${sub.amperes} أمبير | ${if (sub.phone.isNotEmpty()) sub.phone else "بدون هاتف"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    onClick = {
                                        selectedSubscriber = sub
                                        searchQuery = sub.name
                                        expandedDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Month & Year Input
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = month.toString(),
                        onValueChange = { input ->
                            val v = input.toIntOrNull()
                            if (v != null && v in 1..12) month = v
                        },
                        label = { Text("الشهر (1-12)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = year.toString(),
                        onValueChange = { input ->
                            val v = input.toIntOrNull()
                            if (v != null && v in 2020..2040) year = v
                        },
                        label = { Text("السنة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Amperes & Price
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = amperesText,
                        onValueChange = { amperesText = it },
                        label = { Text("الأمبيرات") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("سعر الأمبير") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = customTotalText,
                    onValueChange = { customTotalText = it },
                    label = { Text("مبلغ مقطوع مخصص (اختياري)") },
                    placeholder = { Text("اتركه فارغاً للحساب التلقائي") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val sub = selectedSubscriber ?: return@Button
                    val amps = amperesText.toDoubleOrNull() ?: sub.amperes
                    val price = priceText.toDoubleOrNull() ?: sub.defaultPricePerAmpere
                    val total = customTotalText.toDoubleOrNull()

                    onConfirm(sub.id, month, year, amps, price, total)
                },
                enabled = selectedSubscriber != null
            ) {
                Text("حفظ الفاتورة والدين")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun BillCard(
    bill: Bill,
    settings: GeneratorSettings?,
    onOpenDetails: () -> Unit,
    onCollect: () -> Unit,
    onRevert: () -> Unit,
    onShareWhatsApp: () -> Unit,
    onExportPdf: () -> Unit,
    onPrint: () -> Unit,
    onPrintPos: () -> Unit
) {
    val context = LocalContext.current
    val statusColor = when (bill.status) {
        "PAID" -> Color(0xFF16A34A)
        "PARTIAL" -> Color(0xFFD97706)
        else -> Color(0xFFDC2626)
    }
    val statusText = when (bill.status) {
        "PAID" -> "مدفوعة بالكامل"
        "PARTIAL" -> "مدفوعة جزئياً"
        else -> "غير مدفوعة"
    }

    val mastercard = settings?.mastercardNumber?.takeIf { it.isNotBlank() }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onOpenDetails() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = bill.subscriberName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF000000)
                    )
                    Text(
                        text = "رقم الفاتورة: ${bill.billCode} | شهر ${bill.month} / ${bill.year}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = statusColor.copy(alpha = 0.15f),
                    contentColor = statusColor
                ) {
                    Text(
                        text = statusText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("الأمبيرات: ${bill.amperes} أمبير", fontSize = 13.sp)
                Text("الإجمالي: ${PrintHelper.formatCurrency(bill.totalAmount)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("المدفوع: ${PrintHelper.formatCurrency(bill.paidAmount)}", color = Color(0xFF16A34A), fontSize = 13.sp)
                Text("المتبقي: ${PrintHelper.formatCurrency(bill.remainingAmount)}", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            // Electronic Payment / Mastercard snippet if available
            if (mastercard != null && bill.remainingAmount > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0284C7).copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("ماستر كارد / حساب بنكي:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(mastercard, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                            }
                        }

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("MastercardNumber", mastercard)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "تم نسخ رقم الماستر كارد للحافظة", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "نسخ رقم البطاقة",
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Divider(modifier = Modifier.padding(vertical = 10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row {
                    IconButton(onClick = onShareWhatsApp) {
                        Icon(Icons.Default.Share, contentDescription = "واتساب", tint = Color(0xFF25D366))
                    }
                    IconButton(onClick = onExportPdf) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color(0xFFDC2626))
                    }
                    IconButton(onClick = onPrint) {
                        Icon(Icons.Default.Print, contentDescription = "طباعة النظام", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onPrintPos) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = "طباعة POS حرارية", tint = Color(0xFF0D9488))
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Payment status toggle / revert button when already paid/partial
                    if (bill.paidAmount > 0) {
                        OutlinedButton(
                            onClick = onRevert,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تراجع", fontSize = 11.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = onOpenDetails,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("الدفع والتفاصيل", fontSize = 11.sp)
                    }

                    if (bill.remainingAmount > 0) {
                        Button(
                            onClick = onCollect,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تسجيل دفع", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BillDetailsAndPaymentDialog(
    bill: Bill,
    settings: GeneratorSettings?,
    onDismiss: () -> Unit,
    onCollect: () -> Unit,
    onRevert: () -> Unit,
    onShareWhatsApp: () -> Unit,
    onExportPdf: () -> Unit,
    onPrint: () -> Unit,
    onPrintPos: () -> Unit
) {
    val context = LocalContext.current
    val mastercard = settings?.mastercardNumber?.takeIf { it.isNotBlank() } ?: "لم يتم تحديد رقم ماستر كارد"
    var attachedReceiptUri by remember { mutableStateOf<Uri?>(null) }
    var attachedBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            attachedReceiptUri = uri
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    attachedBitmap = BitmapFactory.decodeStream(stream)
                }
                Toast.makeText(context, "تم إرفاق صورة وصل التحويل بنجاح ✅", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "فشل قراءة صورة الإشعار", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val statusColor = when (bill.status) {
        "PAID" -> Color(0xFF16A34A)
        "PARTIAL" -> Color(0xFFD97706)
        else -> Color(0xFFDC2626)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("فاتورة المشترك: ${bill.subscriberName}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("رقم الفاتورة: ${bill.billCode}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("شهر ${bill.month} / ${bill.year}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Text("المشترك: ${bill.subscriberName} (${bill.subscriberCode})", fontSize = 12.sp)
                            Text("عدد الأمبيرات: ${bill.amperes} أمبير | سعر الأمبير: ${PrintHelper.formatCurrency(bill.pricePerAmpere)}", fontSize = 12.sp)
                            if (bill.fixedFee > 0) {
                                Text("رسوم الفيزة الثابتة: ${PrintHelper.formatCurrency(bill.fixedFee)}", fontSize = 12.sp)
                            }
                            Divider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("المبلغ الإجمالي: ${PrintHelper.formatCurrency(bill.totalAmount)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("المدفوع: ${PrintHelper.formatCurrency(bill.paidAmount)}", color = Color(0xFF16A34A), fontSize = 13.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("المبلغ المتبقي:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(PrintHelper.formatCurrency(bill.remainingAmount), color = Color(0xFFDC2626), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }

                // Mastercard & Electronic Payment Section
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0284C7).copy(alpha = 0.08f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CreditCard, contentDescription = null, tint = Color(0xFF0284C7))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("طريقة الدفع الإلكتروني (ماستر كارد / بنك)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0284C7))
                            }

                            Text(
                                text = "صاحب الحساب: ${settings?.ownerName ?: "صاحب المولدة"}",
                                fontSize = 12.sp
                            )

                            // Card Number with Copy Button
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF0284C7).copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("رقم الماستر كارد / الحساب البنكي:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = mastercard,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = Color(0xFF0284C7)
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("MastercardNumber", mastercard)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "تم نسخ رقم الماستر كارد بنجاح", Toast.LENGTH_SHORT).show()
                                        },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("نسخ الرقم", fontSize = 11.sp)
                                    }
                                }
                            }

                            // Attach Transfer Receipt Image
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { imagePickerLauncher.launch("image/*") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (attachedBitmap != null) "تغيير صورة الوصل" else "إرفاق وصل التحويل", fontSize = 11.sp)
                                }

                                if (attachedBitmap != null) {
                                    IconButton(onClick = {
                                        attachedBitmap = null
                                        attachedReceiptUri = null
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف الوصل", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }

                            // Thumbnail preview if attached
                            if (attachedBitmap != null) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(130.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        Image(
                                            bitmap = attachedBitmap!!.asImageBitmap(),
                                            contentDescription = "صورة وصل التحويل",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                        Surface(
                                            color = Color.Black.copy(alpha = 0.6f),
                                            shape = RoundedCornerShape(bottomEnd = 8.dp),
                                            modifier = Modifier.align(Alignment.TopStart)
                                        ) {
                                            Text(
                                                text = "وصل التحويل مرفق ومؤكد ✅",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Sharing & Actions
                item {
                    Text("خيارات إرسال الفاتورة والطباعة:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = onShareWhatsApp,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("واتساب", fontSize = 11.sp)
                        }

                        Button(
                            onClick = onExportPdf,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PDF", fontSize = 11.sp)
                        }

                        Button(
                            onClick = onPrint,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("طباعة", fontSize = 11.sp)
                        }

                        Button(
                            onClick = onPrintPos,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("طابعة POS", fontSize = 11.sp)
                        }
                    }
                }

                if (bill.paidAmount > 0) {
                    item {
                        OutlinedButton(
                            onClick = onRevert,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تراجع عن الدفع / إلغاء التسديد وإعادة الفاتورة كدين ↩️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (bill.remainingAmount > 0) {
                Button(
                    onClick = onCollect,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                ) {
                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تسجيل دفع الآن")
                }
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordPaymentDialog(
    bill: Bill,
    settings: GeneratorSettings?,
    currentUserName: String,
    availableCollectors: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (amount: Double, collectorName: String, notes: String) -> Unit
) {
    val context = LocalContext.current
    var amountText by remember { mutableStateOf(bill.remainingAmount.toString()) }
    var selectedCollector by remember { mutableStateOf(currentUserName) }
    var expandedCollectorDropdown by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }
    val mastercard = settings?.mastercardNumber?.takeIf { it.isNotBlank() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل دفعة جباية", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("المشترك: ${bill.subscriberName}", fontWeight = FontWeight.Bold)
                Text("المبلغ الإجمالي للفاتورة: ${PrintHelper.formatCurrency(bill.totalAmount)}")
                Text("المبلغ المتبقي حالياً: ${PrintHelper.formatCurrency(bill.remainingAmount)}", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)

                if (mastercard != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF0284C7).copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ماستر كارد: $mastercard", fontSize = 11.sp, color = Color(0xFF0284C7), fontWeight = FontWeight.Bold)
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("MC", mastercard))
                                    Toast.makeText(context, "تم نسخ رقم الماستر كارد", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", tint = Color(0xFF0284C7), modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }

                // Collector Selection Field
                ExposedDropdownMenuBox(
                    expanded = expandedCollectorDropdown,
                    onExpandedChange = { expandedCollectorDropdown = !expandedCollectorDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedCollector,
                        onValueChange = { selectedCollector = it },
                        label = { Text("اسم الجابي (المحصل)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCollectorDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        singleLine = true
                    )

                    ExposedDropdownMenu(
                        expanded = expandedCollectorDropdown,
                        onDismissRequest = { expandedCollectorDropdown = false }
                    ) {
                        availableCollectors.forEach { colName ->
                            DropdownMenuItem(
                                text = { Text(colName, fontWeight = FontWeight.Medium) },
                                onClick = {
                                    selectedCollector = colName
                                    expandedCollectorDropdown = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("المبلغ المستلم الآن (د.ع)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات الدفع / رقم الحوالة (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    onConfirm(amount, selectedCollector.ifBlank { currentUserName }, notes)
                }
            ) {
                Text("تسجيل وحفظ")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
