package com.example.generator.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "generator_settings")
data class GeneratorSettings(
    @PrimaryKey
    val id: Int = 1,
    val generatorName: String = "",
    val ownerName: String = "",
    val phone: String = "",
    val address: String = "",
    val defaultPricePerAmpere: Double = 0.0,
    val mastercardNumber: String = "",
    val isOnlineSyncEnabled: Boolean = true,
    val lastSyncTimestamp: Long = System.currentTimeMillis()
)
