package com.example.generator.ui.components

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.GeneratorSettings
import com.example.generator.data.entity.Subscriber
import com.example.generator.util.PrintHelper
import com.example.ui.theme.*
import java.util.Calendar
import java.util.Locale

@Composable
fun SubscriberPrintOptionsDialog(
    subscriber: Subscriber,
    subBills: List<Bill>,
    settings: GeneratorSettings?,
    targetMonth: Int = 0,
    targetYear: Int = 0,
    onDismiss: () -> Unit,
    onThermalPosPrint: (Bill) -> Unit
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()
    val activeMonth = if (targetMonth > 0) targetMonth else (calendar.get(Calendar.MONTH) + 1)
    val activeYear = if (targetYear > 0) targetYear else calendar.get(Calendar.YEAR)

    // Find latest or target month bill, or construct a representative one
    val bill = subBills.firstOrNull { (targetMonth == 0 || it.month == targetMonth) && (targetYear == 0 || it.year == targetYear) }
        ?: subBills.firstOrNull()
        ?: run {
            val total = (subscriber.amperes * subscriber.defaultPricePerAmpere) + subscriber.fixedFee
            val billCode = "INV-$activeYear${String.format(Locale.US, "%02d", activeMonth)}-${subscriber.id}"
            Bill(
                billCode = billCode,
                subscriberId = subscriber.id,
                subscriberName = subscriber.name,
                subscriberCode = subscriber.subscriberCode,
                month = activeMonth,
                year = activeYear,
                amperes = subscriber.amperes,
                pricePerAmpere = subscriber.defaultPricePerAmpere,
                fixedFee = subscriber.fixedFee,
                totalAmount = total,
                paidAmount = 0.0,
                remainingAmount = total,
                status = "UNPAID"
            )
        }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Icon
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(54.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "خيارات الطباعة والمشاركة",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "خيارات الطباعة والمشاركة",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                val breakerInfo = if (subscriber.circuitBreakerNumber.isNotBlank()) " • ⚡ جوزة: ${subscriber.circuitBreakerNumber}" else ""
                Text(
                    text = "للمشترك: ${subscriber.name} (${subscriber.subscriberCode})$breakerInfo",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Summary Pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "شهر ${bill.month} / ${bill.year}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "إجمالي الحساب: ${PrintHelper.formatCurrency(bill.totalAmount)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElectricCyan
                            )
                        }
                        val address = settings?.address?.takeIf { it.isNotBlank() }
                        if (address != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "📍 $address",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Option 1: Direct Thermal POS Bluetooth Printing
                PrintOptionCard(
                    title = "طباعة حرارية مباشرة (بلوتوث)",
                    subtitle = "طباعة فورية عبر طابعات الفواتير المحمولة 58mm / 80mm",
                    icon = Icons.Default.BluetoothConnected,
                    iconTint = Color(0xFF2563EB),
                    iconBg = Color(0xFFDBEAFE),
                    onClick = {
                        onDismiss()
                        onThermalPosPrint(bill)
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Option 2: Share Invoice via WhatsApp / Social
                PrintOptionCard(
                    title = "مشاركة الفاتورة (واتساب وغيرها)",
                    subtitle = "إرسال تفاصيل الفاتورة كرسالة نصية مع الباركود",
                    icon = Icons.Default.Share,
                    iconTint = Color(0xFF16A34A),
                    iconBg = Color(0xFFDCFCE7),
                    onClick = {
                        onDismiss()
                        PrintHelper.shareBillWhatsApp(context, bill, settings)
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Option 3: View & Print Official System Receipt / PDF
                PrintOptionCard(
                    title = "عرض / طباعة وصل الاستلام",
                    subtitle = "معاينة الوصل والطباعة عبر خدمة الطباعة بالنظام أو PDF",
                    icon = Icons.Default.ReceiptLong,
                    iconTint = Color(0xFFD97706),
                    iconBg = Color(0xFFFEF3C7),
                    onClick = {
                        onDismiss()
                        PrintHelper.printBillAndroid(context, bill, settings)
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Dismiss Button
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إغلاق", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

@Composable
private fun PrintOptionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = iconBg,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
