package com.example.generator.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Bill::class,
            parentColumns = ["id"],
            childColumns = ["billId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["billId"]), Index(value = ["subscriberId"])]
)
data class Payment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val receiptCode: String, // e.g. REC-20260803-101
    val billId: Long,
    val subscriberId: Long,
    val subscriberName: String,
    val amountPaid: Double,
    val paymentDate: Long = System.currentTimeMillis(),
    val collectedBy: String = "مدير النظام",
    val notes: String = ""
)
