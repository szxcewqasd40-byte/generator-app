package com.example.generator.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val privacyPolicyWebUrl = "https://generator-billing-policy.pages.dev/privacy.html"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PrivacyTip,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("سياسة الخصوصية وأمان البيانات", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "نظام إدارة المولدات الأهلية يلتزم بحماية خصوصيتك وبيانات عملائك والامتثال الكامل لسياسات Google Play Developer Policies و Data Safety.",
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                item {
                    PolicySectionCard(
                        title = "1. البيانات التي يجمعها ويخزنها التطبيق:",
                        content = "• بيانات المشتركين: الاسم الثلاثي، رقم الهاتف، عدد الأمبيرات، ورقم الجوزة.\n• السجلات المالية: مبالغ الفواتير، الديون السابقة، وحركات القبض والمصروفات.\n• الغرض: تنظيم عملية الجباية، إصدار وصولات الدفع، وإعداد التقارير المالية لصاحب المولدة."
                    )
                }

                item {
                    PolicySectionCard(
                        title = "2. أمان وتخزين البيانات:",
                        content = "• التخزين المحلي (Offline First): تُحفظ كافة السجلات الحسابية محلياً على جهازك بقاعدة بيانات مشفرة وآمنة تعمل بدون إنترنت.\n• التخزين السحابي (اختياري): في حال تفعيل المزامنة، يتم تشفير البيانات أثناء النقل (TLS/HTTPS) وتخزينها بأمان لحمايتها من الفقدان."
                    )
                }

                item {
                    PolicySectionCard(
                        title = "3. الأذونات المستخدمة (حسب الحاجة فقط):",
                        content = "• البلوتوث (Bluetooth): للاتصال بطابعات الجباية الحرارية المحمولة وأجهزة POS لطباعة الفواتير الفورية.\n• الإنترنت والشبكة: للتحقق من اشتراكات Google Play Billing ومزامنة النسخ الاحتياطية السحابية المشفرة."
                    )
                }

                item {
                    PolicySectionCard(
                        title = "4. حذف الحساب والبيانات (Account & Data Deletion):",
                        content = "يحق لمدير المولدة في أي وقت طلب حذف حسابه بالكامل، ومسح كافة سجلات المشتركين والفواتير والمصروفات نهائياً بضغطة زر واحدة من شاشة الإعدادات أو عبر التواصل مع الدعم الفني."
                    )
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "🌐 رابط صفحة الويب الرسمية لسياسة الخصوصية:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            TextButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(privacyPolicyWebUrl))
                                    context.startActivity(intent)
                                },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(privacyPolicyWebUrl, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("فهمت وموافق")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(privacyPolicyWebUrl))
                    context.startActivity(intent)
                }
            ) {
                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("فتح الرابط الخارجي", fontSize = 11.sp)
            }
        }
    )
}

@Composable
private fun PolicySectionCard(title: String, content: String) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(content, fontSize = 11.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
