package com.example.generator.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.generator.data.AppDatabase
import com.example.generator.data.GeneratorRepository
import com.example.generator.data.entity.*
import com.example.generator.util.ExcelExporterImporter
import com.example.generator.util.NetworkConnectivityObserver
import com.example.generator.util.PrintHelper
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar
import java.util.Locale

class GeneratorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GeneratorRepository
    private val connectivityObserver = NetworkConnectivityObserver(application)

    // --- NETWORK & OFFLINE-FIRST SYNC ---
    val isOnline: StateFlow<Boolean> = connectivityObserver.isOnlineFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, connectivityObserver.isCurrentlyConnected())

    // --- GOOGLE PLAY BILLING & TRIAL ---
    val billingManager = com.generator.billing.util.BillingManager(application)
    val isSubscribed = billingManager.isSubscribed
    val activeProductId = billingManager.activeProductId
    val availablePlans = billingManager.availablePlans
    val billingStatusMessage = billingManager.billingStatusMessage

    // --- AUTHENTICATION & SECURITY MANAGER ---
    val authAndSecurityManager = com.example.generator.util.AuthAndSecurityManager(application)
    val currentUserProfile = authAndSecurityManager.currentUserProfile
    val isAppLockEnabled = authAndSecurityManager.isAppLockEnabled
    val lockType = authAndSecurityManager.lockType
    val securityPin = authAndSecurityManager.securityPin
    val securityPattern = authAndSecurityManager.securityPattern

    // --- THEME & COLOR PALETTE PREFERENCES ---
    val themePreferencesManager = com.example.generator.util.ThemePreferencesManager(application)
    val themeMode = themePreferencesManager.themeMode
    val colorPalette = themePreferencesManager.colorPalette

    fun setThemeMode(mode: com.example.generator.util.AppThemeMode) {
        themePreferencesManager.setThemeMode(mode)
    }

    fun setColorPalette(palette: com.example.generator.util.AppColorPalette) {
        themePreferencesManager.setColorPalette(palette)
    }

    // Trial Flow State
    private val _remainingTrialDays = MutableStateFlow(authAndSecurityManager.getRemainingTrialDays())
    val remainingTrialDays: StateFlow<Int> = _remainingTrialDays.asStateFlow()

    private val _isTrialActive = MutableStateFlow(authAndSecurityManager.isTrialActive())
    val isTrialActive: StateFlow<Boolean> = _isTrialActive.asStateFlow()

    // Access granted if subscribed OR trial is active
    val hasFullAccess: StateFlow<Boolean> = combine(isSubscribed, _isTrialActive) { subscribed, trialActive ->
        subscribed || trialActive
    }.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = GeneratorRepository(database.generatorDao())

        // Ensure default basic auth users and blank settings exist
        viewModelScope.launch {
            try {
                val existingUsers = repository.users.firstOrNull()
                if (existingUsers.isNullOrEmpty()) {
                    repository.addUser(
                        UserAccount(
                            id = 1,
                            username = "admin",
                            name = "المدير العام",
                            pinCode = "1234",
                            role = "ADMIN",
                            canDelete = true,
                            canViewFinancials = true,
                            isActive = true
                        )
                    )
                    repository.addUser(
                        UserAccount(
                            id = 2,
                            username = "gabi",
                            name = "الجابي",
                            pinCode = "0000",
                            role = "COLLECTOR",
                            canDelete = false,
                            canViewFinancials = false,
                            isActive = true
                        )
                    )
                }

                val existingSettings = repository.settings.firstOrNull()
                if (existingSettings == null) {
                    repository.saveSettings(
                        GeneratorSettings(
                            id = 1,
                            generatorName = "",
                            ownerName = "",
                            phone = "",
                            address = "",
                            defaultPricePerAmpere = 0.0,
                            mastercardNumber = "",
                            isOnlineSyncEnabled = true
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Automatic monthly renewal: Automatically initialize active subscribers with current month bill (UNPAID / light red)
        viewModelScope.launch {
            try {
                val calendar = Calendar.getInstance()
                val currentMonth = calendar.get(Calendar.MONTH) + 1
                val currentYear = calendar.get(Calendar.YEAR)
                repository.generateMonthlyBillsForActiveSubscribers(currentMonth, currentYear)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Automatic background sync when coming online
        viewModelScope.launch {
            isOnline.collect { online ->
                if (online) {
                    triggerAutoSyncIfOnline()
                }
            }
        }
    }

    fun subscribePlan(activity: android.app.Activity, plan: com.generator.billing.util.SubscriptionPlan) {
        billingManager.launchBillingFlow(activity, plan)
    }

    fun refreshSubscriptions() {
        billingManager.queryActivePurchases()
        billingManager.querySubscriptions()
    }

    fun openGooglePlaySubscriptions(activity: android.app.Activity) {
        billingManager.openGooglePlaySubscriptions(activity)
    }

    fun cancelSubscriptionForTesting() {
        billingManager.cancelOrDeactivateForTesting()
        _message.value = "تم إلغاء الاشتراك (وضع الاختبار)"
    }

    fun activateSubscriptionForTesting(isYearly: Boolean = false) {
        billingManager.activateForTesting(isYearly)
        _message.value = "تم تفعيل الاشتراك تجريبياً (${if (isYearly) "سنوي" else "شهري"})"
    }

    fun deleteAllAccountDataAndReset() {
        viewModelScope.launch {
            try {
                repository.clearAllDataAndResetAccount()
                val adminUser = repository.users.firstOrNull()?.find { it.role == "ADMIN" }
                currentUser.value = adminUser
                _message.value = "تم حذف الحساب وجميع السجلات والبيانات نهائياً وإعادة ضبط النظام بنجاح"
            } catch (e: Exception) {
                e.printStackTrace()
                _message.value = "حدث خطأ أثناء حذف البيانات: ${e.localizedMessage}"
            }
        }
    }

    // --- USER SESSION & PERMISSIONS ---
    val currentUser = MutableStateFlow<UserAccount?>(null)

    val users: StateFlow<List<UserAccount>> = repository.users
        .stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            listOf(
                UserAccount(
                    id = 1,
                    username = "admin",
                    name = "المدير العام",
                    pinCode = "1234",
                    role = "ADMIN",
                    canDelete = true,
                    canViewFinancials = true,
                    isActive = true
                ),
                UserAccount(
                    id = 2,
                    username = "gabi",
                    name = "الجابي أحمد",
                    pinCode = "0000",
                    role = "COLLECTOR",
                    canDelete = false,
                    canViewFinancials = false,
                    isActive = true
                )
            )
        )

    val settings: StateFlow<GeneratorSettings?> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- SUBSCRIBERS ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val subscribers: StateFlow<List<Subscriber>> = _searchQuery
        .flatMapLatest { query -> repository.searchSubscribers(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val subscriberGroups: StateFlow<List<SubscriberGroup>> = repository.subscriberGroups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- BILLS & PAYMENTS ---
    val bills: StateFlow<List<Bill>> = repository.bills
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<Payment>> = repository.payments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- EXPENSES ---
    val expenses: StateFlow<List<Expense>> = repository.expenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- STATS SUMMARY ---
    val subscribersCount: StateFlow<Int> = repository.subscribersCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalDueAmount: StateFlow<Double> = repository.totalDueAmount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalCollectedAmount: StateFlow<Double> = repository.totalCollectedAmount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalDebtsAmount: StateFlow<Double> = repository.totalDebtsAmount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpensesAmount: StateFlow<Double> = repository.totalExpensesAmount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val netProfit: StateFlow<Double> = combine(totalCollectedAmount, totalExpensesAmount) { collected, expenses ->
        collected - expenses
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Operation Messages/Snackbars
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Auto backup to Downloads folder (persists across app uninstall)
    fun triggerAutoBackup() {
        viewModelScope.launch {
            try {
                ExcelExporterImporter.autoSaveBackupToDownloads(
                    getApplication(),
                    subscribers.value,
                    subscriberGroups.value,
                    bills.value,
                    payments.value,
                    expenses.value,
                    users.value,
                    settings.value
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun restoreFromAutoBackupFile(): Boolean {
        val jsonContent = ExcelExporterImporter.checkForAutoBackupFile(getApplication())
        if (jsonContent != null) {
            restoreFromJsonContent(jsonContent)
            _message.value = "تمت استعادة جميع البيانات بنجاح من النسخة التلقائية لـ الهاتف!"
            return true
        } else {
            _message.value = "لم يتم العثور على ملف نسخة تلقائية محفوظة سابقة في ذاكرة الهاتف"
            return false
        }
    }

    // --- ACTIONS ---
    fun addSubscriber(
        name: String,
        phone: String,
        amperes: Double,
        pricePerAmpere: Double,
        groupName: String = "",
        fixedFee: Double = 0.0,
        circuitBreakerNumber: String = "",
        notes: String = ""
    ) {
        viewModelScope.launch {
            if (name.isBlank()) {
                _message.value = "يرجى إدخال اسم المشترك"
                return@launch
            }
            repository.addSubscriber(name, phone, amperes, pricePerAmpere, groupName, fixedFee, circuitBreakerNumber, notes)
            _message.value = "تمت إضافة المشترك بنجاح"
            triggerAutoBackup()
        }
    }

    fun updateSubscriber(subscriber: Subscriber) {
        viewModelScope.launch {
            repository.updateSubscriber(subscriber)
            _message.value = "تم تحديث بيانات المشترك"
            triggerAutoBackup()
        }
    }

    // --- SUBSCRIBER GROUP / PHASE ACTIONS ---
    fun addSubscriberGroup(
        groupName: String,
        pricePerAmpere: Double,
        fixedFee: Double,
        notes: String,
        applyToExistingSubscribers: Boolean = false
    ) {
        viewModelScope.launch {
            if (groupName.isBlank()) {
                _message.value = "يرجى إدخال اسم الفيز / المجموعة"
                return@launch
            }
            repository.addSubscriberGroup(groupName, pricePerAmpere, fixedFee, notes, applyToExistingSubscribers)
            _message.value = "تمت إضافة المجموعة/الفيز ($groupName) بنجاح"
            triggerAutoBackup()
        }
    }

    fun updateSubscriberGroup(
        group: SubscriberGroup,
        oldGroupName: String? = null,
        applyToSubscribers: Boolean = false
    ) {
        viewModelScope.launch {
            if (group.groupName.isBlank()) {
                _message.value = "اسم المجموعة غير صالح"
                return@launch
            }
            repository.updateSubscriberGroup(group, oldGroupName, applyToSubscribers)
            _message.value = "تم تحديث أسعار وفيزات مجموعة (${group.groupName})"
            triggerAutoBackup()
        }
    }

    fun deleteSubscriberGroup(groupId: Long) {
        viewModelScope.launch {
            repository.deleteSubscriberGroup(groupId)
            _message.value = "تم حذف المجموعة"
        }
    }

    fun applyGroupPricingToSubscribers(groupName: String, pricePerAmpere: Double, fixedFee: Double) {
        viewModelScope.launch {
            repository.applyGroupPricingToSubscribers(groupName, pricePerAmpere, fixedFee)
            _message.value = "تم تطبيق السعر والفيزة الجديدة على كل مشتركي ($groupName)"
            triggerAutoBackup()
        }
    }


    fun deleteSubscriber(subscriberId: Long) {
        viewModelScope.launch {
            if (currentUser.value?.role != "ADMIN" && currentUser.value?.canDelete != true) {
                _message.value = "ليس لديك صلاحية حذف المشتركين"
                return@launch
            }
            repository.deleteSubscriber(subscriberId)
            _message.value = "تم حذف المشترك وجميع بياناته"
        }
    }

    fun generateMonthlyBills(month: Int, year: Int) {
        viewModelScope.launch {
            val count = repository.generateMonthlyBillsForActiveSubscribers(month, year)
            if (count > 0) {
                _message.value = "تم إصدار $count فاتورة لشهر $month / $year"
                triggerAutoBackup()
            } else {
                _message.value = "جميع المشتركين لديهم فواتير لهذا الشهر بالفعل"
            }
        }
    }

    fun addSingleBillForSubscriber(subscriberId: Long, month: Int, year: Int, amperes: Double, pricePerAmpere: Double, customTotal: Double? = null) {
        viewModelScope.launch {
            val success = repository.addSingleBillForSubscriber(subscriberId, month, year, amperes, pricePerAmpere, customTotal)
            if (success) {
                _message.value = "تم إضافة الفاتورة/الدين بنجاح لشهر $month / $year"
                triggerAutoBackup()
            } else {
                _message.value = "توجد فاتورة سابقة محددة لهذا المشترك في شهر $month / $year"
            }
        }
    }

    fun recordPayment(billId: Long, amount: Double, collectorName: String? = null, notes: String = "") {
        viewModelScope.launch {
            if (amount <= 0) {
                _message.value = "يرجى إدخال مبلغ صحيح للدفعة"
                return@launch
            }
            val collector = if (!collectorName.isNullOrBlank()) collectorName else (currentUser.value?.name ?: "الجابي")
            val payment = repository.recordPayment(billId, amount, collector, notes)
            if (payment != null) {
                _message.value = "تم تسجيل الدفعة بنجاح وتحديث حساب الدين بواسطة ($collector)"
                triggerAutoBackup()
                triggerAutoSyncIfOnline()
            } else {
                _message.value = "تعذر العثور على الفاتورة"
            }
        }
    }

    /**
     * Records full payment for a subscriber's unpaid / remaining bills for the specified month/year (or all remaining bills if not specified).
     * Automatically creates the bill if none exists yet for that month.
     */
    fun paySubscriberInFull(
        subscriberId: Long,
        notes: String = "",
        targetMonth: Int? = null,
        targetYear: Int? = null
    ) {
        viewModelScope.launch {
            var subBills = bills.value.filter {
                it.subscriberId == subscriberId &&
                (targetMonth == null || targetMonth == 0 || it.month == targetMonth) &&
                (targetYear == null || it.year == targetYear)
            }

            // If no bill exists for this specific month, create one automatically
            if (subBills.isEmpty() && targetMonth != null && targetMonth > 0 && targetYear != null) {
                val sub = repository.dao.getSubscriberById(subscriberId)
                if (sub != null) {
                    val total = (sub.amperes * sub.defaultPricePerAmpere) + sub.fixedFee
                    val billCode = "INV-$targetYear${String.format(Locale.US, "%02d", targetMonth)}-${sub.id}"
                    val newBill = Bill(
                        billCode = billCode,
                        subscriberId = sub.id,
                        subscriberName = sub.name,
                        subscriberCode = sub.subscriberCode,
                        month = targetMonth,
                        year = targetYear,
                        amperes = sub.amperes,
                        pricePerAmpere = sub.defaultPricePerAmpere,
                        fixedFee = sub.fixedFee,
                        totalAmount = total,
                        paidAmount = 0.0,
                        remainingAmount = total,
                        status = "UNPAID"
                    )
                    val insertedId = repository.dao.insertBill(newBill)
                    subBills = listOf(newBill.copy(id = insertedId))
                }
            }

            val unpaidBills = subBills.filter { it.remainingAmount > 0 }
            if (unpaidBills.isEmpty()) {
                _message.value = "المشترك مسدد بالكامل بالفعل"
                return@launch
            }
            val collector = currentUser.value?.name ?: "الجابي"
            for (bill in unpaidBills) {
                repository.recordPayment(bill.id, bill.remainingAmount, collector, if (notes.isBlank()) "سداد كامل للاشتراك" else notes)
            }
            _message.value = "تم تسجيل السداد الكامل للمشترك بنجاح 🟢"
            triggerAutoBackup()
            triggerAutoSyncIfOnline()
        }
    }

    /**
     * Records partial payment for a subscriber's remaining bills for the specified month/year.
     * Automatically creates the bill if none exists yet for that month.
     */
    fun recordSubscriberPartialPayment(
        subscriberId: Long,
        amount: Double,
        notes: String = "",
        targetMonth: Int? = null,
        targetYear: Int? = null
    ) {
        viewModelScope.launch {
            if (amount <= 0) {
                _message.value = "يرجى إدخال مبلغ صحيح"
                return@launch
            }
            var subBills = bills.value.filter {
                it.subscriberId == subscriberId &&
                (targetMonth == null || targetMonth == 0 || it.month == targetMonth) &&
                (targetYear == null || it.year == targetYear)
            }

            if (subBills.isEmpty() && targetMonth != null && targetMonth > 0 && targetYear != null) {
                val sub = repository.dao.getSubscriberById(subscriberId)
                if (sub != null) {
                    val total = (sub.amperes * sub.defaultPricePerAmpere) + sub.fixedFee
                    val billCode = "INV-$targetYear${String.format(Locale.US, "%02d", targetMonth)}-${sub.id}"
                    val newBill = Bill(
                        billCode = billCode,
                        subscriberId = sub.id,
                        subscriberName = sub.name,
                        subscriberCode = sub.subscriberCode,
                        month = targetMonth,
                        year = targetYear,
                        amperes = sub.amperes,
                        pricePerAmpere = sub.defaultPricePerAmpere,
                        fixedFee = sub.fixedFee,
                        totalAmount = total,
                        paidAmount = 0.0,
                        remainingAmount = total,
                        status = "UNPAID"
                    )
                    val insertedId = repository.dao.insertBill(newBill)
                    subBills = listOf(newBill.copy(id = insertedId))
                }
            }

            val unpaidBills = subBills.filter { it.remainingAmount > 0 }
            if (unpaidBills.isEmpty()) {
                _message.value = "لا توجد فواتير متبقية على هذا المشترك"
                return@launch
            }
            val collector = currentUser.value?.name ?: "الجابي"
            var remainingToPay = amount
            for (bill in unpaidBills) {
                if (remainingToPay <= 0) break
                val payForThisBill = minOf(remainingToPay, bill.remainingAmount)
                repository.recordPayment(bill.id, payForThisBill, collector, if (notes.isBlank()) "سداد جزئي" else notes)
                remainingToPay -= payForThisBill
            }
            _message.value = "تم تسجيل السداد الجزئي بنجاح 🟡"
            triggerAutoBackup()
            triggerAutoSyncIfOnline()
        }
    }

    /**
     * Reverts all payments for a subscriber's bills back to unpaid status.
     */
    fun revertSubscriberAllPayments(
        subscriberId: Long,
        targetMonth: Int? = null,
        targetYear: Int? = null
    ) {
        viewModelScope.launch {
            val subBills = bills.value.filter {
                it.subscriberId == subscriberId &&
                it.paidAmount > 0 &&
                (targetMonth == null || targetMonth == 0 || it.month == targetMonth) &&
                (targetYear == null || it.year == targetYear)
            }
            if (subBills.isEmpty()) {
                _message.value = "المشترك ليس لديه دفعات مسجلة لإلغائها"
                return@launch
            }
            for (bill in subBills) {
                repository.revertBillPayment(bill.id)
            }
            _message.value = "تم التراجع عن جميع دفعات المشترك وإعادتها كـ غير مدفوعة 🔴"
            triggerAutoBackup()
            triggerAutoSyncIfOnline()
        }
    }

    /**
     * Reverts payment on a bill (resets back to UNPAID, restores remaining amount, deletes payment records)
     */
    fun revertBillPayment(billId: Long) {
        viewModelScope.launch {
            val success = repository.revertBillPayment(billId)
            if (success) {
                _message.value = "تم التراجع عن سداد الفاتورة بنجاح وإعادتها كـ غير مدفوعة ↩️"
                triggerAutoBackup()
                triggerAutoSyncIfOnline()
            } else {
                _message.value = "تعذر إلغاء سداد الفاتورة"
            }
        }
    }

    /**
     * Reverts a single payment receipt and updates the bill's remaining amount and status.
     */
    fun revertSinglePayment(paymentId: Long) {
        viewModelScope.launch {
            val success = repository.revertSinglePayment(paymentId)
            if (success) {
                _message.value = "تم حذف إيصال السداد وتحديث الفاتورة وإجمالي الديون فوراً ↩️"
                triggerAutoBackup()
                triggerAutoSyncIfOnline()
            } else {
                _message.value = "تعذر حذف إيصال السداد"
            }
        }
    }

    fun addExpense(category: String, amount: Double, description: String, notes: String) {
        viewModelScope.launch {
            if (amount <= 0 || description.isBlank()) {
                _message.value = "يرجى كتابة وصف ومبلغ صحيح للمصروف"
                return@launch
            }
            val recorder = currentUser.value?.name ?: "المدير"
            repository.addExpense(category, amount, description, notes, recorder)
            _message.value = "تمت إضافة المصروف بنجاح"
            triggerAutoBackup()
            triggerAutoSyncIfOnline()
        }
    }

    fun deleteExpense(id: Long) {
        viewModelScope.launch {
            if (currentUser.value?.role != "ADMIN") {
                _message.value = "الصلاحية محصورة لمدير النظام"
                return@launch
            }
            repository.deleteExpense(id)
            _message.value = "تم حذف المصروف"
            triggerAutoBackup()
            triggerAutoSyncIfOnline()
        }
    }

    // --- SECURITY & APP LOCK (SharedPreferences) ---
    private val sharedPreferences = application.getSharedPreferences("generator_app_security_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val PREF_KEY_APP_LOCK_ENABLED = "pref_key_app_lock_enabled"
        private const val PREF_KEY_LAST_SYNC_TIME = "pref_key_last_sync_time"
        private const val PREF_KEY_AUTO_SYNC_CODE = "pref_key_auto_sync_code"
    }

    val isSyncing = MutableStateFlow(false)
    val cloudSyncCode = MutableStateFlow<String?>(
        sharedPreferences.getString(PREF_KEY_AUTO_SYNC_CODE, null)
    )
    val lastSyncTimestamp = MutableStateFlow<Long?>(
        sharedPreferences.getLong(PREF_KEY_LAST_SYNC_TIME, 0L).takeIf { it > 0L }
    )

    fun triggerAutoSyncIfOnline() {
        if (!isOnline.value) return
        viewModelScope.launch {
            try {
                val code = com.example.generator.util.CloudSyncUtil.uploadToCloud(
                    subscribers = subscribers.value,
                    subscriberGroups = subscriberGroups.value,
                    bills = bills.value,
                    payments = payments.value,
                    expenses = expenses.value,
                    users = users.value,
                    settings = settings.value
                )
                if (code != null) {
                    cloudSyncCode.value = code
                    val now = System.currentTimeMillis()
                    lastSyncTimestamp.value = now
                    sharedPreferences.edit()
                        .putLong(PREF_KEY_LAST_SYNC_TIME, now)
                        .putString(PREF_KEY_AUTO_SYNC_CODE, code)
                        .apply()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // --- AUTHENTICATION & LOGIN ACTIONS ---
    fun signInWithGoogleFast(displayName: String, email: String, photoUrl: String? = null) {
        val profile = authAndSecurityManager.signInWithGoogle(displayName, email, photoUrl)
        val adminUser = users.value.find { it.role == "ADMIN" }
        currentUser.value = adminUser ?: UserAccount(
            id = 1,
            username = email.substringBefore("@"),
            name = displayName,
            pinCode = "1234",
            role = "ADMIN",
            canDelete = true,
            canViewFinancials = true,
            isActive = true
        )
        _remainingTrialDays.value = authAndSecurityManager.getRemainingTrialDays()
        _isTrialActive.value = authAndSecurityManager.isTrialActive()
        isAppLocked.value = false
        _message.value = "مرحباً بك! تم تسجيل الدخول بنجاح بحساب Google: $displayName"
        triggerAutoSyncIfOnline()
    }

    fun signInWithPhone(phoneNumber: String, displayName: String = "صاحب المولدة") {
        val profile = authAndSecurityManager.signInWithPhone(phoneNumber, displayName)
        val adminUser = users.value.find { it.role == "ADMIN" }
        currentUser.value = adminUser ?: UserAccount(
            id = 1,
            username = phoneNumber,
            name = displayName,
            pinCode = "1234",
            role = "ADMIN",
            canDelete = true,
            canViewFinancials = true,
            isActive = true
        )
        _remainingTrialDays.value = authAndSecurityManager.getRemainingTrialDays()
        _isTrialActive.value = authAndSecurityManager.isTrialActive()
        isAppLocked.value = false
        _message.value = "تم تسجيل الدخول برقم الهاتف $phoneNumber بنجاح"
        triggerAutoSyncIfOnline()
    }

    fun signOut() {
        authAndSecurityManager.signOut()
        _message.value = "تم تسجيل الخروج بنجاح"
    }

    fun setLockType(type: com.example.generator.util.LockType) {
        authAndSecurityManager.setLockType(type)
        _message.value = "تم تغيير نوع القفل إلى ${type.name}"
    }

    fun setSecurityPin(pin: String) {
        authAndSecurityManager.setSecurityPin(pin)
        _message.value = "تم تحديث رمز PIN بنجاح"
    }

    fun setSecurityPattern(pattern: String) {
        authAndSecurityManager.setSecurityPattern(pattern)
        _message.value = "تم حفظ نمط الشاشة الجديد بنجاح"
    }

    fun verifyPatternAndUnlock(enteredPattern: String): Boolean {
        val saved = securityPattern.value
        val isValid = saved == enteredPattern.trim()
        if (isValid) {
            isAppLocked.value = false
            _message.value = "تم فتح قفل الشاشة بالنمط بنجاح"
            return true
        } else {
            _message.value = "نمط الشاشة غير صحيح"
            return false
        }
    }

    fun unlockWithBiometrics(): Boolean {
        isAppLocked.value = false
        _message.value = "تم التحقق بالبصمة البيومترية وفتح التطبيق بنجاح ✅"
        return true
    }

    fun simulateTrialExpiry(isExpired: Boolean) {
        if (isExpired) {
            _remainingTrialDays.value = 0
            _isTrialActive.value = false
            _message.value = "تم محاكاة انتهاء الفترة التجريبية (7 أيام) - يلزم الاشتراك"
        } else {
            _remainingTrialDays.value = 7
            _isTrialActive.value = true
            _message.value = "تمت استعادة صلاحية الفترة التجريبية (7 أيام كاملة)"
        }
    }

    // Check SharedPreferences on launch to set initial locked state (defaults to false for easy direct access as requested)
    val requirePinOnLaunch = MutableStateFlow(
        authAndSecurityManager.isAppLockEnabled.value
    )
    val isAppLocked = MutableStateFlow(
        authAndSecurityManager.isAppLockEnabled.value
    )

    fun setAppLockEnabled(enabled: Boolean) {
        authAndSecurityManager.setAppLockEnabled(enabled)
        sharedPreferences.edit().putBoolean(PREF_KEY_APP_LOCK_ENABLED, enabled).apply()
        requirePinOnLaunch.value = enabled
        if (enabled) {
            isAppLocked.value = true
            _message.value = "تم تفعيل حماية التطبيق وقفل الشاشة بنجاح 🔒"
        } else {
            isAppLocked.value = false
            _message.value = "تم إلغاء قفل الشاشة، سيتم فتح التطبيق مباشرة دون كلمة سر 🔓"
        }
    }

    fun toggleRequirePinOnLaunch(enabled: Boolean) {
        setAppLockEnabled(enabled)
    }

    fun onAppBackgrounded() {
        // Only lock if explicitly enabled
        val isEnabled = authAndSecurityManager.isAppLockEnabled.value
        if (isEnabled) {
            isAppLocked.value = true
        }
    }

    // Password Reset & Recovery
    private val _generatedResetCode = MutableStateFlow<String?>(null)
    val generatedResetCode: StateFlow<String?> = _generatedResetCode.asStateFlow()

    fun sendPasswordResetCode(contactInfo: String): String {
        val code = (100000..999999).random().toString()
        _generatedResetCode.value = code
        _message.value = "تم إرسال رمز إعادة التعيين إلى $contactInfo بنجاح!"
        return code
    }

    fun verifyResetCodeAndResetPin(user: UserAccount, enteredCode: String, newPin: String): Boolean {
        val validCode = _generatedResetCode.value
        if (validCode != null && validCode == enteredCode.trim()) {
            viewModelScope.launch {
                val updatedUser = user.copy(pinCode = newPin.trim())
                repository.addUser(updatedUser)
                currentUser.value = updatedUser
                isAppLocked.value = false
                _generatedResetCode.value = null
                _message.value = "تمت إعادة تعيين كلمة المرور بنجاح وتسجيل الدخول بحساب ${updatedUser.name}!"
            }
            return true
        } else {
            _message.value = "رمز إعادة التعيين الذي أدخلته غير صحيح!"
            return false
        }
    }

    fun unlockApp(user: UserAccount?, enteredPin: String): Boolean {
        fun normalizeDigits(input: String): String {
            return input
                .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
                .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
                .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
                .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('٩', '9')
                .trim()
        }

        val normalizedEntered = normalizeDigits(enteredPin)
        if (normalizedEntered.isEmpty()) {
            _message.value = "يرجى كتابة رمز الدخول (PIN)"
            return false
        }

        val userList = users.value.ifEmpty {
            listOf(
                UserAccount(
                    id = 1,
                    username = "admin",
                    name = "المدير العام",
                    pinCode = "1234",
                    role = "ADMIN",
                    canDelete = true,
                    canViewFinancials = true,
                    isActive = true
                )
            )
        }

        val targetUser = user?.let { u ->
            userList.find { it.id == u.id || it.username == u.username } ?: u
        }

        val matchedUser = if (targetUser != null) {
            val normalizedUserPin = normalizeDigits(targetUser.pinCode)
            val isValid = normalizedUserPin.isNotEmpty() && normalizedUserPin == normalizedEntered
            if (isValid) targetUser else null
        } else {
            // Match against any user having the entered PIN
            userList.find { normalizeDigits(it.pinCode) == normalizedEntered }
        }

        if (matchedUser != null) {
            currentUser.value = matchedUser
            isAppLocked.value = false
            _message.value = "تم الدخول بنجاح! أهلاً بك: ${matchedUser.name}"
            return true
        } else {
            _message.value = "رمز الدخول (PIN) غير صحيح"
            return false
        }
    }

    fun lockApp() {
        isAppLocked.value = true
        _message.value = "تم قفل الشاشة وحماية التطبيق بنجاح"
    }

    fun saveSettings(
        generatorName: String,
        ownerName: String,
        phone: String,
        address: String,
        pricePerAmpere: Double,
        mastercardNumber: String = "5324 8899 7766 5544"
    ) {
        viewModelScope.launch {
            val current = settings.value ?: GeneratorSettings()
            val updated = current.copy(
                generatorName = generatorName,
                ownerName = ownerName,
                phone = phone,
                address = address,
                defaultPricePerAmpere = pricePerAmpere,
                mastercardNumber = mastercardNumber
            )
            repository.saveSettings(updated)
            // Automatically update price for all existing subscribers
            repository.updateAllSubscribersDefaultPrice(pricePerAmpere)
            _message.value = "تم حفظ الإعدادات وتطبيق تسعيرة الأمبير ($pricePerAmpere د.ع) على جميع المشتركين تلقائياً"
        }
    }

    fun verifyAndSwitchUser(user: UserAccount, enteredPin: String): Boolean {
        fun normalizeDigits(input: String): String {
            return input
                .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
                .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
                .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
                .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('٩', '9')
                .trim()
        }

        val normalizedEntered = normalizeDigits(enteredPin)
        val latestUser = users.value.find { it.id == user.id || it.username == user.username } ?: user
        val normalizedUserPin = normalizeDigits(latestUser.pinCode)

        val isPinCorrect = normalizedUserPin.isNotEmpty() && normalizedUserPin == normalizedEntered

        if (isPinCorrect) {
            currentUser.value = latestUser
            _message.value = "تم تسجيل الدخول بنجاح بحساب: ${latestUser.name}"
            return true
        } else {
            _message.value = "رمز الدخول (PIN) غير صحيح"
            return false
        }
    }

    fun switchUserRoleDirect(user: UserAccount) {
        currentUser.value = user
        _message.value = "تم الانتقال إلى حساب: ${user.name} (${if (user.role == "ADMIN") "صاحب المولدة" else "جابي"})"
    }

    fun addUserAccount(username: String, name: String, pin: String, role: String, canDelete: Boolean, canViewFinancials: Boolean) {
        viewModelScope.launch {
            if (username.isBlank() || pin.isBlank() || name.isBlank()) {
                _message.value = "يرجى إكمال جميع الحقول وإدخال رمز PIN"
                return@launch
            }
            fun normalizeDigits(input: String): String {
                return input
                    .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
                    .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
                    .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
                    .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
                    .trim()
            }
            val user = UserAccount(
                username = username.trim(),
                name = name.trim(),
                pinCode = normalizeDigits(pin),
                role = role,
                canDelete = canDelete,
                canViewFinancials = canViewFinancials,
                isActive = true
            )
            repository.addUser(user)
            _message.value = "تمت إضافة حساب جديد للجابي: $name"
        }
    }

    fun updateUserAccount(user: UserAccount) {
        viewModelScope.launch {
            repository.addUser(user)
            if (currentUser.value?.id == user.id) {
                currentUser.value = user
            }
            _message.value = "تم تحديث بيانات وصلاحيات الحساب: ${user.name}"
        }
    }

    fun deleteUserAccount(id: Long) {
        viewModelScope.launch {
            val userToDelete = users.value.find { it.id == id }
            if (userToDelete?.role == "ADMIN" && users.value.count { it.role == "ADMIN" } <= 1) {
                _message.value = "لا يمكن حذف حساب صاحب المولدة الرئيسي الوحيد"
                return@launch
            }
            repository.deleteUser(id)
            _message.value = "تم حذف الحساب بنجاح"
        }
    }

    // Cloud Online Sync & Multi-device Sync
    fun uploadToCloudSync() {
        viewModelScope.launch {
            isSyncing.value = true
            val code = com.example.generator.util.CloudSyncUtil.uploadToCloud(
                subscribers = subscribers.value,
                subscriberGroups = subscriberGroups.value,
                bills = bills.value,
                payments = payments.value,
                expenses = expenses.value,
                users = users.value,
                settings = settings.value
            )
            isSyncing.value = false
            if (code != null) {
                cloudSyncCode.value = code
                _message.value = "تم رفع وقفل النسخة السحابية بنجاح! رمز المزامنة: $code"
            } else {
                _message.value = "فشل الرفع السحابي. يرجى التحقق من الاتصال بالإنترنت"
            }
        }
    }

    fun restoreFromCloudSync(syncCode: String) {
        viewModelScope.launch {
            if (syncCode.isBlank()) {
                _message.value = "يرجى إدخال رمز المزامنة السحابية"
                return@launch
            }
            isSyncing.value = true
            val bundle = com.example.generator.util.CloudSyncUtil.downloadFromCloud(syncCode)
            isSyncing.value = false
            if (bundle != null) {
                repository.restoreDatabase(
                    subscribersList = bundle.subscribers,
                    subscriberGroupsList = bundle.subscriberGroups,
                    billsList = bundle.bills,
                    paymentsList = bundle.payments,
                    expensesList = bundle.expenses,
                    usersList = bundle.users,
                    settingsObj = bundle.settings
                )
                cloudSyncCode.value = syncCode
                _message.value = "تمت المزامنة واستعادة البيانات بنجاح من السحابة!"
            } else {
                _message.value = "تعذر العثور على البيانات السحابية بهذا الرمز"
            }
        }
    }

    // Backup & Export
    fun exportToExcelCsv(context: Context): File? {
        val subs = subscribers.value
        val grps = subscriberGroups.value
        val b = bills.value
        val p = payments.value
        val e = expenses.value
        val s = settings.value
        return try {
            val file = ExcelExporterImporter.exportToExcelCsv(context, subs, grps, b, p, e, s)
            _message.value = "تم حفظ التقرير في مجلد التنزيلات (Downloads): ${file.name}"
            file
        } catch (ex: Exception) {
            ex.printStackTrace()
            _message.value = "خطأ أثناء حفظ التقرير"
            null
        }
    }

    fun exportDebtsToExcelCsv(context: Context): File? {
        val b = bills.value
        val s = settings.value
        return try {
            val file = ExcelExporterImporter.exportDebtsToExcelCsv(context, b, s)
            _message.value = "تم حفظ كشف الديون في مجلد التنزيلات (Downloads): ${file.name}"
            file
        } catch (ex: Exception) {
            ex.printStackTrace()
            _message.value = "خطأ أثناء تصدير كشف الديون"
            null
        }
    }

    fun exportDailyPaymentsToExcelCsv(context: Context, paymentsList: List<Payment>, dateLabel: String): File? {
        val s = settings.value
        return try {
            val file = ExcelExporterImporter.exportDailyPaymentsToExcelCsv(context, paymentsList, dateLabel, s)
            _message.value = "تم حفظ كشف المقبوضات في مجلد التنزيلات (Downloads): ${file.name}"
            file
        } catch (ex: Exception) {
            ex.printStackTrace()
            _message.value = "خطأ أثناء تصدير كشف المقبوضات"
            null
        }
    }

    fun exportExpensesToExcelCsv(context: Context): File? {
        val e = expenses.value
        val s = settings.value
        return try {
            val file = ExcelExporterImporter.exportExpensesToExcelCsv(context, e, s)
            _message.value = "تم حفظ كشف المصروفات في مجلد التنزيلات (Downloads): ${file.name}"
            file
        } catch (ex: Exception) {
            ex.printStackTrace()
            _message.value = "خطأ أثناء تصدير كشف المصروفات"
            null
        }
    }

    fun exportToJsonBackup(context: Context): File? {
        val subs = subscribers.value
        val grps = subscriberGroups.value
        val b = bills.value
        val p = payments.value
        val e = expenses.value
        val u = users.value
        val s = settings.value
        return try {
            val file = ExcelExporterImporter.exportToJsonBackup(context, subs, grps, b, p, e, u, s)
            _message.value = "تم حفظ النسخة الاحتياطية في مجلد التنزيلات (Downloads): ${file.name}"
            file
        } catch (ex: Exception) {
            ex.printStackTrace()
            _message.value = "خطأ أثناء إنشاء النسخة الاحتياطية"
            null
        }
    }

    /**
     * Generates a fully formatted, multi-page professional PDF backup containing all database records:
     * - Executive summary and key operational/financial metrics
     * - Electrical line / phase settings & users
     * - Full subscribers directory and circuit breakers
     * - Comprehensive billing history and remaining debts
     * - Receipts & payment logs
     * - Expenses ledger
     */
    fun exportFullBackupPdf(context: Context): File? {
        val subs = subscribers.value
        val grps = subscriberGroups.value
        val b = bills.value
        val p = payments.value
        val e = expenses.value
        val u = users.value
        val s = settings.value
        return try {
            val file = com.example.generator.util.FullBackupPdfExporter.generateFullBackupPdf(
                context = context,
                subscribers = subs,
                subscriberGroups = grps,
                bills = b,
                payments = p,
                expenses = e,
                users = u,
                settings = s
            )
            if (file != null) {
                _message.value = "تم إنشاء وتصدير النسخة الاحتياطية الشاملة بملف PDF احترافي بنجاح! 📑"
            } else {
                _message.value = "حدث خطأ أثناء إنشاء ملف PDF للنسخة الاحتياطية"
            }
            file
        } catch (ex: Exception) {
            ex.printStackTrace()
            _message.value = "خطأ أثناء إنشاء ملف PDF للنسخة الاحتياطية"
            null
        }
    }

    fun restoreFromJsonContent(jsonContent: String) {
        viewModelScope.launch {
            try {
                val bundle = ExcelExporterImporter.parseJsonBackup(jsonContent)
                repository.restoreDatabase(
                    subscribersList = bundle.subscribers,
                    subscriberGroupsList = bundle.subscriberGroups,
                    billsList = bundle.bills,
                    paymentsList = bundle.payments,
                    expensesList = bundle.expenses,
                    usersList = bundle.users,
                    settingsObj = bundle.settings
                )
                _message.value = "تمت استعادة البيانات بنجاح والحفاظ على جميع العلاقات"
            } catch (ex: Exception) {
                ex.printStackTrace()
                _message.value = "خطأ في قراءة ملف النسخة الاحتياطية"
            }
        }
    }
}
