package com.example.generator.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

object BarcodeGenerator {

    private val PATTERNS = arrayOf(
        "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213", // 0-9
        "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132", // 10-19
        "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211", // 20-29
        "212123", "212321", "202132", "111323", "131123", "131321", "112313", "132113", "132311", "211313", // 30-39
        "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331", // 40-49
        "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111", // 50-59
        "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214", // 60-69
        "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111", // 70-79
        "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141", // 80-89
        "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141", // 90-99
        "114131", "311141", "411131", "211412", "211214", "211232", "2331112" // 100-106
    )

    fun createBarcodeBitmap(codeText: String, width: Int = 380, height: Int = 100): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = false
        }

        val cleanText = codeText.trim()
        val codes = mutableListOf<Int>()
        codes.add(104) // Start B

        var checksum = 104
        for (i in cleanText.indices) {
            val charCode = cleanText[i].code
            val code = if (charCode in 32..126) charCode - 32 else 0
            codes.add(code)
            checksum += (i + 1) * code
        }
        codes.add(checksum % 103)
        codes.add(106) // Stop

        val modules = StringBuilder()
        for (code in codes) {
            val pattern = if (code in 0..106) PATTERNS[code] else PATTERNS[0]
            var isBar = true
            for (char in pattern) {
                val moduleWidth = char.toString().toIntOrNull() ?: 1
                for (m in 0 until moduleWidth) {
                    modules.append(if (isBar) '1' else '0')
                }
                isBar = !isBar
            }
        }

        val totalModules = modules.length
        val quietZone = 20
        val usableWidth = width - (quietZone * 2)
        val moduleWidthPx = usableWidth.toFloat() / totalModules.toFloat()

        var currentX = quietZone.toFloat()
        val barHeight = height - 26f

        for (i in 0 until totalModules) {
            if (modules[i] == '1') {
                canvas.drawRect(currentX, 10f, currentX + moduleWidthPx, barHeight, paint)
            }
            currentX += moduleWidthPx
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 14f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(cleanText, (width / 2).toFloat(), height - 6f, textPaint)

        return bitmap
    }
}
