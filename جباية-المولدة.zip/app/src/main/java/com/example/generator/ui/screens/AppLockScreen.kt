package com.example.generator.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.generator.data.entity.UserAccount
import com.example.generator.ui.components.ElectricBadge
import com.example.generator.ui.components.GlassCard
import com.example.generator.ui.components.Glossy3DIcon
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.LockType
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppLockScreen(viewModel: GeneratorViewModel) {
    val context = LocalContext.current
    val usersFromDb by viewModel.users.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val lockType by viewModel.lockType.collectAsState()

    val fallbackAdmin = remember {
        UserAccount(
            id = 1,
            username = "admin",
            name = "المدير العام",
            pinCode = "1234",
            role = "ADMIN",
            canDelete = true,
            canViewFinancials = true,
            isActive = true
        )
    }
    val fallbackCollector = remember {
        UserAccount(
            id = 2,
            username = "gabi",
            name = "الجابي أحمد",
            pinCode = "0000",
            role = "COLLECTOR",
            canDelete = false,
            canViewFinancials = false,
            isActive = true
        )
    }

    val effectiveUsers = remember(usersFromDb) {
        if (usersFromDb.isNotEmpty()) usersFromDb else listOf(fallbackAdmin, fallbackCollector)
    }

    var selectedUser by remember(effectiveUsers) {
        mutableStateOf(effectiveUsers.firstOrNull { it.role == "ADMIN" } ?: effectiveUsers.firstOrNull())
    }
    var pinInput by remember { mutableStateOf("") }
    var patternSelectedDots by remember { mutableStateOf<List<Int>>(emptyList()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var passwordVisible by remember { mutableStateOf(false) }
    var showForgotPasswordDialog by remember { mutableStateOf(false) }

    // Intercept hardware back button so app cannot be bypassed
    BackHandler(enabled = true) {
        val activity = context as? Activity
        activity?.moveTaskToBack(true)
    }

    val genName = settings?.generatorName ?: "منظومة إدارة وجباية المولدات"

    fun attemptUnlockWithPin(targetPin: String = pinInput) {
        val user = selectedUser ?: effectiveUsers.firstOrNull()
        if (targetPin.isBlank()) {
            errorMessage = "يرجى إدخال رمز الدخول (PIN)"
            return
        }
        val success = viewModel.unlockApp(user, targetPin)
        if (!success) {
            errorMessage = "رمز PIN غير صحيح! يرجى التأكد من الرمز وإعادة المحاولة."
        }
    }

    fun attemptUnlockWithPattern() {
        val currentPatternStr = patternSelectedDots.joinToString(",")
        if (currentPatternStr.isBlank()) {
            errorMessage = "يرجى رسم نمط الشاشة"
            return
        }
        val success = viewModel.verifyPatternAndUnlock(currentPatternStr)
        if (!success) {
            errorMessage = "نمط الشاشة غير صحيح! يرجى إعادة المحاولة."
            patternSelectedDots = emptyList()
        }
    }

    LaunchedEffect(pinInput) {
        if (pinInput.length == 4 && lockType == LockType.PIN) {
            attemptUnlockWithPin(pinInput)
        }
    }

    MidnightCyberBackground {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(24.dp),
                borderColor = ElectricCyan.copy(alpha = 0.45f),
                borderWidth = 1.2.dp,
                backgroundColor = Color(0xCC0C1738)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Lock 3D Icon
                    Glossy3DIcon(
                        imageRes = R.drawable.icon_3d_energy_1787310378195,
                        contentDescription = "Security Lock",
                        size = 64.dp,
                        glowColor = ElectricCyan
                    )

                    Text(
                        text = genName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = when (lockType) {
                            LockType.BIOMETRIC -> "تأكيد الدخول ببصمة الإصبع أو الوجه 🛡️"
                            LockType.PATTERN -> "تأكيد الدخول برسم نمط الشاشة 🔒"
                            else -> "أدخل رمز PIN لفتح التطبيق 🔒"
                        },
                        fontSize = 12.sp,
                        color = TextCyanSecondary,
                        textAlign = TextAlign.Center
                    )

                    HorizontalDivider(
                        color = Color(0x2238BDF8),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )

                    // User account selection chips
                    Text(
                        text = "اختر الحساب النشط:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextWhitePrimary,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        effectiveUsers.forEach { u ->
                            val isSelected = selectedUser?.id == u.id || selectedUser?.username == u.username
                            GlassCard(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        selectedUser = u
                                        pinInput = ""
                                        patternSelectedDots = emptyList()
                                        errorMessage = null
                                    },
                                shape = RoundedCornerShape(14.dp),
                                borderColor = if (isSelected) ElectricCyan else Color(0x2238BDF8),
                                borderWidth = if (isSelected) 1.5.dp else 1.dp,
                                backgroundColor = if (isSelected) Color(0xCC0E2554) else Color(0x660B142B),
                                elevation = if (isSelected) 6.dp else 2.dp
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (u.role == "ADMIN") Icons.Default.AdminPanelSettings else Icons.Default.Person,
                                        contentDescription = null,
                                        tint = if (isSelected) ElectricCyan else TextCyanSecondary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Text(
                                        text = u.name,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 12.sp,
                                        color = TextWhitePrimary,
                                        textAlign = TextAlign.Center
                                    )
                                    ElectricBadge(
                                        text = if (u.role == "ADMIN") "مدير النظام" else "جابي",
                                        color = if (u.role == "ADMIN") MetallicEmerald else ElectricCyan
                                    )
                                }
                            }
                        }
                    }

                    // Lock Type UI Rendering
                    when (lockType) {
                        LockType.BIOMETRIC -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0x3300F0FF),
                                    border = BorderStroke(2.dp, ElectricCyan),
                                    modifier = Modifier
                                        .size(90.dp)
                                        .clickable { viewModel.unlockWithBiometrics() }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Fingerprint,
                                            contentDescription = "استخدام البصمة",
                                            tint = ElectricCyan,
                                            modifier = Modifier.size(50.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "المس مستشعر البصمة أو انقر هنا للتحقق البيومتري الفوري",
                                    fontSize = 12.sp,
                                    color = TextCyanSecondary,
                                    textAlign = TextAlign.Center
                                )

                                Button(
                                    onClick = { viewModel.unlockWithBiometrics() },
                                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = MidnightNavyDeep),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Fingerprint, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("تأكيد البصمة البيومترية الرسمية", fontWeight = FontWeight.Bold)
                                }

                                TextButton(onClick = { viewModel.setLockType(LockType.PIN) }) {
                                    Text("الدخول بواسطة رمز PIN بدلاً من ذلك", fontSize = 12.sp, color = ElectricCyan)
                                }
                            }
                        }

                        LockType.PATTERN -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "المس النقاط بالتسلسل لتشكيل النمط (النقاط المحددة: ${patternSelectedDots.size})",
                                    fontSize = 12.sp,
                                    color = TextCyanSecondary
                                )

                                Column(
                                    verticalArrangement = Arrangement.spacedBy(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(8.dp)
                                ) {
                                    for (row in 0..2) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                                            for (col in 0..2) {
                                                val dotIndex = row * 3 + col
                                                val isDotSelected = patternSelectedDots.contains(dotIndex)
                                                Surface(
                                                    shape = CircleShape,
                                                    color = if (isDotSelected) ElectricCyan else Color(0x3300F0FF),
                                                    border = BorderStroke(2.dp, if (isDotSelected) ElectricCyan else Color(0x4438BDF8)),
                                                    modifier = Modifier
                                                        .size(46.dp)
                                                        .clickable {
                                                            if (!patternSelectedDots.contains(dotIndex)) {
                                                                patternSelectedDots = patternSelectedDots + dotIndex
                                                                errorMessage = null
                                                            }
                                                        }
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = if (isDotSelected) "${patternSelectedDots.indexOf(dotIndex) + 1}" else "•",
                                                            color = if (isDotSelected) MidnightNavyDeep else TextCyanSecondary,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 16.sp
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { patternSelectedDots = emptyList(); errorMessage = null },
                                        border = BorderStroke(1.dp, Color(0x3338BDF8)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("مسح النمط", color = TextWhitePrimary)
                                    }
                                    Button(
                                        onClick = { attemptUnlockWithPattern() },
                                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = MidnightNavyDeep),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("تأكيد وفتح", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        else -> {
                            OutlinedTextField(
                                value = pinInput,
                                onValueChange = {
                                    pinInput = it
                                    errorMessage = null
                                },
                                readOnly = true,
                                label = { Text("رمز الدخول (PIN)") },
                                placeholder = { Text("استخدم لوحة الأرقام أدناه لإدخال الرمز") },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = null,
                                            tint = ElectricCyan
                                        )
                                    }
                                },
                                singleLine = true,
                                isError = errorMessage != null,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            // Keypad with Glass Cyber Style
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val keyRows = listOf(
                                    listOf("1", "2", "3"),
                                    listOf("4", "5", "6"),
                                    listOf("7", "8", "9"),
                                    listOf("C", "0", "⌫")
                                )

                                keyRows.forEach { row ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        row.forEach { key ->
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(44.dp)
                                                    .clickable {
                                                        when (key) {
                                                            "C" -> {
                                                                pinInput = ""
                                                                errorMessage = null
                                                            }
                                                            "⌫" -> {
                                                                if (pinInput.isNotEmpty()) {
                                                                    pinInput = pinInput.dropLast(1)
                                                                    errorMessage = null
                                                                }
                                                            }
                                                            else -> {
                                                                if (pinInput.length < 8) {
                                                                    pinInput += key
                                                                    errorMessage = null
                                                                }
                                                            }
                                                        }
                                                    },
                                                shape = RoundedCornerShape(10.dp),
                                                color = when (key) {
                                                    "C" -> Color(0x33EF4444)
                                                    "⌫" -> Color(0x3300F0FF)
                                                    else -> Color(0x331E293B)
                                                },
                                                border = BorderStroke(1.dp, Color(0x2238BDF8))
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = key,
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = when (key) {
                                                            "C" -> MetallicCrimson
                                                            "⌫" -> ElectricCyan
                                                            else -> TextWhitePrimary
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            Button(
                                onClick = { attemptUnlockWithPin() },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = MidnightNavyDeep),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("دخول وفتح التطبيق", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }

                    if (errorMessage != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0x33EF4444),
                            border = BorderStroke(1.dp, MetallicCrimson),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = errorMessage!!,
                                color = Color(0xFFFCA5A5),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    TextButton(
                        onClick = { showForgotPasswordDialog = true },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = ElectricCyan
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "نسيت كلمة المرور / استعادة الرمز؟",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElectricCyan
                        )
                    }
                }
            }
        }
    }

    if (showForgotPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showForgotPasswordDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LockReset, contentDescription = null, tint = ElectricCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("استعادة رمز الدخول (PIN)", fontWeight = FontWeight.Bold, color = TextWhitePrimary)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "الرموز الافتراضية الأولية للنظام:",
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary,
                        fontSize = 13.sp
                    )
                    Text("• رمز المدير الافتراضي: 1234", color = TextCyanSecondary, fontSize = 12.sp)
                    Text("• رمز الجابي الافتراضي: 0000", color = TextCyanSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "إذا قمت بتغيير الرمز ونسيته، يمكنك فتح التطبيق فوراً عبر بصمة الإصبع أو إعادة تعيينه من حساب Google المسجل.",
                        color = TextCyanSecondary,
                        fontSize = 11.sp
                    )
                }
            },
            containerColor = Color(0xFF0D1838),
            confirmButton = {
                Button(
                    onClick = {
                        pinInput = "1234"
                        attemptUnlockWithPin("1234")
                        showForgotPasswordDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = MidnightNavyDeep)
                ) {
                    Text("دخول برمز المدير (1234)", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showForgotPasswordDialog = false },
                    border = BorderStroke(1.dp, Color(0x3338BDF8))
                ) {
                    Text("إغلاق", color = TextWhitePrimary)
                }
            }
        )
    }
}
