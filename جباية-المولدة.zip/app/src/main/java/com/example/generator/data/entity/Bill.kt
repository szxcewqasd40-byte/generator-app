package com.example.generator.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "bills",
    foreignKeys = [
        ForeignKey(
            entity = Subscriber::class,
            parentColumns = ["id"],
            childColumns = ["subscriberId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["subscriberId"]), Index(value = ["subscriberId", "month", "year"], unique = true)]
)
data class Bill(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val billCode: String, // e.g. INV-202608-1001
    val subscriberId: Long,
    val subscriberName: String,
    val subscriberCode: String,
    val month: Int, // 1 - 12
    val year: Int, // e.g. 2026
    val amperes: Double,
    val pricePerAmpere: Double,
    val fixedFee: Double = 0.0, // رسوم الفيزة / الاشتراك الثابت للمجموعة
    val totalAmount: Double,
    val paidAmount: Double = 0.0,
    val remainingAmount: Double = totalAmount,
    val status: String = "UNPAID", // PAID, PARTIAL, UNPAID
    val createdAt: Long = System.currentTimeMillis()
)
