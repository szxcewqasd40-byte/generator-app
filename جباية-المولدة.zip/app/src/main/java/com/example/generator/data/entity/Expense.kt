package com.example.generator.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // الوقود والكاز, الزيوت والدهن, قطع الغيار, الصيانة, أجور العاملين, الإيجار, الكهرباء والماء, الضرائب والرسوم, مصروفات أخرى
    val amount: Double,
    val expenseDate: Long = System.currentTimeMillis(),
    val description: String,
    val notes: String = "",
    val recordedBy: String = "مدير النظام"
)
