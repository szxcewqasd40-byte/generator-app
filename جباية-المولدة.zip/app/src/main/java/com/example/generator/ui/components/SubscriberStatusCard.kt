package com.example.generator.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.Subscriber
import com.example.generator.util.PrintHelper
import java.util.Locale

/**
 * فئات حالات الدفع ونظام الألوان الحركي (Color Coding) مع التوافق التام للوضع الليلي والنهاري:
 * 1. FULL_PAID: أخضر فاتح للمسدد بالكامل.
 * 2. PREVIOUS_DEBT / PARTIAL_PAID (ديون سابقة): أصفر فاتح لمن عليه ديون سابقة أو دفع جزئي.
 * 3. UNPAID: أحمر فاتح لغير المسدد للشهر الحالي.
 * 4. NO_BILLS: رمادي هادئ.
 */
enum class SubscriberPaymentStatus(
    val title: String,
    val shortLabel: String,
    val icon: ImageVector,
    val lightIndicatorColor: Color,
    val lightBgColor: Color,
    val lightBorderColor: Color,
    val lightTextColor: Color,
    val darkIndicatorColor: Color,
    val darkBgColor: Color,
    val darkBorderColor: Color,
    val darkTextColor: Color
) {
    FULL_PAID(
        title = "تم الدفع بالكامل (مسدد)",
        shortLabel = "مسدد بالكامل",
        icon = Icons.Default.CheckCircle,
        lightIndicatorColor = Color(0xFF16A34A),
        lightBgColor = Color(0xFFE8F5E9),
        lightBorderColor = Color(0xFFA5D6A7),
        lightTextColor = Color(0xFF1B5E20),
        darkIndicatorColor = Color(0xFF4ADE80),
        darkBgColor = Color(0xFF14532D).copy(alpha = 0.35f),
        darkBorderColor = Color(0xFF166534),
        darkTextColor = Color(0xFFBBF7D0)
    ),
    PREVIOUS_DEBT(
        title = "يوجد دين / دفع جزئي",
        shortLabel = "ديون سابقة",
        icon = Icons.Default.Warning,
        lightIndicatorColor = Color(0xFFD97706),
        lightBgColor = Color(0xFFFFFBEB),
        lightBorderColor = Color(0xFFFDE68A),
        lightTextColor = Color(0xFF92400E),
        darkIndicatorColor = Color(0xFFFBBF24),
        darkBgColor = Color(0xFF78350F).copy(alpha = 0.35f),
        darkBorderColor = Color(0xFF92400E),
        darkTextColor = Color(0xFFFDE68A)
    ),
    UNPAID(
        title = "غير مسدد للشهر الحالي",
        shortLabel = "غير مسدد",
        icon = Icons.Default.Cancel,
        lightIndicatorColor = Color(0xFFDC2626),
        lightBgColor = Color(0xFFFEF2F2),
        lightBorderColor = Color(0xFFFECACA),
        lightTextColor = Color(0xFF991B1B),
        darkIndicatorColor = Color(0xFFF87171),
        darkBgColor = Color(0xFF7F1D1D).copy(alpha = 0.35f),
        darkBorderColor = Color(0xFF991B1B),
        darkTextColor = Color(0xFFFECACA)
    ),
    NO_BILLS(
        title = "لا توجد فواتير",
        shortLabel = "جديد",
        icon = Icons.Default.Info,
        lightIndicatorColor = Color(0xFF64748B),
        lightBgColor = Color(0xFFF8FAFC),
        lightBorderColor = Color(0xFFE2E8F0),
        lightTextColor = Color(0xFF334155),
        darkIndicatorColor = Color(0xFF94A3B8),
        darkBgColor = Color(0xFF1E293B).copy(alpha = 0.4f),
        darkBorderColor = Color(0xFF334155),
        darkTextColor = Color(0xFFCBD5E1)
    );

    // Compatibility aliases
    val containerColor: Color get() = lightBgColor
    val borderColor: Color get() = lightBorderColor
    val contentColor: Color get() = lightTextColor
    val badgeBgColor: Color get() = lightBorderColor
    val indicatorColor: Color get() = lightIndicatorColor

    @Composable
    fun getBackgroundColor(isDark: Boolean): Color = if (isDark) darkBgColor else lightBgColor

    @Composable
    fun getBorderColor(isDark: Boolean): Color = if (isDark) darkBorderColor else lightBorderColor

    @Composable
    fun getIndicatorColor(isDark: Boolean): Color = if (isDark) darkIndicatorColor else lightIndicatorColor

    @Composable
    fun getTextColor(isDark: Boolean): Color = if (isDark) darkTextColor else lightTextColor

    companion object {
        val PARTIAL_PAID = PREVIOUS_DEBT

        fun calculate(bills: List<Bill>): SubscriberPaymentStatus {
            if (bills.isEmpty()) return NO_BILLS
            val totalRemaining = bills.sumOf { it.remainingAmount }
            val totalPaid = bills.sumOf { it.paidAmount }
            return when {
                totalRemaining <= 0.0 -> FULL_PAID
                totalPaid > 0.0 || bills.size > 1 -> PREVIOUS_DEBT
                else -> UNPAID
            }
        }
    }
}

/**
 * ترويسة قائمة المشتركين المنظمة
 */
@Composable
fun SubscriberTableHeader(
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp),
        shape = RoundedCornerShape(8.dp),
        color = if (isDark) Color(0xFF1E293B).copy(alpha = 0.6f) else Color(0xFFE2E8F0).copy(alpha = 0.7f),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ListAlt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "سجل المشتركين وبيانات الجباية",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color(0xFF0F172A),
                    maxLines = 1,
                    softWrap = false
                )
            }
            Text(
                text = "⚡ جوزة • فيز • أمبير • حالة الدفع",
                fontSize = 10.sp,
                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

/**
 * عنصر بطاقة المشترك (Subscriber Card Item)
 * مصمم بنظام أفقي متناسق يمنع تكسر النصوص عمودياً مع شارات حالة واضحة وأيقونات مناسبة.
 */
@Composable
fun SubscriberTableRow(
    index: Int,
    subscriber: Subscriber,
    subBills: List<Bill>,
    onClick: () -> Unit,
    onQuickPay: () -> Unit,
    onRevertPay: () -> Unit,
    onPrintOptions: () -> Unit,
    onAnnualHistory: () -> Unit = onClick,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val status = SubscriberPaymentStatus.calculate(subBills)
    val totalPaid = subBills.sumOf { it.paidAmount }
    val totalRemaining = subBills.sumOf { it.remainingAmount }
    val hasPayments = totalPaid > 0

    val bgColor = status.getBackgroundColor(isDark)
    val borderColor = status.getBorderColor(isDark)
    val indicatorColor = status.getIndicatorColor(isDark)
    val statusTextColor = status.getTextColor(isDark)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Row 1: Header (Index + Name + Phone) & (Status Badge horizontally)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Serial Number + Name & Phone
                Row(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = index.toString(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = subscriber.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A),
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (subscriber.phone.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = subscriber.phone,
                                    fontSize = 10.sp,
                                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF475569),
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Payment Status Badge - Always horizontal, auto-sized, no vertical stacking
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = indicatorColor.copy(alpha = if (isDark) 0.25f else 0.15f),
                    border = BorderStroke(1.dp, indicatorColor),
                    modifier = Modifier.wrapContentWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = status.icon,
                            contentDescription = null,
                            tint = indicatorColor,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = status.shortLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusTextColor,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: Secondary Technical Chips (Circuit breaker + Phase + Amperes)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circuit Breaker Chip
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isDark) Color(0xFF1E293B) else Color(0xFFFFFFFF),
                    border = BorderStroke(0.8.dp, if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)),
                    modifier = Modifier.wrapContentWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = null,
                            tint = if (isDark) Color(0xFFFCD34D) else Color(0xFFB45309),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = if (subscriber.circuitBreakerNumber.isNotBlank()) "جوزة: ${subscriber.circuitBreakerNumber}" else "جوزة: -",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color(0xFFFCD34D) else Color(0xFFB45309),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                // Phase Chip
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isDark) Color(0xFF1E293B) else Color(0xFFFFFFFF),
                    border = BorderStroke(0.8.dp, if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)),
                    modifier = Modifier.wrapContentWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Power,
                            contentDescription = null,
                            tint = if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = subscriber.groupName.replace(" (السكني العام)", "").replace(" (الخط التجاري)", "").replace(" (الخط الذهبي 24H)", ""),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isDark) Color(0xFFE2E8F0) else Color(0xFF1E293B),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                // Amperes Chip
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isDark) Color(0xFF1E293B) else Color(0xFFFFFFFF),
                    border = BorderStroke(0.8.dp, if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)),
                    modifier = Modifier.wrapContentWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricMeter,
                            contentDescription = null,
                            tint = if (isDark) Color(0xFF4ADE80) else Color(0xFF16A34A),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "${String.format(Locale.US, "%.0f", subscriber.amperes)} أمبير",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 3: Financial Summary & Quick Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (isDark) Color(0xFF0F172A).copy(alpha = 0.5f) else Color(0xFFF1F5F9).copy(alpha = 0.6f),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Amounts Info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (totalRemaining > 0) {
                        Text(
                            text = "متبقي: ${PrintHelper.formatCurrency(totalRemaining)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color(0xFFF87171) else Color(0xFFDC2626),
                            maxLines = 1,
                            softWrap = false
                        )
                    } else {
                        Text(
                            text = "تم التسديد: ${PrintHelper.formatCurrency(totalPaid)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color(0xFF4ADE80) else Color(0xFF16A34A),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                // Action Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (status != SubscriberPaymentStatus.FULL_PAID) {
                        FilledTonalButton(
                            onClick = onQuickPay,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (isDark) Color(0xFF15803D) else Color(0xFF16A34A),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("تسديد", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    } else if (hasPayments) {
                        OutlinedButton(
                            onClick = onRevertPay,
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (isDark) Color(0xFFF87171) else Color(0xFFDC2626)
                            ),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("إلغاء الدفع", fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }

                    IconButton(
                        onClick = onPrintOptions,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "طباعة ومشاركة الوصل",
                            tint = if (isDark) Color(0xFF93C5FD) else Color(0xFF2563EB),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onAnnualHistory,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "السجل السنوي وخريطة الأشهر",
                            tint = if (isDark) Color(0xFFFBBF24) else Color(0xFFD97706),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

// Backward compatibility alias for SubscriberStatusCard
@Composable
fun SubscriberStatusCard(
    subscriber: Subscriber,
    subBills: List<Bill>,
    onClick: () -> Unit,
    onQuickPay: () -> Unit,
    onRevertPay: () -> Unit,
    onPrintOptions: () -> Unit,
    onAnnualHistory: () -> Unit = onClick,
    modifier: Modifier = Modifier
) {
    SubscriberTableRow(
        index = 1,
        subscriber = subscriber,
        subBills = subBills,
        onClick = onClick,
        onQuickPay = onQuickPay,
        onRevertPay = onRevertPay,
        onPrintOptions = onPrintOptions,
        onAnnualHistory = onAnnualHistory,
        modifier = modifier
    )
}
