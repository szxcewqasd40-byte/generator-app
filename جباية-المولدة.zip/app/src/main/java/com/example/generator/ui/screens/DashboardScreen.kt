package com.example.generator.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.generator.data.entity.Payment
import com.example.generator.ui.components.ElectricBadge
import com.example.generator.ui.components.GlassCard
import com.example.generator.ui.components.Glossy3DIcon
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.PrintHelper
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: GeneratorViewModel,
    onNavigateToSubscribers: () -> Unit,
    onNavigateToBills: () -> Unit,
    onNavigateToExpenses: () -> Unit,
    onNavigateToBackup: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val subCount by viewModel.subscribersCount.collectAsState()
    val totalDue by viewModel.totalDueAmount.collectAsState()
    val totalCollected by viewModel.totalCollectedAmount.collectAsState()
    val totalDebts by viewModel.totalDebtsAmount.collectAsState()
    val totalExpenses by viewModel.totalExpensesAmount.collectAsState()
    val netProfit by viewModel.netProfit.collectAsState()

    val payments by viewModel.payments.collectAsState()
    val subscribers by viewModel.subscribers.collectAsState()
    val subscriberGroups by viewModel.subscriberGroups.collectAsState()

    val calendar = Calendar.getInstance()
    val currentMonth = calendar.get(Calendar.MONTH) + 1
    val currentYear = calendar.get(Calendar.YEAR)

    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val isTrialActive by viewModel.isTrialActive.collectAsState()
    val remainingTrialDays by viewModel.remainingTrialDays.collectAsState()
    var showPaywallDialog by remember { mutableStateOf(false) }
    var showQuickBillDialog by remember { mutableStateOf(false) }

    val (todayCollected, yesterdayCollected, tomorrowCollected) = remember(payments) {
        val now = Calendar.getInstance()
        val todayYear = now.get(Calendar.YEAR)
        val todayDay = now.get(Calendar.DAY_OF_YEAR)

        val calYesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val yestYear = calYesterday.get(Calendar.YEAR)
        val yestDay = calYesterday.get(Calendar.DAY_OF_YEAR)

        val calTomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        val tomYear = calTomorrow.get(Calendar.YEAR)
        val tomDay = calTomorrow.get(Calendar.DAY_OF_YEAR)

        var todaySum = 0.0
        var yestSum = 0.0
        var tomSum = 0.0

        for (p in payments) {
            val pCal = Calendar.getInstance().apply { timeInMillis = p.paymentDate }
            val pYear = pCal.get(Calendar.YEAR)
            val pDay = pCal.get(Calendar.DAY_OF_YEAR)

            if (pYear == todayYear && pDay == todayDay) {
                todaySum += p.amountPaid
            } else if (pYear == yestYear && pDay == yestDay) {
                yestSum += p.amountPaid
            } else if (pYear == tomYear && pDay == tomDay) {
                tomSum += p.amountPaid
            }
        }
        Triple(todaySum, yestSum, tomSum)
    }

    MidnightCyberBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 88.dp)
        ) {
            // Glassmorphism Hero Header with 3D Generator Orb
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    borderColor = ElectricCyan.copy(alpha = 0.45f),
                    borderWidth = 1.2.dp,
                    backgroundColor = Color(0xCC0C1738)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Glossy3DIcon(
                                imageRes = R.drawable.icon_3d_energy_1787310378195,
                                contentDescription = "Generator Power",
                                size = 52.dp,
                                glowColor = ElectricCyan
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = settings?.generatorName ?: "مولدة البركة الأهلية",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhitePrimary
                                )
                                Text(
                                    text = "نظام الجباية وإدارة القدرة الكهربائية • شهر $currentMonth / $currentYear",
                                    fontSize = 11.sp,
                                    color = TextCyanSecondary
                                )
                            }
                        }

                        ElectricBadge(
                            text = "⚡ متصل سحابياً",
                            color = ElectricCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0x33050B1A), RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, Color(0x2238BDF8)), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (currentUser?.role == "ADMIN") Icons.Default.AdminPanelSettings else Icons.Default.Person,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "المستخدم: ${currentUser?.name ?: "المدير"}",
                                fontSize = 12.sp,
                                color = TextWhitePrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Text(
                            text = if (currentUser?.role == "ADMIN") "صلاحية كاملة (مدير)" else "جابي أموال",
                            fontSize = 11.sp,
                            color = MetallicGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // 7-Day Free Trial / Subscription Glass Banner
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp),
                    borderColor = if (isSubscribed) MetallicEmerald.copy(alpha = 0.6f) else if (isTrialActive) ElectricCyan.copy(alpha = 0.5f) else MetallicCrimson.copy(alpha = 0.6f),
                    backgroundColor = if (isSubscribed) Color(0x99062E1E) else if (isTrialActive) Color(0x990A2247) else Color(0x993B0E14),
                    onClick = { showPaywallDialog = true }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (isSubscribed) MetallicEmerald else if (isTrialActive) ElectricCyan else MetallicCrimson,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isSubscribed) Icons.Default.WorkspacePremium else if (isTrialActive) Icons.Default.CardGiftcard else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = MidnightNavyDeep,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = if (isSubscribed) {
                                        "ترخيص Google Play مفعل بالكامل ⭐"
                                    } else if (isTrialActive) {
                                        "الفترة التجريبية: متبقي $remainingTrialDays أيام 🎁"
                                    } else {
                                        "انتهت الفترة التجريبية (7 أيام) - يلزم التجديد"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSubscribed) Color(0xFF4ADE80) else if (isTrialActive) ElectricCyan else Color(0xFFF87171)
                                )
                                Text(
                                    text = if (isSubscribed) "جميع الميزات غير محدودة مع التجديد التلقائي" else if (isTrialActive) "استمتع بجميع الميزات والطباعة مجاناً" else "انقر هنا لتفعيل الاشتراك والترخيص الفوري",
                                    fontSize = 11.sp,
                                    color = TextCyanSecondary
                                )
                            }
                        }

                        Button(
                            onClick = { showPaywallDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSubscribed) MetallicEmerald else ElectricCyan,
                                contentColor = MidnightNavyDeep
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = if (isSubscribed) "تفاصيل" else "ترقية الآن",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Quick Actions with 3D Glossy Touch
            item {
                Column(modifier = Modifier.padding(top = 16.dp, start = 16.dp, end = 16.dp)) {
                    Text(
                        text = "الإجراءات والعمليات السريعة",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            GlassActionChip(
                                title = "إدارة المشتركين والجباية",
                                imageRes = R.drawable.icon_3d_users_1787310351541,
                                accentColor = ElectricCyan,
                                onClick = onNavigateToSubscribers
                            )
                        }
                        item {
                            GlassActionChip(
                                title = "إصدار فواتير الشهر",
                                imageRes = R.drawable.icon_3d_money_1787310364133,
                                accentColor = MetallicGold,
                                onClick = { showQuickBillDialog = true }
                            )
                        }
                        item {
                            GlassActionChip(
                                title = "المصروفات والوقود",
                                imageRes = R.drawable.icon_3d_analytics_1787310400722,
                                accentColor = MetallicCrimson,
                                onClick = onNavigateToExpenses
                            )
                        }
                        item {
                            GlassActionChip(
                                title = "تصدير تقرير Excel",
                                imageRes = R.drawable.icon_3d_energy_1787310378195,
                                accentColor = MetallicEmerald,
                                onClick = { viewModel.exportToExcelCsv(context) }
                            )
                        }
                    }
                }
            }

            // Stats Summary Grid Cards (Glassmorphism + 3D Orbs)
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "المؤشرات المالية والحسابية المباشرة",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        GlassStatCard(
                            title = "عدد المشتركين",
                            value = "$subCount مشترك",
                            imageRes = R.drawable.icon_3d_users_1787310351541,
                            accentColor = ElectricCyan,
                            modifier = Modifier.weight(1f)
                        )
                        GlassStatCard(
                            title = "المبالغ المستحقة",
                            value = PrintHelper.formatCurrency(totalDue),
                            imageRes = R.drawable.icon_3d_money_1787310364133,
                            accentColor = MetallicGold,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        GlassStatCard(
                            title = "إجمالي المقبوضات",
                            value = PrintHelper.formatCurrency(totalCollected),
                            imageRes = R.drawable.icon_3d_money_1787310364133,
                            accentColor = MetallicEmerald,
                            modifier = Modifier.weight(1f)
                        )
                        GlassStatCard(
                            title = "الديون والمتأخرات",
                            value = PrintHelper.formatCurrency(totalDebts),
                            imageRes = R.drawable.icon_3d_energy_1787310378195,
                            accentColor = MetallicCrimson,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (currentUser?.role == "ADMIN" || currentUser?.canViewFinancials == true) {
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            GlassStatCard(
                                title = "إجمالي المصروفات",
                                value = PrintHelper.formatCurrency(totalExpenses),
                                imageRes = R.drawable.icon_3d_analytics_1787310400722,
                                accentColor = Color(0xFFF97316),
                                modifier = Modifier.weight(1f)
                            )
                            GlassStatCard(
                                title = "صافي الأرباح",
                                value = PrintHelper.formatCurrency(netProfit),
                                imageRes = R.drawable.icon_3d_money_1787310364133,
                                accentColor = if (netProfit >= 0) MetallicEmerald else MetallicCrimson,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Daily Collection Stats (اليوم، الأمس، الغد)
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(
                        text = "حركة الجباية والتحصيل اليومي",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GlassDailyStatCard(
                            title = "جباية الأمس",
                            subtitle = "المقبوض أمس",
                            amount = yesterdayCollected,
                            accentColor = TextCyanSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        GlassDailyStatCard(
                            title = "جباية اليوم",
                            subtitle = "المقبوض اليوم",
                            amount = todayCollected,
                            accentColor = MetallicEmerald,
                            modifier = Modifier.weight(1.1f)
                        )
                        GlassDailyStatCard(
                            title = "المستحق القادم",
                            subtitle = "مواعيد الغد",
                            amount = tomorrowCollected,
                            accentColor = MetallicGold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Electrical Lines Load Monitor (الفيزات)
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "مراقبة أحمال الفيزات وتوزيع الأمبيرية",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhitePrimary
                        )
                        TextButton(onClick = onNavigateToSubscribers) {
                            Text("إدارة الخطوط", fontSize = 12.sp, color = ElectricCyan)
                        }
                    }

                    val totalDrawnAmperes = subscribers.filter { it.isActive }.sumOf { it.amperes }

                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        borderColor = ElectricCyan.copy(alpha = 0.3f),
                        backgroundColor = Color(0xAA0B1533)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "إجمالي حمل المولدة الفعلي:",
                                fontSize = 12.sp,
                                color = TextCyanSecondary
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.1f", totalDrawnAmperes)} أمبير",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElectricCyan
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        if (subscriberGroups.isEmpty()) {
                            Text(
                                text = "لا توجد مجموعات فيزات معرفة حالياً.",
                                fontSize = 12.sp,
                                color = TextCyanSecondary
                            )
                        } else {
                            subscriberGroups.forEach { group ->
                                val groupSubs = subscribers.filter { it.groupName == group.groupName }
                                val groupAmps = groupSubs.filter { it.isActive }.sumOf { it.amperes }
                                val fraction = if (totalDrawnAmperes > 0) (groupAmps / totalDrawnAmperes).toFloat() else 0f

                                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = group.groupName,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextWhitePrimary
                                        )
                                        Text(
                                            text = "${String.format(Locale.US, "%.1f", groupAmps)} A (${groupSubs.size} مشترك)",
                                            fontSize = 11.sp,
                                            color = TextCyanSecondary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { fraction.coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = ElectricCyan,
                                        trackColor = Color(0x3300F0FF)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Recent Collection Log Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "آخر المقبوضات وسندات القبض",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "${payments.size} دفعة مسجلة",
                        fontSize = 12.sp,
                        color = TextCyanSecondary
                    )
                }
            }

            if (payments.isEmpty()) {
                item {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        borderColor = Color(0x2238BDF8)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "لا توجد دفعات مقبوضة حتى الآن",
                                color = TextCyanSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            } else {
                items(payments.take(5)) { payment ->
                    GlassPaymentRow(payment = payment, settings = settings)
                }
            }
        }
    }

    if (showQuickBillDialog) {
        AlertDialog(
            onDismissRequest = { showQuickBillDialog = false },
            title = { Text("إصدار فواتير الشهر تلقائياً", color = TextWhitePrimary) },
            text = {
                Text(
                    "هل ترغب بإصدار فواتير شهر $currentMonth / $currentYear لجميع المشتركين الفعالين؟ لن يتم تكرار الفواتير الصادرة سابقاً.",
                    color = TextCyanSecondary
                )
            },
            containerColor = Color(0xFF0F1B3E),
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.generateMonthlyBills(currentMonth, currentYear)
                        showQuickBillDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = MidnightNavyDeep)
                ) {
                    Text("إصدار الآن", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showQuickBillDialog = false },
                    border = BorderStroke(1.dp, Color(0x3338BDF8))
                ) {
                    Text("إلغاء", color = TextWhitePrimary)
                }
            }
        )
    }

    if (showPaywallDialog) {
        SubscriptionPaywallDialog(
            viewModel = viewModel,
            onDismiss = { showPaywallDialog = false }
        )
    }
}

@Composable
private fun GlassStatCard(
    title: String,
    value: String,
    imageRes: Int,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        borderColor = accentColor.copy(alpha = 0.35f),
        backgroundColor = Color(0xB30C1635)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = TextCyanSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = value,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhitePrimary
                )
            }
            Glossy3DIcon(
                imageRes = imageRes,
                contentDescription = title,
                size = 40.dp,
                glowColor = accentColor
            )
        }
    }
}

@Composable
private fun GlassActionChip(
    title: String,
    imageRes: Int,
    accentColor: Color,
    onClick: () -> Unit
) {
    GlassCard(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        borderColor = accentColor.copy(alpha = 0.4f),
        backgroundColor = Color(0xB30F1C40),
        elevation = 4.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Glossy3DIcon(
                imageRes = imageRes,
                contentDescription = title,
                size = 28.dp,
                glowColor = accentColor
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhitePrimary
            )
        }
    }
}

@Composable
private fun GlassDailyStatCard(
    title: String,
    subtitle: String,
    amount: Double,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        borderColor = accentColor.copy(alpha = 0.3f),
        backgroundColor = Color(0xB30A1430),
        elevation = 3.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhitePrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = PrintHelper.formatCurrency(amount),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
            Text(
                text = subtitle,
                fontSize = 9.sp,
                color = TextCyanSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun GlassPaymentRow(
    payment: Payment,
    settings: com.example.generator.data.entity.GeneratorSettings?
) {
    val context = LocalContext.current
    val dateFormat = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar"))
    val dateStr = dateFormat.format(Date(payment.paymentDate))

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        borderColor = ElectricCyan.copy(alpha = 0.25f),
        backgroundColor = Color(0xB30C1635),
        elevation = 3.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Glossy3DIcon(
                    imageRes = R.drawable.icon_3d_money_1787310364133,
                    contentDescription = "Payment Receipt",
                    size = 38.dp,
                    glowColor = MetallicEmerald
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = payment.subscriberName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "إيصال: ${payment.receiptCode} • $dateStr",
                        fontSize = 11.sp,
                        color = TextCyanSecondary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = PrintHelper.formatCurrency(payment.amountPaid),
                    fontWeight = FontWeight.Bold,
                    color = MetallicEmerald,
                    fontSize = 14.sp
                )
                IconButton(
                    onClick = { PrintHelper.sharePaymentWhatsApp(context, payment, null, settings) }
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "مشاركة",
                        modifier = Modifier.size(18.dp),
                        tint = ElectricCyan
                    )
                }
            }
        }
    }
}
