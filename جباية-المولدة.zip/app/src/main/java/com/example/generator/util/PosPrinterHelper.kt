package com.example.generator.util

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.GeneratorSettings
import com.example.generator.data.entity.Payment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

enum class PosPaperSize(val widthPx: Int, val labelAr: String) {
    SIZE_58MM(384, "رول صغير 58 مم (POS)"),
    SIZE_80MM(576, "رول عريض 80 مم (POS)")
}

data class BluetoothPosDevice(
    val name: String,
    val address: String,
    val isBonded: Boolean = true
)

object PosPrinterHelper {

    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private const val PREFS_NAME = "pos_printer_prefs"
    private const val KEY_LAST_DEVICE_ADDR = "last_pos_device_address"
    private const val KEY_LAST_DEVICE_NAME = "last_pos_device_name"
    private const val KEY_PAPER_SIZE = "last_pos_paper_size"

    fun getLastSavedDevice(context: Context): BluetoothPosDevice? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val addr = prefs.getString(KEY_LAST_DEVICE_ADDR, null) ?: return null
        val name = prefs.getString(KEY_LAST_DEVICE_NAME, "طابعة POS بلوتوث") ?: "طابعة POS"
        return BluetoothPosDevice(name, addr)
    }

    fun saveLastDevice(context: Context, device: BluetoothPosDevice) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_LAST_DEVICE_ADDR, device.address)
            .putString(KEY_LAST_DEVICE_NAME, device.name)
            .apply()
    }

    fun getSavedPaperSize(context: Context): PosPaperSize {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val name = prefs.getString(KEY_PAPER_SIZE, PosPaperSize.SIZE_58MM.name)
        return try {
            PosPaperSize.valueOf(name ?: PosPaperSize.SIZE_58MM.name)
        } catch (e: Exception) {
            PosPaperSize.SIZE_58MM
        }
    }

    fun savePaperSize(context: Context, size: PosPaperSize) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PAPER_SIZE, size.name).apply()
    }

    /**
     * Checks if Bluetooth permissions are granted.
     */
    fun hasBluetoothPermissions(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Retrieves list of paired/bonded Bluetooth POS printers.
     */
    fun getPairedBluetoothDevices(context: Context): List<BluetoothPosDevice> {
        if (!hasBluetoothPermissions(context)) {
            return emptyList()
        }
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return try {
            bluetoothAdapter.bondedDevices?.map { device ->
                BluetoothPosDevice(
                    name = device.name ?: "جهاز بدون اسم",
                    address = device.address,
                    isBonded = true
                )
            } ?: emptyList()
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    // =========================================================================
    // 🖨️ POS BITMAP RECEIPT GENERATION (High Contrast Monochrome for Thermal Rolls)
    // =========================================================================

    /**
     * Creates a high quality receipt bitmap for a single bill.
     */
    fun generateBillReceiptBitmap(
        bill: Bill,
        settings: GeneratorSettings?,
        paperSize: PosPaperSize = PosPaperSize.SIZE_58MM
    ): Bitmap {
        val width = paperSize.widthPx
        val scale = if (paperSize == PosPaperSize.SIZE_80MM) 1.25f else 1.0f

        val estimatedHeight = (680 * scale).toInt()
        val bitmap = Bitmap.createBitmap(width, estimatedHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        val genName = settings?.generatorName?.takeIf { it.isNotBlank() } ?: "مولدة الكهرباء الأهلية"
        val ownerName = settings?.ownerName?.takeIf { it.isNotBlank() } ?: "غير محدد"
        val phone = settings?.phone?.takeIf { it.isNotBlank() } ?: "غير متوفر"
        val dateFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
        val dateStr = dateFormat.format(Date())

        var y = 28f * scale

        // Header Title
        paint.textSize = 20f * scale
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("⚡ $genName ⚡", width / 2f, y, paint)

        y += 24f * scale
        paint.textSize = 12f * scale
        paint.isFakeBoldText = false
        canvas.drawText("الإدارة: $ownerName | هاتف: $phone", width / 2f, y, paint)

        y += 18f * scale
        paint.textSize = 11f * scale
        canvas.drawText("تاريخ وساعة التسديد: $dateStr", width / 2f, y, paint)

        // Dotted divider
        y += 12f * scale
        drawDottedLine(canvas, y, width.toFloat(), paint)

        // Title Tag
        y += 20f * scale
        paint.textSize = 15f * scale
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("=== إيصال فاتورة اشتراك ===", width / 2f, y, paint)

        y += 22f * scale
        paint.textSize = 13f * scale
        paint.textAlign = Paint.Align.RIGHT
        val marginX = width - 18f * scale
        val leftX = 18f * scale

        // Details rows (Right to Left)
        drawReceiptRow(canvas, "رقم الفاتورة:", bill.billCode, y, marginX, leftX, paint, isBold = true)
        y += 20f * scale
        drawReceiptRow(canvas, "اسم المشترك:", bill.subscriberName, y, marginX, leftX, paint, isBold = true)
        y += 20f * scale
        drawReceiptRow(canvas, "رقم المشترك:", bill.subscriberCode, y, marginX, leftX, paint)
        y += 20f * scale
        drawReceiptRow(canvas, "الفترة المفوترة:", "شهر ${bill.month} / ${bill.year}", y, marginX, leftX, paint)
        y += 20f * scale
        drawReceiptRow(canvas, "عدد الأمبيرات:", "${bill.amperes} أمبير", y, marginX, leftX, paint)
        y += 20f * scale
        drawReceiptRow(canvas, "سعر الأمبير:", PrintHelper.formatCurrency(bill.pricePerAmpere), y, marginX, leftX, paint)

        if (bill.fixedFee > 0) {
            y += 20f * scale
            drawReceiptRow(canvas, "رسوم الفيزة الثابتة:", PrintHelper.formatCurrency(bill.fixedFee), y, marginX, leftX, paint)
        }

        // Solid divider
        y += 12f * scale
        drawSolidLine(canvas, y, width.toFloat(), paint)

        // Totals Box
        y += 22f * scale
        paint.textSize = 15f * scale
        paint.isFakeBoldText = true
        drawReceiptRow(canvas, "المبلغ الإجمالي:", PrintHelper.formatCurrency(bill.totalAmount), y, marginX, leftX, paint, isBold = true)

        y += 22f * scale
        drawReceiptRow(canvas, "المبلغ المسدد:", PrintHelper.formatCurrency(bill.paidAmount), y, marginX, leftX, paint)

        y += 24f * scale
        paint.textSize = 16f * scale
        drawReceiptRow(canvas, "المتبقي (الدين):", PrintHelper.formatCurrency(bill.remainingAmount), y, marginX, leftX, paint, isBold = true)

        // Address under total account if configured
        val address = settings?.address?.takeIf { it.isNotBlank() }
        if (address != null) {
            y += 18f * scale
            paint.textSize = 11f * scale
            paint.isFakeBoldText = false
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(address, width / 2f, y, paint)
        }

        val mastercard = settings?.mastercardNumber?.takeIf { it.isNotBlank() }
        if (mastercard != null) {
            y += 14f * scale
            drawDottedLine(canvas, y, width.toFloat(), paint)
            y += 18f * scale
            paint.textSize = 11f * scale
            paint.isFakeBoldText = true
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("الدفع الإلكتروني (ماستر كارد):", width / 2f, y, paint)
            y += 16f * scale
            paint.textSize = 13f * scale
            canvas.drawText(mastercard, width / 2f, y, paint)
        }

        // Barcode
        y += 14f * scale
        drawDottedLine(canvas, y, width.toFloat(), paint)
        y += 14f * scale

        try {
            val barcodeW = (width * 0.78f).toInt()
            val barcodeH = (50 * scale).toInt()
            val barcodeBitmap = BarcodeGenerator.createBarcodeBitmap(bill.billCode, barcodeW, barcodeH)
            val bx = (width - barcodeW) / 2f
            canvas.drawBitmap(barcodeBitmap, bx, y, null)
            y += barcodeH + (16f * scale)
        } catch (e: Exception) {
            y += 10f * scale
        }

        // Footer
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 11f * scale
        paint.isFakeBoldText = false
        canvas.drawText("شكراً لالتزامكم بالتسديد - يرجى الاحتفاظ بالوصل", width / 2f, y, paint)
        y += 16f * scale
        paint.textSize = 9f * scale
        canvas.drawText("*** نظام إدارة المولدات الذكي POS ***", width / 2f, y, paint)
        y += 24f * scale

        // Crop bitmap to actual drawn height
        val actualHeight = y.toInt()
        return if (actualHeight > 0 && actualHeight <= estimatedHeight) {
            Bitmap.createBitmap(bitmap, 0, 0, width, actualHeight)
        } else {
            bitmap
        }
    }

    /**
     * Creates receipt bitmap for a single payment.
     */
    fun generatePaymentReceiptBitmap(
        payment: Payment,
        bill: Bill?,
        settings: GeneratorSettings?,
        paperSize: PosPaperSize = PosPaperSize.SIZE_58MM
    ): Bitmap {
        val width = paperSize.widthPx
        val scale = if (paperSize == PosPaperSize.SIZE_80MM) 1.25f else 1.0f

        val estimatedHeight = (640 * scale).toInt()
        val bitmap = Bitmap.createBitmap(width, estimatedHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        val genName = settings?.generatorName?.takeIf { it.isNotBlank() } ?: "مولدة الكهرباء الأهلية"
        val ownerName = settings?.ownerName?.takeIf { it.isNotBlank() } ?: "غير محدد"
        val phone = settings?.phone?.takeIf { it.isNotBlank() } ?: "غير متوفر"
        val dateFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
        val dateStr = dateFormat.format(Date())

        var y = 28f * scale

        // Header Title
        paint.textSize = 20f * scale
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("⚡ $genName ⚡", width / 2f, y, paint)

        y += 24f * scale
        paint.textSize = 12f * scale
        paint.isFakeBoldText = false
        canvas.drawText("الإدارة: $ownerName | هاتف: $phone", width / 2f, y, paint)

        y += 18f * scale
        paint.textSize = 11f * scale
        canvas.drawText("تاريخ وساعة التسديد: $dateStr", width / 2f, y, paint)

        y += 12f * scale
        drawDottedLine(canvas, y, width.toFloat(), paint)

        y += 20f * scale
        paint.textSize = 15f * scale
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("=== إيصال استلام دفعة مالية ===", width / 2f, y, paint)

        y += 24f * scale
        val marginX = width - 18f * scale
        val leftX = 18f * scale
        paint.textSize = 13f * scale

        drawReceiptRow(canvas, "رقم الإيصال:", payment.receiptCode, y, marginX, leftX, paint, isBold = true)
        y += 20f * scale
        drawReceiptRow(canvas, "اسم المشترك:", payment.subscriberName, y, marginX, leftX, paint, isBold = true)
        y += 20f * scale
        drawReceiptRow(canvas, "الجابي / المستلم:", payment.collectedBy, y, marginX, leftX, paint)

        if (payment.notes.isNotBlank()) {
            y += 20f * scale
            drawReceiptRow(canvas, "ملاحظات:", payment.notes, y, marginX, leftX, paint)
        }

        // Highlighted Amount Box
        y += 18f * scale
        val boxRect = Rect(
            (14 * scale).toInt(),
            y.toInt(),
            (width - 14 * scale).toInt(),
            (y + 44 * scale).toInt()
        )
        val strokePaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2.5f * scale
        }
        canvas.drawRect(boxRect, strokePaint)

        y += 28f * scale
        paint.textSize = 16f * scale
        paint.isFakeBoldText = true
        drawReceiptRow(canvas, "المبلغ المقبوض:", PrintHelper.formatCurrency(payment.amountPaid), y, marginX, leftX, paint, isBold = true)

        y += 28f * scale
        if (bill != null) {
            paint.textSize = 13f * scale
            drawReceiptRow(canvas, "المتبقي من الفاتورة:", PrintHelper.formatCurrency(bill.remainingAmount), y, marginX, leftX, paint, isBold = true)
            y += 20f * scale
        }

        // Barcode
        y += 8f * scale
        drawDottedLine(canvas, y, width.toFloat(), paint)
        y += 14f * scale

        try {
            val barcodeW = (width * 0.78f).toInt()
            val barcodeH = (48 * scale).toInt()
            val barcodeBitmap = BarcodeGenerator.createBarcodeBitmap(payment.receiptCode, barcodeW, barcodeH)
            val bx = (width - barcodeW) / 2f
            canvas.drawBitmap(barcodeBitmap, bx, y, null)
            y += barcodeH + (16f * scale)
        } catch (e: Exception) {
            y += 10f * scale
        }

        // Footer
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 11f * scale
        paint.isFakeBoldText = false
        canvas.drawText("شكراً لتسديدكم المبلغ - دمتم بخير", width / 2f, y, paint)
        y += 16f * scale
        paint.textSize = 9f * scale
        canvas.drawText("*** نظام إدارة المولدات الذكي POS ***", width / 2f, y, paint)
        y += 24f * scale

        val actualHeight = y.toInt()
        return if (actualHeight > 0 && actualHeight <= estimatedHeight) {
            Bitmap.createBitmap(bitmap, 0, 0, width, actualHeight)
        } else {
            bitmap
        }
    }

    /**
     * Creates summary receipt bitmap for daily collections (end-of-day POS report).
     */
    fun generateDailySummaryReceiptBitmap(
        payments: List<Payment>,
        dateLabel: String,
        settings: GeneratorSettings?,
        paperSize: PosPaperSize = PosPaperSize.SIZE_58MM
    ): Bitmap {
        val width = paperSize.widthPx
        val scale = if (paperSize == PosPaperSize.SIZE_80MM) 1.25f else 1.0f

        val rowHeight = (20f * scale)
        val estimatedHeight = (450 * scale + (payments.size * rowHeight)).toInt()
        val bitmap = Bitmap.createBitmap(width, estimatedHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        val genName = settings?.generatorName?.takeIf { it.isNotBlank() } ?: "مولدة الكهرباء الأهلية"
        val totalCollected = payments.sumOf { it.amountPaid }

        var y = 28f * scale

        paint.textSize = 18f * scale
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("⚡ $genName ⚡", width / 2f, y, paint)

        y += 22f * scale
        paint.textSize = 14f * scale
        canvas.drawText("📊 تقرير الجباية والتحصيل اليومي", width / 2f, y, paint)

        y += 18f * scale
        paint.textSize = 11f * scale
        paint.isFakeBoldText = false
        canvas.drawText("التاريخ: $dateLabel", width / 2f, y, paint)

        y += 12f * scale
        drawSolidLine(canvas, y, width.toFloat(), paint)

        y += 20f * scale
        val marginX = width - 16f * scale
        val leftX = 16f * scale

        paint.textSize = 14f * scale
        drawReceiptRow(canvas, "إجمالي المقبوضات:", PrintHelper.formatCurrency(totalCollected), y, marginX, leftX, paint, isBold = true)
        y += 20f * scale
        drawReceiptRow(canvas, "عدد الإيصالات المسددة:", "${payments.size} إيصال", y, marginX, leftX, paint, isBold = true)

        // Breakdown by Collectors
        val collectorGroups = payments.groupBy { it.collectedBy }
        y += 12f * scale
        drawDottedLine(canvas, y, width.toFloat(), paint)
        y += 18f * scale
        paint.textSize = 12f * scale
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("تفصيل الجباة:", marginX, y, paint)

        for ((col, list) in collectorGroups) {
            y += 18f * scale
            val colSum = list.sumOf { it.amountPaid }
            drawReceiptRow(canvas, "- $col (${list.size}):", PrintHelper.formatCurrency(colSum), y, marginX - 10f, leftX, paint)
        }

        y += 12f * scale
        drawSolidLine(canvas, y, width.toFloat(), paint)
        y += 16f * scale
        paint.textSize = 10f * scale
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("قائمة المقبوضات التفصيلية:", width / 2f, y, paint)

        // Payments mini table
        for (p in payments) {
            y += 18f * scale
            val sName = if (p.subscriberName.length > 15) p.subscriberName.take(15) + ".." else p.subscriberName
            drawReceiptRow(canvas, sName, PrintHelper.formatCurrency(p.amountPaid), y, marginX, leftX, paint)
        }

        y += 16f * scale
        drawDottedLine(canvas, y, width.toFloat(), paint)
        y += 22f * scale
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 10f * scale
        canvas.drawText("*** تم استخراج التقرير عبر جهاز POS ***", width / 2f, y, paint)
        y += 24f * scale

        val actualHeight = y.toInt()
        return if (actualHeight > 0 && actualHeight <= estimatedHeight) {
            Bitmap.createBitmap(bitmap, 0, 0, width, actualHeight)
        } else {
            bitmap
        }
    }

    /**
     * Creates a test print receipt bitmap.
     */
    fun generateTestReceiptBitmap(
        settings: GeneratorSettings?,
        paperSize: PosPaperSize = PosPaperSize.SIZE_58MM
    ): Bitmap {
        val width = paperSize.widthPx
        val scale = if (paperSize == PosPaperSize.SIZE_80MM) 1.25f else 1.0f
        val height = (320 * scale).toInt()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        var y = 30f * scale
        paint.textSize = 18f * scale
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("⚡ ${settings?.generatorName ?: "مولدة الكهرباء"} ⚡", width / 2f, y, paint)

        y += 24f * scale
        paint.textSize = 14f * scale
        canvas.drawText("✅ فحص طباعة POS ناجح", width / 2f, y, paint)

        y += 14f * scale
        drawSolidLine(canvas, y, width.toFloat(), paint)

        y += 22f * scale
        paint.textSize = 12f * scale
        paint.isFakeBoldText = false
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale("ar"))
        canvas.drawText("التاريخ: ${dateFormat.format(Date())}", width / 2f, y, paint)

        y += 20f * scale
        canvas.drawText("عرض الرول: ${paperSize.labelAr}", width / 2f, y, paint)
        y += 20f * scale
        canvas.drawText("الاتصال الحراري يعمل بنجاح 100%", width / 2f, y, paint)

        y += 14f * scale
        drawDottedLine(canvas, y, width.toFloat(), paint)

        y += 22f * scale
        paint.textSize = 10f * scale
        canvas.drawText("*** نظام إدارة المولدات الذكي POS ***", width / 2f, y, paint)

        return bitmap
    }

    private fun drawReceiptRow(
        canvas: Canvas,
        label: String,
        value: String,
        y: Float,
        rightX: Float,
        leftX: Float,
        paint: Paint,
        isBold: Boolean = false
    ) {
        paint.isFakeBoldText = isBold
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText(label, rightX, y, paint)

        paint.textAlign = Paint.Align.LEFT
        canvas.drawText(value, leftX, y, paint)
    }

    private fun drawDottedLine(canvas: Canvas, y: Float, width: Float, paint: Paint) {
        val dottedPaint = Paint(paint).apply {
            strokeWidth = 1.5f
            pathEffect = DashPathEffect(floatArrayOf(5f, 5f), 0f)
        }
        canvas.drawLine(14f, y, width - 14f, y, dottedPaint)
    }

    private fun drawSolidLine(canvas: Canvas, y: Float, width: Float, paint: Paint) {
        val solidPaint = Paint(paint).apply {
            strokeWidth = 2f
        }
        canvas.drawLine(14f, y, width - 14f, y, solidPaint)
    }

    // =========================================================================
    // 📡 ESC/POS BYTE GENERATOR (GS v 0 Raster Bit Image Format)
    // =========================================================================

    /**
     * Converts an Android Bitmap to raw ESC/POS commands suitable for thermal Bluetooth printers.
     */
    fun convertBitmapToEscPosBytes(bitmap: Bitmap): ByteArray {
        val outputStream = ByteArrayOutputStream()

        // 1. Initialize printer: ESC @
        outputStream.write(byteArrayOf(0x1B, 0x40))

        // 2. Align center: ESC a 1
        outputStream.write(byteArrayOf(0x1B, 0x61, 0x01))

        // 3. Convert Bitmap to ESC/POS Raster bit image: GS v 0 m xL xH yL yH d1...dk
        val width = bitmap.width
        val height = bitmap.height
        val widthBytes = (width + 7) / 8

        val xL = (widthBytes % 256).toByte()
        val xH = (widthBytes / 256).toByte()
        val yL = (height % 256).toByte()
        val yH = (height / 256).toByte()

        // GS v 0 0 xL xH yL yH
        outputStream.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH))

        // Pixel raster data
        for (y in 0 until height) {
            for (xByte in 0 until widthBytes) {
                var byteVal = 0
                for (bit in 0 until 8) {
                    val x = xByte * 8 + bit
                    if (x < width) {
                        val pixel = bitmap.getPixel(x, y)
                        val r = (pixel shr 16) and 0xFF
                        val g = (pixel shr 8) and 0xFF
                        val b = pixel and 0xFF
                        val luminance = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
                        if (luminance < 160) { // Black dot
                            byteVal = byteVal or (1 shl (7 - bit))
                        }
                    }
                }
                outputStream.write(byteVal)
            }
        }

        // 4. Feed 4 lines: ESC d 4
        outputStream.write(byteArrayOf(0x1B, 0x64, 0x04))

        // 5. Paper Cut command: GS V 66 0 (Partial / Full Cut)
        outputStream.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))

        return outputStream.toByteArray()
    }

    // =========================================================================
    // 📶 BLUETOOTH DIRECT PRINTING EXECUTION
    // =========================================================================

    /**
     * Connects to a Bluetooth POS Thermal Printer and prints the given bitmap.
     */
    suspend fun printBitmapViaBluetooth(
        deviceAddress: String,
        bitmap: Bitmap
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            ?: return@withContext Result.failure(Exception("البلوتوث غير متوفر في هذا الجهاز"))

        if (!bluetoothAdapter.isEnabled) {
            return@withContext Result.failure(Exception("يرجى تشغيل البلوتوث أولاً للاتصال بالطابعة"))
        }

        var socket: BluetoothSocket? = null
        var outputStream: OutputStream? = null

        try {
            val device: BluetoothDevice = bluetoothAdapter.getRemoteDevice(deviceAddress)
            bluetoothAdapter.cancelDiscovery()

            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()

            outputStream = socket.outputStream
            val escPosBytes = convertBitmapToEscPosBytes(bitmap)
            outputStream.write(escPosBytes)
            outputStream.flush()

            // Small delay to allow printer buffer to finish before closing
            kotlinx.coroutines.delay(500)
            Result.success(Unit)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(Exception("تعذر الاتصال بطابعة POS: ${e.localizedMessage ?: "تأكد من تشغيل الطابعة واقترانها"}"))
        } finally {
            try {
                outputStream?.close()
                socket?.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // =========================================================================
    // 🖨️ ANDROID SYSTEM THERMAL PRINT (Supports Built-in POS Terminals: Sunmi, PAX, etc.)
    // =========================================================================

    /**
     * Triggers Android Print Spooler formatted specifically for thermal roll paper.
     */
    fun printBitmapViaAndroidSystem(
        context: Context,
        bitmap: Bitmap,
        jobName: String = "طباعة_POS"
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: run {
            Toast.makeText(context, "خدمة الطباعة غير متوفرة في النظام", Toast.LENGTH_SHORT).show()
            return
        }

        printManager.print(jobName, object : PrintDocumentAdapter() {
            private var pdfDoc: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()

                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                pdfDoc = PdfDocument()
                val pageWidth = bitmap.width
                val pageHeight = bitmap.height

                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
                val page = pdfDoc?.startPage(pageInfo)

                if (page != null) {
                    val canvas = page.canvas
                    canvas.drawBitmap(bitmap, 0f, 0f, null)
                    pdfDoc?.finishPage(page)
                }

                try {
                    FileOutputStream(destination?.fileDescriptor).use { out ->
                        pdfDoc?.writeTo(out)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    pdfDoc?.close()
                }
            }
        }, PrintAttributes.Builder()
            .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
            .build())
    }

    /**
     * Opens or shares the receipt image to external thermal printer apps (e.g., RawBT, Bluetooth Print, Quick Printer).
     */
    fun shareReceiptImageToPosApp(context: Context, bitmap: Bitmap, title: String = "إرسال إلى تطبيق طابعة POS") {
        try {
            val file = File(context.cacheDir, "pos_receipt_temp.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "فشل فتح تطبيق الطابعة: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
