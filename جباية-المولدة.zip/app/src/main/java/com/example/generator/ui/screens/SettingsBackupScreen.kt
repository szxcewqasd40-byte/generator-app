package com.example.generator.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.generator.data.entity.UserAccount
import com.example.generator.ui.components.GlassCard
import com.example.generator.ui.components.Glossy3DIcon
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.components.PosPrintDialog
import com.example.generator.ui.components.PosPrintTarget
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.AppThemeMode
import com.example.generator.util.PrintHelper
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBackupScreen(viewModel: GeneratorViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val users by viewModel.users.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val activeProductId by viewModel.activeProductId.collectAsState()

    val currentThemeMode by viewModel.themeMode.collectAsState()

    val currentSettings = settings
    var generatorName by remember(currentSettings) { mutableStateOf(currentSettings?.generatorName ?: "") }
    var ownerName by remember(currentSettings) { mutableStateOf(currentSettings?.ownerName ?: "") }
    var phone by remember(currentSettings) { mutableStateOf(currentSettings?.phone ?: "") }
    var address by remember(currentSettings) { mutableStateOf(currentSettings?.address ?: "") }
    var priceText by remember(currentSettings) { mutableStateOf(if (currentSettings != null && currentSettings.defaultPricePerAmpere > 0) currentSettings.defaultPricePerAmpere.toString() else "") }
    var mastercardNumber by remember(currentSettings) { mutableStateOf(currentSettings?.mastercardNumber ?: "") }

    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var pendingRestoreContent by remember { mutableStateOf<String?>(null) }

    var showAddUserDialog by remember { mutableStateOf(false) }
    var userToEdit by remember { mutableStateOf<UserAccount?>(null) }
    var userToSwitch by remember { mutableStateOf<UserAccount?>(null) }
    var showPosDialog by remember { mutableStateOf(false) }
    var showPaywallDialog by remember { mutableStateOf(false) }
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var showHelpTutorialDialog by remember { mutableStateOf(false) }

    // File picker launcher for JSON / CSV Backup Restore
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val content = stream.bufferedReader(Charsets.UTF_8).readText()
                    pendingRestoreContent = content
                    showRestoreConfirmDialog = true
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "فشل قراءة الملف المختار", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Glossy3DIcon(
                            imageRes = R.drawable.icon_3d_energy_1787310378195,
                            contentDescription = null,
                            size = 36.dp,
                            glowColor = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("الإعدادات والنسخ الاحتياطي", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    }
                },
                actions = {
                    IconButton(onClick = { showHelpTutorialDialog = true }) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "دليل الاستخدام والشروحات", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        MidnightCyberBackground {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // 🎨 Theme Mode & Color Appearance Card (Day/Night & Color Options)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.DarkMode,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "المظهر والوضع الليلي",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "التبديل بين الوضع الليلي والنهاري أو التلقائي حسب النظام",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "وضع السمة:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Dark Mode
                            FilterChip(
                                selected = currentThemeMode == AppThemeMode.DARK,
                                onClick = { viewModel.setThemeMode(AppThemeMode.DARK) },
                                label = { Text("ليلي 🌙", fontSize = 12.sp, fontWeight = if (currentThemeMode == AppThemeMode.DARK) FontWeight.Bold else FontWeight.Normal) },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.DarkMode,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )

                            // Light Mode
                            FilterChip(
                                selected = currentThemeMode == AppThemeMode.LIGHT,
                                onClick = { viewModel.setThemeMode(AppThemeMode.LIGHT) },
                                label = { Text("نهاري ☀️", fontSize = 12.sp, fontWeight = if (currentThemeMode == AppThemeMode.LIGHT) FontWeight.Bold else FontWeight.Normal) },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.LightMode,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )

                            // System Auto
                            FilterChip(
                                selected = currentThemeMode == AppThemeMode.SYSTEM,
                                onClick = { viewModel.setThemeMode(AppThemeMode.SYSTEM) },
                                label = { Text("النظام ⚙️", fontSize = 12.sp, fontWeight = if (currentThemeMode == AppThemeMode.SYSTEM) FontWeight.Bold else FontWeight.Normal) },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.BrightnessAuto,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Help & Tutorial Card (User Guides & How-To)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.MenuBook,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "دليل الاستخدام والشروحات السريعة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "تعلم كيفية إضافة المشتركين وطباعة الوصل بخطوات مبسطة",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF16A34A).copy(alpha = 0.15f),
                                contentColor = Color(0xFF16A34A)
                            ) {
                                Text(
                                    text = "دليل تفاعلي 💡",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "شروحات عملية ومباشرة مع نصائح احترافية لإدارة منظومة المولدة، توليد الفواتير الشهرية، واستخدام طابعات الفواتير POS وبلوتوث وتصدير ملفات PDF.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showHelpTutorialDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.HelpOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("فتح دليل الاستخدام والشروحات 📖", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Google Play Billing & Subscription Status Card (Google Play Policy Compliant)
            item {
                val isTrialActive by viewModel.isTrialActive.collectAsState()
                val remainingTrialDays by viewModel.remainingTrialDays.collectAsState()

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSubscribed) Color(0xFF16A34A).copy(alpha = 0.08f) else if (isTrialActive) Color(0xFF0284C7).copy(alpha = 0.08f) else Color(0xFFDC2626).copy(alpha = 0.08f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isSubscribed) Icons.Default.WorkspacePremium else if (isTrialActive) Icons.Default.CardGiftcard else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isSubscribed) Color(0xFF16A34A) else if (isTrialActive) Color(0xFF0284C7) else Color(0xFFDC2626)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "اشتراك وتراخيص Google Play",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = if (isSubscribed) {
                                            "مفعل ونشط عبر Google Play ✅"
                                        } else if (isTrialActive) {
                                            "فترة تجريبية مجانية (متبقي $remainingTrialDays أيام) 🎁"
                                        } else {
                                            "انتهت الفترة التجريبية (7 أيام) - يلزم الاشتراك"
                                        },
                                        fontSize = 11.sp,
                                        color = if (isSubscribed) Color(0xFF16A34A) else if (isTrialActive) Color(0xFF0284C7) else Color(0xFFDC2626)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSubscribed) Color(0xFF16A34A).copy(alpha = 0.2f) else if (isTrialActive) Color(0xFF0284C7).copy(alpha = 0.2f) else Color(0xFFDC2626).copy(alpha = 0.2f),
                                contentColor = if (isSubscribed) Color(0xFF16A34A) else if (isTrialActive) Color(0xFF0284C7) else Color(0xFFDC2626)
                            ) {
                                Text(
                                    text = if (isSubscribed) (if (activeProductId == com.generator.billing.util.BillingManager.PRODUCT_YEARLY) "اشتراك سنوي ⭐" else "اشتراك شهري ⭐") else if (isTrialActive) "فترة تجريبية" else "منتهي الصلاحية",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "• الخطط المتاحة: $5.00 شهرياً أو $50.00 سنوياً (توفير شهرين).\n• فترة تجريبية مجانية لمدة 7 أيام مع كل حساب Google جديد.\n• تتم المعالجة وإدارة التجديد والإلغاء حصرياً عبر Google Play Billing بأمان تام.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { showPaywallDialog = true },
                                modifier = Modifier.weight(1.2f)
                            ) {
                                Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("خطط الاشتراك والترقية", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    val activity = context as? android.app.Activity
                                    if (activity != null) {
                                        viewModel.openGooglePlaySubscriptions(activity)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إدارة / إلغاء", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            TextButton(
                                onClick = { viewModel.simulateTrialExpiry(true) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("محاكاة انتهاء الـ 7 أيام ⌛", fontSize = 10.sp, color = Color(0xFFDC2626))
                            }
                            TextButton(
                                onClick = { viewModel.simulateTrialExpiry(false) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("استعادة الـ 7 أيام مجاناً 🎁", fontSize = 10.sp, color = Color(0xFF16A34A))
                            }
                        }
                    }
                }
            }

            // Current Session & User Management
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ManageAccounts, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("إدارة الحسابات والأدوار والرمز السرّي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ) {
                                Text(
                                    text = "${currentUser?.name} (${if (currentUser?.role == "ADMIN") "صاحب المولدة" else "جابي"})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("قم بالتبديل بين الحسابات أو إضافة حُساب جابي جديد بكلمة سر واسم خاص به:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            users.forEach { u ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (currentUser?.id == u.id) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(u.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (u.role == "ADMIN") Color(0xFF16A34A).copy(alpha = 0.15f) else Color(0xFF0284C7).copy(alpha = 0.15f),
                                                    contentColor = if (u.role == "ADMIN") Color(0xFF16A34A) else Color(0xFF0284C7)
                                                ) {
                                                    Text(
                                                        text = if (u.role == "ADMIN") "صاحب المولدة (المدير)" else "جابي اشتراكات",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "رمز PIN: **** • ${if (u.canViewFinancials) "صلاحية مالية كاملة" else "جباية فقط بدون أرباح"}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (currentUser?.id != u.id) {
                                                Button(
                                                    onClick = { userToSwitch = u },
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                    modifier = Modifier.height(36.dp)
                                                ) {
                                                    Text("دخول", fontSize = 12.sp)
                                                }
                                            } else {
                                                Text("نشط الآن", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            }

                                            if (currentUser?.role == "ADMIN") {
                                                IconButton(onClick = { userToEdit = u }) {
                                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", modifier = Modifier.size(18.dp))
                                                }
                                                if (u.role != "ADMIN" || users.count { it.role == "ADMIN" } > 1) {
                                                    IconButton(onClick = { viewModel.deleteUserAccount(u.id) }) {
                                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (currentUser?.role == "ADMIN") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { showAddUserDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إضافة حساب جابي جديد")
                            }
                        }
                    }
                }
            }

            // Backup & Export Section (Local File & PDF Backup)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FolderZip, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("النسخ الاحتياطي وتصدير البيانات", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF0284C7).copy(alpha = 0.15f),
                                contentColor = Color(0xFF0284C7)
                            ) {
                                Text("PDF & Excel & JSON", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("يمكنك الاحتفاظ بنسخة احتياطية شاملة ومنسقة بملف PDF احترافي لجميع المشتركين والفواتير والمقبوضات والمصروفات، أو تصدير كشوفات Excel، أو حفظ ملف JSON واستعادته في أي وقت.", fontSize = 12.sp, lineHeight = 16.sp)

                        Spacer(modifier = Modifier.height(12.dp))

                        // Full Professional PDF Backup Button (Hero Button)
                        Button(
                            onClick = {
                                val file = viewModel.exportFullBackupPdf(context)
                                if (file != null) {
                                    PrintHelper.shareFile(context, file, "application/pdf", "مشاركة النسخة الاحتياطية الشاملة (PDF)")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDC2626) // Premium Crimson Red
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(20.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("الاحتفاظ بنسخة احتياطية شاملة (ملف PDF احترافي ومنسق) 📑", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val file = viewModel.exportToExcelCsv(context)
                                    if (file != null) {
                                        PrintHelper.shareFile(context, file, "text/csv", "تصدير كشف Excel")
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.SimCardDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تصدير Excel", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    val file = viewModel.exportToJsonBackup(context)
                                    if (file != null) {
                                        PrintHelper.shareFile(context, file, "application/json", "مشاركة النسخة الاحتياطية")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("نسخة محليّة JSON", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = { filePickerLauncher.launch("*/*") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("اختيار واستعادة ملف نسخة احتياطية (Import JSON/CSV)")
                        }
                    }
                }
            }

            // POS Thermal Printers & Smart Terminals Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Color(0xFF0D9488))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("طابعات وأجهزة الجباية POS الحرارية", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text("Sunmi / PAX / طابعات البلوتوث 58mm & 80mm", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "يدعم التطبيق الطباعة الفورية للفواتير وسندات القبض وكشوفات الجباية اليومية عبر أجهزة نقاط البيع POS وطابعات البلوتوث الحرارية المحمولة دون الحاجة لبرامج وسيطة.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showPosDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فحص والاتصال بطابعة POS / طباعة تجريبية 🖨️")
                        }
                    }
                }
            }

            // App Security & Screen Lock Card (PIN / Biometric / Pattern Protection)
            item {
                val isAppLockEnabled by viewModel.isAppLockEnabled.collectAsState()
                val lockType by viewModel.lockType.collectAsState()
                val savedPin by viewModel.securityPin.collectAsState()
                val savedPattern by viewModel.securityPattern.collectAsState()

                var showPinEditDialog by remember { mutableStateOf(false) }
                var showPatternEditDialog by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isAppLockEnabled) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isAppLockEnabled) Icons.Default.Lock else Icons.Default.LockOpen,
                                    contentDescription = null,
                                    tint = if (isAppLockEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("الحماية الاختيارية وقفل التطبيق", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(
                                        text = if (isAppLockEnabled) "الحماية مفعلة (${when (lockType) {
                                            com.example.generator.util.LockType.BIOMETRIC -> "بصمة الإصبع / الوجه"
                                            com.example.generator.util.LockType.PATTERN -> "نمط الشاشة"
                                            else -> "رمز PIN"
                                        }}) 🔒" else "الحماية معطلة - فتح مباشر دون قفل 🔓",
                                        fontSize = 11.sp,
                                        color = if (isAppLockEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Switch(
                                checked = isAppLockEnabled,
                                onCheckedChange = { enabled ->
                                    viewModel.setAppLockEnabled(enabled)
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "• عند التفعيل: يمكنك حماية منظومة المولدة عبر رمز PIN مخصص، بصمة الإصبع، أو نمط الشاشة.\n• عند التعطيل: يدخل التطبيق مباشرة إلى واجهة التحكم دون طلب أي رمز سرّي أو قفل إجباري.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )

                        if (isAppLockEnabled) {
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(12.dp))

                            Text("اختر وسيلة الحماية المفضلة:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // PIN option
                                FilterChip(
                                    selected = lockType == com.example.generator.util.LockType.PIN,
                                    onClick = { viewModel.setLockType(com.example.generator.util.LockType.PIN) },
                                    label = { Text("رمز PIN (أرقام)") },
                                    leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.weight(1f)
                                )

                                // Biometric option
                                FilterChip(
                                    selected = lockType == com.example.generator.util.LockType.BIOMETRIC,
                                    onClick = { viewModel.setLockType(com.example.generator.util.LockType.BIOMETRIC) },
                                    label = { Text("بصمة الإصبع") },
                                    leadingIcon = { Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.weight(1f)
                                )

                                // Pattern option
                                FilterChip(
                                    selected = lockType == com.example.generator.util.LockType.PATTERN,
                                    onClick = { viewModel.setLockType(com.example.generator.util.LockType.PATTERN) },
                                    label = { Text("نمط الشاشة") },
                                    leadingIcon = { Icon(Icons.Default.Pattern, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (lockType == com.example.generator.util.LockType.PIN) {
                                    OutlinedButton(
                                        onClick = { showPinEditDialog = true },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تغيير رمز PIN ($savedPin)", fontSize = 11.sp)
                                    }
                                }

                                Button(
                                    onClick = { viewModel.lockApp() },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تجربة القفل الآن", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // PIN Edit Dialog
                if (showPinEditDialog) {
                    var newPin by remember { mutableStateOf("") }
                    AlertDialog(
                        onDismissRequest = { showPinEditDialog = false },
                        title = { Text("تعيين رمز PIN الجديد", fontWeight = FontWeight.Bold) },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("أدخل رمز PIN الجديد المكوّن من 4 أرقام:")
                                OutlinedTextField(
                                    value = newPin,
                                    onValueChange = { if (it.length <= 6) newPin = it },
                                    label = { Text("رمز PIN الجديد") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    if (newPin.isNotBlank()) {
                                        viewModel.setSecurityPin(newPin)
                                        showPinEditDialog = false
                                    }
                                }
                            ) {
                                Text("حفظ الرمز")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showPinEditDialog = false }) {
                                Text("إلغاء")
                            }
                        }
                    )
                }
            }

            // Generator Configuration (Admin Only)
            if (currentUser?.role == "ADMIN") {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("بيانات وإعدادات المولدة وطريقة الدفع", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }

                            OutlinedTextField(
                                value = generatorName,
                                onValueChange = { generatorName = it },
                                label = { Text("اسم المولدة الأهلية") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = ownerName,
                                onValueChange = { ownerName = it },
                                label = { Text("اسم صاحب المولدة (المدير العام)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("رقم هاتف المولدة / الصيانة") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = address,
                                onValueChange = { address = it },
                                label = { Text("العنوان / الموقع") },
                                placeholder = { Text("اختياري - اتركه فارغاً لعدم إظهار أي عنوان في الفاتورة") },
                                leadingIcon = {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = priceText,
                                onValueChange = { priceText = it },
                                label = { Text("سعر الأمبير الافتراضي (د.ع)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = mastercardNumber,
                                onValueChange = { mastercardNumber = it },
                                label = { Text("رقم الماستر كارد / الحساب البنكي (للتسديد الإلكتروني)") },
                                placeholder = { Text("مثال: 5324 8899 7766 5544 أو حساب مصرفي/زين كاش") },
                                leadingIcon = {
                                    Icon(Icons.Default.CreditCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Text(
                                text = "💡 عند حفظ رقم الماستر كارد، سيظهر تلقائياً في فواتير المشتركين لإتاحة التحويل المالي الإلكتروني مع إمكانية نسخ الرقم وإرفاق وصل التحويل.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )

                            Button(
                                onClick = {
                                    val price = priceText.toDoubleOrNull() ?: 10000.0
                                    viewModel.saveSettings(generatorName, ownerName, phone, address, price, mastercardNumber)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("حفظ الإعدادات وتطبيق السعر على الجميع")
                            }
                        }
                    }
                }
            }

            // Privacy Policy & Data Safety Card (Google Play Policy Mandatory)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("سياسة الخصوصية وأمان البيانات", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF0284C7).copy(alpha = 0.15f),
                                contentColor = Color(0xFF0284C7)
                            ) {
                                Text(
                                    text = "Google Play Verified",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "نحن نحترم خصوصية بيانات المشتركين والمداخيل المالية. جميع البيانات مشفرة ومحفوظة محلياً أو سحابياً وفق أعلى معايير الأمان.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showPrivacyPolicyDialog = true },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PrivacyTip, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("عرض سياسة الخصوصية", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Danger Zone: Permanent Account & Data Deletion (Google Play Compliance)
            if (currentUser?.role == "ADMIN") {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "حذف الحساب والبيانات نهائياً (Account Deletion)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "وفقاً لسياسة Google Play، يحق لك حذف حسابك وجميع بيانات المشتركين والفواتير والمصروفات الخاصة بك نهائياً من قاعدة البيانات والتخزين السحابي.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 16.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { showDeleteAccountDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("طلب حذف الحساب وجميع البيانات نهائياً", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

    // Paywall Dialog
    if (showPaywallDialog) {
        SubscriptionPaywallDialog(
            viewModel = viewModel,
            onDismiss = { showPaywallDialog = false }
        )
    }

    // Help & Tutorial Dialog
    if (showHelpTutorialDialog) {
        com.example.generator.ui.components.HelpTutorialDialog(
            onDismiss = { showHelpTutorialDialog = false }
        )
    }

    // Privacy Policy Dialog
    if (showPrivacyPolicyDialog) {
        PrivacyPolicyDialog(
            onDismiss = { showPrivacyPolicyDialog = false }
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountDialog = false },
            icon = {
                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(36.dp))
            },
            title = {
                Text("تأكيد حذف الحساب وجميع البيانات نهائياً؟", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "تحذير شديد الأهمية: هذا الإجراء لا يمكن التراجع عنه مطلقاً وسيؤدي إلى:",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                    Text("• مسح وحذف كافة سجلات المشتركين والجوزات والأمبيرات.")
                    Text("• مسح وحذف جميع الفواتير وسندات القبض ومبالغ الديون التاريخية.")
                    Text("• مسح سجلات المصروفات وحسابات الجباة المسجلة.")
                    Text("• إعادة ضبط التطبيق بالكامل كأنه مثبت لأول مرة.")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAllAccountDataAndReset()
                        showDeleteAccountDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، احذف كل شيء نهائياً")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteAccountDialog = false }) {
                    Text("إلغاء وتراجع")
                }
            }
        )
    }

    // Switch User PIN Dialog
    if (userToSwitch != null) {
        var pinInput by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { userToSwitch = null },
            title = { Text("تأكيد تسجيل الدخول بحساب: ${userToSwitch?.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("يرجى إدخال رمز الدخول (PIN) المكون من أرقام للتحقق من هويتك:")
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            pinInput = it
                            pinError = false
                        },
                        label = { Text("رمز الدخول (PIN)") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        isError = pinError,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError) {
                        Text("رمز PIN غير صحيح! يرجى إعادة المحاولة.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val targetUser = userToSwitch ?: return@Button
                        val success = viewModel.verifyAndSwitchUser(targetUser, pinInput)
                        if (success) {
                            userToSwitch = null
                        } else {
                            pinError = true
                        }
                    }
                ) {
                    Text("دخول")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { userToSwitch = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Restore Confirm Dialog
    if (showRestoreConfirmDialog && pendingRestoreContent != null) {
        AlertDialog(
            onDismissRequest = {
                showRestoreConfirmDialog = false
                pendingRestoreContent = null
            },
            title = { Text("تأكيد استعادة البيانات من الملف") },
            text = {
                Text("هل أنت تأكد من استعادة البيانات؟ سيتم تحديث وتنسيق قاعدة البيانات واستبدال السجلات الحالية بأمان.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingRestoreContent?.let { viewModel.restoreFromJsonContent(it) }
                        showRestoreConfirmDialog = false
                        pendingRestoreContent = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("استعادة واكتمال")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showRestoreConfirmDialog = false
                        pendingRestoreContent = null
                    }
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Add User Dialog
    if (showAddUserDialog) {
        AddUserDialog(
            onDismiss = { showAddUserDialog = false },
            onConfirm = { username, name, pin, role, canDelete, canViewFinancials ->
                viewModel.addUserAccount(username, name, pin, role, canDelete, canViewFinancials)
                showAddUserDialog = false
            }
        )
    }

    // Edit User Dialog
    if (userToEdit != null) {
        EditUserDialog(
            user = userToEdit!!,
            onDismiss = { userToEdit = null },
            onConfirm = { updatedUser ->
                viewModel.updateUserAccount(updatedUser)
                userToEdit = null
            }
        )
    }

    // POS Printer Dialog
    if (showPosDialog) {
        PosPrintDialog(
            target = PosPrintTarget.TestPrint,
            settings = settings,
            onDismiss = { showPosDialog = false }
        )
    }
}

@Composable
fun AddUserDialog(
    onDismiss: () -> Unit,
    onConfirm: (username: String, name: String, pin: String, role: String, canDelete: Boolean, canViewFinancials: Boolean) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("COLLECTOR") }
    var canDelete by remember { mutableStateOf(false) }
    var canViewFinancials by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة حساب جابي جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الجابي / المستخدم (مثلاً: الجابي كرار)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم المستخدم للدخول (Username)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text("رمز الدخول PIN (مثلاً: 1234)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("صلاحية حذف المشتركين/الفواتير:")
                    Switch(checked = canDelete, onCheckedChange = { canDelete = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("صلاحية الاطلاع على الأرباح والمصروفات:")
                    Switch(checked = canViewFinancials, onCheckedChange = { canViewFinancials = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(username, name, pin, role, canDelete, canViewFinancials) }
            ) {
                Text("إضافة الحساب")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun EditUserDialog(
    user: UserAccount,
    onDismiss: () -> Unit,
    onConfirm: (updatedUser: UserAccount) -> Unit
) {
    var name by remember { mutableStateOf(user.name) }
    var username by remember { mutableStateOf(user.username) }
    var pin by remember { mutableStateOf(user.pinCode) }
    var canDelete by remember { mutableStateOf(user.canDelete) }
    var canViewFinancials by remember { mutableStateOf(user.canViewFinancials) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل بيانات وصلاحيات الحساب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المستخدم") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم الدخول (Username)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text("رمز الدخول PIN") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (user.role != "ADMIN") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("صلاحية الحذف:")
                        Switch(checked = canDelete, onCheckedChange = { canDelete = it })
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("عرض الأرباح والمصروفات:")
                        Switch(checked = canViewFinancials, onCheckedChange = { canViewFinancials = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = user.copy(
                        name = name,
                        username = username,
                        pinCode = pin,
                        canDelete = if (user.role == "ADMIN") true else canDelete,
                        canViewFinancials = if (user.role == "ADMIN") true else canViewFinancials
                    )
                    onConfirm(updated)
                }
            ) {
                Text("حفظ التغييرات")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
