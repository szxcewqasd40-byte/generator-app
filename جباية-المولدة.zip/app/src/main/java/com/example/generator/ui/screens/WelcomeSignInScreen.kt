package com.example.generator.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.generator.ui.components.ElectricBadge
import com.example.generator.ui.components.GlassCard
import com.example.generator.ui.components.Glossy3DIcon
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.ui.theme.*

/**
 * Modern, clean Welcome & One-Tap Google / Phone Sign-In Screen.
 * Styled in Midnight Electric Navy with floating Glassmorphism & 3D glowing energy orb.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WelcomeSignInScreen(
    viewModel: GeneratorViewModel,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    var showPhoneDialog by remember { mutableStateOf(false) }
    var showQuickAccountPicker by remember { mutableStateOf(false) }

    // Intercept back button on login
    BackHandler(enabled = true) {
        activity?.moveTaskToBack(true)
    }

    MidnightCyberBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top App Branding & 3D Glowing Energy Orb
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 36.dp)
            ) {
                Glossy3DIcon(
                    imageRes = R.drawable.icon_3d_energy_1787310378195,
                    contentDescription = "Generator Smart System",
                    size = 96.dp,
                    glowColor = ElectricCyan
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "منظومة إدارة وجباية المولدات الأهلية",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhitePrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "الجيل الذكي لإدارة المشتركين، الجباية السريعة، الطباعة الحرارية والمزامنة السحابية",
                    fontSize = 12.sp,
                    color = TextCyanSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // 7-Day Free Trial Badge
                ElectricBadge(
                    text = "🎁 فترة تجريبية مجانية لمدة 7 أيام مع كل حساب جديد",
                    color = MetallicEmerald
                )
            }

            // Central Actions: Glass Cards for Google & Phone Sign-In
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Google One-Tap Sign In Button
                Button(
                    onClick = { showQuickAccountPicker = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF4285F4),
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("G", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "تسجيل الدخول باستخدام Google",
                            color = Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                // 2. Phone Number SMS Sign In Button
                OutlinedButton(
                    onClick = { showPhoneDialog = true },
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.2.dp, ElectricCyan.copy(alpha = 0.8f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(20.dp), tint = ElectricCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "الدخول برقم الهاتف ورمز التحقق (SMS)",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }

                // 3. Fast Instant Start (Local Mode for Demo/Instant access)
                TextButton(
                    onClick = {
                        viewModel.signInWithGoogleFast(
                            displayName = "صاحب المولدة (مدير النظام)",
                            email = "generator.owner@gmail.com"
                        )
                        onSuccess()
                    }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TextCyanSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "الدخول السريع بحساب المدير الافتراضي ⚡",
                            color = TextCyanSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Bottom Policy & Terms Note
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "بالتسجيل، أنت توافق على شروط الخدمة وسياسة الخصوصية الخاصة بالتطبيق والمحمية بمعايير Google Play.",
                    fontSize = 10.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    lineHeight = 14.sp
                )
            }
        }
    }

    // Google Account Picker Dialog
    if (showQuickAccountPicker) {
        AlertDialog(
            onDismissRequest = { showQuickAccountPicker = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF4285F4),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("G", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("اختر حساب Google للمتابعة", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextWhitePrimary)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "اختر أحد الحسابات المسجلة على هذا الهاتف لتسجيل الدخول الفوري وربط قاعدة البيانات السحابية:",
                        fontSize = 12.sp,
                        color = TextCyanSecondary
                    )

                    // Account 1
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.signInWithGoogleFast(
                                    displayName = "حساب Google الأساسي",
                                    email = "nasiriyah1984@gmail.com"
                                )
                                showQuickAccountPicker = false
                                onSuccess()
                            },
                        shape = RoundedCornerShape(14.dp),
                        borderColor = ElectricCyan.copy(alpha = 0.4f),
                        backgroundColor = Color(0xCC0C1635)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = ElectricCyan.copy(alpha = 0.2f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("صاحب المولدة (الرئيسي)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextWhitePrimary)
                                Text("nasiriyah1984@gmail.com", fontSize = 11.sp, color = TextCyanSecondary)
                            }
                        }
                    }
                }
            },
            containerColor = Color(0xFF0D1838),
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showQuickAccountPicker = false }) {
                    Text("إلغاء", color = TextCyanSecondary)
                }
            }
        )
    }

    // Phone SMS Dialog
    if (showPhoneDialog) {
        var phoneNumber by remember { mutableStateOf("") }
        var verificationCode by remember { mutableStateOf("") }
        var isCodeSent by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showPhoneDialog = false },
            title = {
                Text(
                    text = if (!isCodeSent) "الدخول برقم الهاتف" else "أدخل رمز التحقق (OTP)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextWhitePrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!isCodeSent) {
                        Text(
                            text = "أدخل رقم هاتفك لتسجيل الدخول السحابي ومزامنة سجلات المولدة:",
                            fontSize = 12.sp,
                            color = TextCyanSecondary
                        )
                        OutlinedTextField(
                            value = phoneNumber,
                            onValueChange = { phoneNumber = it },
                            label = { Text("رقم الهاتف (مثال: 07701234567)") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = ElectricCyan) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Done),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    } else {
                        Text(
                            text = "تم إرسال رمز التأكيد إلى الرقم $phoneNumber:",
                            fontSize = 12.sp,
                            color = TextCyanSecondary
                        )
                        OutlinedTextField(
                            value = verificationCode,
                            onValueChange = { verificationCode = it },
                            label = { Text("رمز التحقق (مثال: 123456)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = ElectricCyan) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            },
            containerColor = Color(0xFF0D1838),
            confirmButton = {
                Button(
                    onClick = {
                        if (!isCodeSent) {
                            if (phoneNumber.isNotBlank()) {
                                isCodeSent = true
                            }
                        } else {
                            viewModel.signInWithPhone(phoneNumber, "صاحب المولدة")
                            showPhoneDialog = false
                            onSuccess()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = MidnightNavyDeep)
                ) {
                    Text(if (!isCodeSent) "إرسال الرمز 📩" else "تأكيد والدخول 🚀", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showPhoneDialog = false },
                    border = BorderStroke(1.dp, Color(0x3338BDF8))
                ) {
                    Text("إلغاء", color = TextWhitePrimary)
                }
            }
        )
    }
}
