package com.example.generator.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties

data class HelpSectionItem(
    val id: String,
    val title: String,
    val summary: String,
    val icon: ImageVector,
    val color: Color,
    val steps: List<String>,
    val tips: List<String>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpTutorialDialog(
    onDismiss: () -> Unit
) {
    val helpSections = remember {
        listOf(
            HelpSectionItem(
                id = "add_subscriber",
                title = "1. كيفية إضافة مشترك جديد وتحديد الخط / الفيز",
                summary = "إدخال الاسم الكامل، رقم الهاتف، عدد الأمبيرات، ورقم الجوزة بكل سلاسة.",
                icon = Icons.Default.PersonAdd,
                color = Color(0xFF0284C7),
                steps = listOf(
                    "انتقل إلى شاشة «المشتركون» من شريط التنقل السفلي.",
                    "اضغط على الزر الدائري العائم ( + ) في أسفل الشاشة أو زر «إضافة مشترك».",
                    "أدخل «الاسم الكامل للمشترك» (يمكنك أيضاً استخدام الإدخال الصوتي بالنقر على أيقونة الميكروفون 🎙️).",
                    "اكتب «رقم هاتف المشترك» المكون من 11 رقماً، وسينتقل المؤشر تلقائياً لحقل الأمبيرات.",
                    "حدد «عدد الأمبيرات» وسعر الأمبير (أو اختر اسم الفيز/الخط المعرف مسبقاً لتطبيق سعره تلقائياً).",
                    "أدخل «رقم الجوزة ⚡» وملاحظات الموقع، ثم اضغط زر «حفظ المشترك»."
                ),
                tips = listOf(
                    "💡 عند حفظ المشترك، يتم توليد رمز مشترك فريد (مثل SUB-001) وكود باركود خاص به فوراً.",
                    "💡 يمكنك تعديل بيانات أي مشترك أو حذف اشتراكه في أي وقت بالضغط على زر التعديل في بطاقته."
                )
            ),
            HelpSectionItem(
                id = "issue_and_print_bill",
                title = "2. كيفية إصدار الفواتير وطباعة الوصولات وسندات القبض",
                summary = "طباعة حرارية POS أو بلوتوث، ومشاركة PDF أو واتساب بنقرة واحدة.",
                icon = Icons.Default.Print,
                color = Color(0xFF16A34A),
                steps = listOf(
                    "انتقل إلى شاشة «الفواتير والديون» ثم اضغط زر «توليد فواتير الشهر الجديد ⚡».",
                    "سيقوم النظام تلقائياً باحتساب الفاتورة الشهرية لكل مشترك بناءً على عدد أمبيراته وسعر خطه.",
                    "لتسديد فاتورة: اضغط على بطاقة المشترك ثم اختر «تسديد كامل» أو «سداد جزئي».",
                    "لطباعة الوصل: اضغط على أيقونة الطباعة 🖨️ في بطاقة الفاتورة أو شاشة الإيصال.",
                    "اختر وسيلة الإخراج المطلوبة: «طباعة حرارية POS / بلوتوث»، «طباعة نظام Android»، أو «تصدير ومشاركة PDF»."
                ),
                tips = listOf(
                    "💡 يتم تضمين باركود الفاتورة ورقم الماستر كارد وتاريخ وساعة التسديد الفعلية لحظياً في كل وصل.",
                    "💡 يمكنك مشاركة الفاتورة عبر واتساب بضغطة زر دون الحاجة لطباعة ورقية."
                )
            ),
            HelpSectionItem(
                id = "backup_and_pdf",
                title = "3. النسخ الاحتياطي وتصدير كشف PDF الشامل",
                summary = "حفظ نسخة احتياطية لكافة بيانات المنظومة بملف PDF احترافي أو Excel أو JSON.",
                icon = Icons.Default.PictureAsPdf,
                color = Color(0xFFDC2626),
                steps = listOf(
                    "انتقل إلى شاشة «الإعدادات والنسخ الاحتياطي».",
                    "توجه إلى قسم «النسخ الاحتياطي وتصدير البيانات».",
                    "اضغط زر «الاحتفاظ بنسخة احتياطية شاملة (ملف PDF احترافي ومنسق) 📑».",
                    "سيتم فوراً إنشاء ملف PDF عالي الجودة يحتوي على مؤشرات الأداء، سجل المشتركين، الفواتير، المقبوضات، والمصروفات.",
                    "اختر التطبيق لمشاركة الملف أو حفظه في التخزين الداخلي / Downloads."
                ),
                tips = listOf(
                    "💡 يُفضل حفظ نسخة احتياطية PDF أو JSON دورياً نهاية كل شهر لتوثيق الحسابات.",
                    "💡 يمكنك استعادة بياناتك في أي وقت باختيار ملف النسخة الاحتياطية JSON."
                )
            ),
            HelpSectionItem(
                id = "collectors_and_pos",
                title = "4. إدارة حسابات الجباة وتوصيل طابعات POS",
                summary = "تحديد صلاحيات الجابي وربط طابعات البلوتوث المحمولة.",
                icon = Icons.Default.PointOfSale,
                color = Color(0xFFF59E0B),
                steps = listOf(
                    "من شاشة «الإعدادات»، اضغط «إضافة جابي جديد» لإنشاء حساب مخصص للجابي برمز PIN خاص.",
                    "يمكنك تفعيل أو تعطيل صلاحيات الجابي (مثل صلاحية حذف المشتركين أو الاطلاع على الأرباح الإجمالية).",
                    "لتوصيل طابعة حرارية: توجه لبطاقة «طابعات الفواتير المحمولة POS وبلوتوث» ثم اضغط «بحث وإعداد طابعة».",
                    "اقترن بالطابعة عبر البلوتوث وحدد عرض الورق (80mm أو 58mm)."
                ),
                tips = listOf(
                    "💡 كل وصل يتم تسجيله يحفظ تلقائياً اسم الجابي وساعة الاستلام لمنع أي التباس."
                )
            )
        )
    }

    var expandedSectionId by remember { mutableStateOf<String?>("add_subscriber") }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "دليل الاستخدام والشروحات",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "خطوات مبسطة لإدارة المولدة وطباعة الوصولات",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Tutorial Sections
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(helpSections) { section ->
                        val isExpanded = expandedSectionId == section.id

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isExpanded) section.color.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            ),
                            border = BorderStroke(
                                width = if (isExpanded) 1.5.dp else 1.dp,
                                color = if (isExpanded) section.color else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    expandedSectionId = if (isExpanded) null else section.id
                                }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                // Title & Accordion Header
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = section.color.copy(alpha = 0.15f),
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = section.icon,
                                                    contentDescription = null,
                                                    tint = section.color,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = section.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (!isExpanded) {
                                                Text(
                                                    text = section.summary,
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }

                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = null,
                                        tint = if (isExpanded) section.color else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Expanded Content (Steps & Pro Tips)
                                AnimatedVisibility(visible = isExpanded) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "📋 الخطوات العملية:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = section.color
                                        )

                                        section.steps.forEachIndexed { index, step ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.Top
                                            ) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = section.color.copy(alpha = 0.2f),
                                                    modifier = Modifier
                                                        .padding(top = 2.dp)
                                                        .size(18.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = "${index + 1}",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = section.color
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = step,
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    lineHeight = 17.sp,
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }

                                        if (section.tips.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Surface(
                                                shape = RoundedCornerShape(10.dp),
                                                color = Color(0xFFF1F5F9),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    section.tips.forEach { tip ->
                                                        Text(
                                                            text = tip,
                                                            fontSize = 11.sp,
                                                            color = Color(0xFF334155),
                                                            lineHeight = 15.sp
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Close Button
                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text("فهمت ذلك، إغلاق الدليل", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}
