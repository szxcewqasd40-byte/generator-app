package com.example.generator.util

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * خيارات وضع السمة (ليلي / نهاري / حسب النظام)
 */
enum class AppThemeMode(val title: String) {
    SYSTEM("تلقائي (حسب النظام)"),
    DARK("الوضع الليلي (Dark Mode) 🌙"),
    LIGHT("الوضع النهاري (Light Mode) ☀️")
}

/**
 * خيارات لوحة ألوان التطبيق:
 * 1. لون التطبيق الأصلي (الأزرق الكهربائي والسيان السيبراني والذهبي)
 * 2. أبيض وأسود مونوكروم (Monochrome Black & White)
 * 3. الأزرق الملكي الكلاسيكي (Classic Royal Blue)
 * 4. الأخضر الطاقي الزمردي (Emerald Energy)
 */
enum class AppColorPalette(val title: String) {
    ORIGINAL_CYBER("أزرق وسيان وسماوي (اللون الأصلي الفاخر)"),
    MONOCHROME_BW("أبيض وأسود (Monochrome Black & White)"),
    ROYAL_BLUE("الأزرق الملكي الرسمي (Royal Blue)"),
    EMERALD_GREEN("الأخضر الطاقي الزمردي (Emerald Green)")
}

class ThemePreferencesManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("generator_theme_prefs", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(loadThemeMode())
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    private val _colorPalette = MutableStateFlow(loadColorPalette())
    val colorPalette: StateFlow<AppColorPalette> = _colorPalette.asStateFlow()

    private fun loadThemeMode(): AppThemeMode {
        val name = prefs.getString(KEY_THEME_MODE, AppThemeMode.DARK.name) ?: AppThemeMode.DARK.name
        return try {
            AppThemeMode.valueOf(name)
        } catch (e: Exception) {
            AppThemeMode.DARK
        }
    }

    private fun loadColorPalette(): AppColorPalette {
        val name = prefs.getString(KEY_COLOR_PALETTE, AppColorPalette.ORIGINAL_CYBER.name) ?: AppColorPalette.ORIGINAL_CYBER.name
        return try {
            AppColorPalette.valueOf(name)
        } catch (e: Exception) {
            AppColorPalette.ORIGINAL_CYBER
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
    }

    fun setColorPalette(palette: AppColorPalette) {
        _colorPalette.value = palette
        prefs.edit().putString(KEY_COLOR_PALETTE, palette.name).apply()
    }

    companion object {
        private const val KEY_THEME_MODE = "key_app_theme_mode"
        private const val KEY_COLOR_PALETTE = "key_app_color_palette"
    }
}
