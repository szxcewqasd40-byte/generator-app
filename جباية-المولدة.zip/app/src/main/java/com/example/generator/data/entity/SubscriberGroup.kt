package com.example.generator.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subscriber_groups")
data class SubscriberGroup(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupName: String,
    val pricePerAmpere: Double = 0.0, // سعر الأمبير الخاص بالفيز أو المجموعة
    val fixedFee: Double = 0.0, // الرسوم الثابتة أو الفيزة الإضافية لكل مشترك في هذه المجموعة
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
