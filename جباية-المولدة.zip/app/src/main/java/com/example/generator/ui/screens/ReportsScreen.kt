package com.example.generator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.generator.mgr.R
import com.example.generator.data.entity.Bill
import com.example.generator.data.entity.Expense
import com.example.generator.data.entity.Payment
import com.example.generator.ui.components.GlassCard
import com.example.generator.ui.components.Glossy3DIcon
import com.example.generator.ui.components.MidnightCyberBackground
import com.example.generator.ui.components.PosPrintDialog
import com.example.generator.ui.components.PosPrintTarget
import com.example.generator.ui.viewmodel.GeneratorViewModel
import com.example.generator.util.ExcelExporterImporter
import com.example.generator.util.FileDownloadHelper
import com.example.generator.util.PrintHelper
import com.example.generator.util.VoiceSearchTextField
import com.example.ui.theme.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: GeneratorViewModel) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: المشتركين, 1: الفواتير, 2: الديون, 3: المقبوضات, 4: المصروفات, 5: الأرباح والخسائر

    val subscribers by viewModel.subscribers.collectAsState()
    val subscriberGroups by viewModel.subscriberGroups.collectAsState()
    val bills by viewModel.bills.collectAsState()
    val payments by viewModel.payments.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var selectedReportPhaseFilter by remember { mutableStateOf<String?>(null) }

    val totalCollected by viewModel.totalCollectedAmount.collectAsState()
    val totalExpenses by viewModel.totalExpensesAmount.collectAsState()
    val netProfit by viewModel.netProfit.collectAsState()
    val totalDebts by viewModel.totalDebtsAmount.collectAsState()

    val canViewFinancials = currentUser?.role == "ADMIN" || currentUser?.canViewFinancials == true

    var showExportDialog by remember { mutableStateOf(false) }
    var downloadedFileSuccess by remember { mutableStateOf<File?>(null) }
    var selectedExportType by remember { mutableIntStateOf(0) } // 0: الشامل, 1: الجباية اليومية, 2: الديون, 3: المصروفات
    var posPrintTarget by remember { mutableStateOf<PosPrintTarget?>(null) }

    val tabs = listOf(
        "الجباية اليومية والتفاصيل 📅",
        "المشتركين والفيزات",
        "الفواتير الصادرة",
        "الديون والمتأخرات",
        "تقارير الجباة والسجل التفصيلي",
        "كافة المقبوضات",
        "المصروفات التشغيلية",
        "الجدول الشهري والسنوي (ميزانية)"
    )

    // Export & Download Reports Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            icon = { Icon(Icons.Default.DownloadForOffline, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp)) },
            title = {
                Text(
                    text = "تحميل وتصدير التقارير المالية (Excel)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "اختر نوع التقرير المراد تنزيله وحفظه في ذاكرة الهاتف (مجلد التنزيلات Downloads):",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Report Type Selection Chips
                    val reportTypes = listOf(
                        "📊 التقرير المالي الشامل (كل الجداول)",
                        "📅 كشف الجباية اليومية والمقبوضات",
                        "🔴 كشف الديون والمتأخرات",
                        "📉 كشف المصروفات التشغيلية"
                    )

                    reportTypes.forEachIndexed { index, label ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedExportType == index) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = if (selectedExportType == index) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedExportType = index }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedExportType == index,
                                    onClick = { selectedExportType = index }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = label,
                                    fontSize = 13.sp,
                                    fontWeight = if (selectedExportType == index) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "💡 سيتم حفظ الملف تلقائياً بصيغة Excel (CSV UTF-8) في مجلد التنزيلات (Downloads) بجهازك ليتاح فتحه ومشاركته في أي وقت.",
                        fontSize = 11.sp,
                        color = Color(0xFF16A34A),
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val file = when (selectedExportType) {
                            0 -> viewModel.exportToExcelCsv(context)
                            1 -> viewModel.exportDailyPaymentsToExcelCsv(context, payments, "سجل اليوم")
                            2 -> viewModel.exportDebtsToExcelCsv(context)
                            3 -> viewModel.exportExpensesToExcelCsv(context)
                            else -> viewModel.exportToExcelCsv(context)
                        }
                        showExportDialog = false
                        if (file != null) {
                            downloadedFileSuccess = file
                        }
                    }
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تنزيل وحفظ في الهاتف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Downloaded File Success Dialog
    if (downloadedFileSuccess != null) {
        val file = downloadedFileSuccess!!
        AlertDialog(
            onDismissRequest = { downloadedFileSuccess = null },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(42.dp)) },
            title = {
                Text(
                    text = "تم تنزيل وحفظ التقرير بنجاح! 📥",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFF16A34A)
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("📁 تم الحفظ في: مجلد التنزيلات (Downloads)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("📄 اسم الملف: ${file.name}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            Text("💾 الحجم: ${file.length() / 1024 + 1} كيلوبايت", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Text(
                        text = "يمكنك الآن فتح الملف مباشرة ببرنامج Excel أو مشاركته مع المشتركين أو المحاسب عبر الواتساب:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                FileDownloadHelper.openFileWithApp(context, file, "text/csv")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("فتح في Excel", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                FileDownloadHelper.shareFile(context, file, "text/csv", "مشاركة تقرير المولدة")
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مشاركة واتساب", fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { downloadedFileSuccess = null }) {
                    Text("تم الإغلاق")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Glossy3DIcon(
                            imageRes = R.drawable.icon_3d_analytics_1787310400722,
                            contentDescription = null,
                            size = 36.dp,
                            glowColor = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("التقارير المالية والحسابية", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    }
                },
                actions = {
                    IconButton(onClick = { showExportDialog = true }) {
                        Icon(Icons.Default.Download, contentDescription = "تنزيل تقرير Excel إلى الهاتف", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        MidnightCyberBackground {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Horizontal Report Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (selectedTab) {
                0 -> {
                    // Daily Collection Report & Detailed Payers
                    DailyCollectionReportView(
                        payments = payments,
                        settings = settings,
                        onRevertPayment = { paymentId ->
                            viewModel.revertSinglePayment(paymentId)
                        },
                        onPrintPosPayment = { payment ->
                            val bill = bills.find { it.id == payment.billId }
                            posPrintTarget = PosPrintTarget.SinglePayment(payment, bill)
                        },
                        onPrintPosDailySummary = { dayList, dateStr ->
                            posPrintTarget = PosPrintTarget.DailySummary(dayList, dateStr)
                        }
                    )
                }
                1 -> {
                    // Subscribers & Phase Breakdown Report
                    val filteredList = if (selectedReportPhaseFilter == null) subscribers else subscribers.filter { it.groupName == selectedReportPhaseFilter }
                    val totalAmps = filteredList.filter { it.isActive }.sumOf { it.amperes }

                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            // Phase filter chips
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(bottom = 8.dp)
                            ) {
                                item {
                                    FilterChip(
                                        selected = selectedReportPhaseFilter == null,
                                        onClick = { selectedReportPhaseFilter = null },
                                        label = { Text("⚡ كافة الفيزات (${subscribers.size})") }
                                    )
                                }
                                items(subscriberGroups) { grp ->
                                    val count = subscribers.count { it.groupName == grp.groupName }
                                    FilterChip(
                                        selected = selectedReportPhaseFilter == grp.groupName,
                                        onClick = { selectedReportPhaseFilter = grp.groupName },
                                        label = { Text("${grp.groupName} ($count)") }
                                    )
                                }
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = selectedReportPhaseFilter ?: "كافة فيزات المولدة",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "المشتركين: ${filteredList.size} مشترك",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "مجموع الحمل المسحوب",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = "${String.format(Locale.US, "%.1f", totalAmps)} أمبير",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }

                        items(filteredList) { sub ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(sub.name, fontWeight = FontWeight.Bold)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("${sub.subscriberCode} • هاتف: ${sub.phone.ifBlank { "غير مدخل" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.secondaryContainer
                                        ) {
                                            Text(
                                                text = "🔌 ${sub.groupName}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("${sub.amperes} أمبير", fontWeight = FontWeight.Bold)
                                        Text(if (sub.isActive) "فعال" else "متوقف", fontSize = 12.sp, color = if (sub.isActive) Color(0xFF16A34A) else Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Bills Report
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("إجمالي الفواتير الصادرة: ${bills.size}", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        items(bills) { bill ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(bill.subscriberName, fontWeight = FontWeight.Bold)
                                        Text("شهر ${bill.month} / ${bill.year} • ${bill.billCode}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("الإجمالي: ${PrintHelper.formatCurrency(bill.totalAmount)}", fontWeight = FontWeight.Bold)
                                        Text("المتبقي: ${PrintHelper.formatCurrency(bill.remainingAmount)}", fontSize = 12.sp, color = Color(0xFFDC2626))
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Debts Report
                    val unpaidBills = bills.filter { it.remainingAmount > 0 }
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFDC2626).copy(alpha = 0.12f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("إجمالي الديون والمتأخرات الكلية", fontSize = 13.sp)
                                            Text(PrintHelper.formatCurrency(totalDebts), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                                        }

                                        FilledTonalButton(
                                            onClick = {
                                                val file = viewModel.exportDebtsToExcelCsv(context)
                                                if (file != null) downloadedFileSuccess = file
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("تنزيل كشف الديون (Excel)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                        items(unpaidBills) { bill ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(bill.subscriberName, fontWeight = FontWeight.Bold)
                                        Text("شهر ${bill.month}/${bill.year}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(
                                        text = PrintHelper.formatCurrency(bill.remainingAmount),
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFDC2626)
                                    )
                                }
                            }
                        }
                    }
                }
                4 -> {
                    // Collectors Report & Detailed Paid Subscribers Log
                    CollectorReportsView(payments = payments, settings = settings)
                }
                5 -> {
                    // All Payments Collections Report
                    val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar"))
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("إجمالي المقبوضات: ${PrintHelper.formatCurrency(totalCollected)}", fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        items(payments) { p ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(p.subscriberName, fontWeight = FontWeight.Bold)
                                        Text("${p.receiptCode} • ${p.collectedBy} • ${dateFormat.format(Date(p.paymentDate))}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(PrintHelper.formatCurrency(p.amountPaid), fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                }
                            }
                        }
                    }
                }
                6 -> {
                    // Expenses Report
                    if (!canViewFinancials) {
                        FinancialPrivacyNotice()
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEA580C).copy(alpha = 0.12f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("إجمالي المصروفات التشغيلية", fontSize = 13.sp)
                                            Text(PrintHelper.formatCurrency(totalExpenses), fontWeight = FontWeight.Bold, color = Color(0xFFEA580C), fontSize = 18.sp)
                                        }

                                        FilledTonalButton(
                                            onClick = {
                                                val file = viewModel.exportExpensesToExcelCsv(context)
                                                if (file != null) downloadedFileSuccess = file
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("تنزيل كشف المصروفات (Excel)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                            }
                            items(expenses) { exp ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(exp.category, fontWeight = FontWeight.Bold)
                                            Text(exp.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Text(PrintHelper.formatCurrency(exp.amount), fontWeight = FontWeight.Bold, color = Color(0xFFEA580C))
                                    }
                                }
                            }
                        }
                    }
                }
                7 -> {
                    // Monthly & Yearly Profit, Expense & Debts Table
                    if (!canViewFinancials) {
                        FinancialPrivacyNotice()
                    } else {
                        MonthlyYearlyFinancialTable(
                            bills = bills,
                            payments = payments,
                            expenses = expenses,
                            totalCollected = totalCollected,
                            totalExpenses = totalExpenses,
                            netProfit = netProfit,
                            totalDebts = totalDebts
                        )
                    }
                }
            }
        }
    }
}

    if (posPrintTarget != null) {
        PosPrintDialog(
            target = posPrintTarget!!,
            settings = settings,
            onDismiss = { posPrintTarget = null }
        )
    }
}

@Composable
fun FinancialPrivacyNotice() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "خصوصية الماليّة والأرباح",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "تقارير المصروفات التشغيلية وصافي الأرباح محصورة بحساب صاحب المولدة (المدير العام) لحماية الخصوصية المالية.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
        }
    }
}

data class MonthlyFinancialRow(
    val year: Int,
    val month: Int,
    val revenue: Double,
    val expenses: Double,
    val debts: Double,
    val netProfit: Double
)

@Composable
fun MonthlyYearlyFinancialTable(
    bills: List<Bill>,
    payments: List<Payment>,
    expenses: List<Expense>,
    totalCollected: Double,
    totalExpenses: Double,
    netProfit: Double,
    totalDebts: Double
) {
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    var selectedYear by remember { mutableIntStateOf(currentYear) }

    // Aggregate monthly data
    val monthlyDataMap = remember(bills, payments, expenses, selectedYear) {
        val map = mutableMapOf<Int, MonthlyFinancialRow>()

        for (m in 1..12) {
            val monthBills = bills.filter { it.year == selectedYear && it.month == m }
            val monthDebts = monthBills.sumOf { it.remainingAmount }

            val monthPayments = payments.filter { p ->
                val cal = Calendar.getInstance().apply { timeInMillis = p.paymentDate }
                cal.get(Calendar.YEAR) == selectedYear && (cal.get(Calendar.MONTH) + 1) == m
            }
            val rev = monthPayments.sumOf { it.amountPaid }

            val monthExpenses = expenses.filter { e ->
                val cal = Calendar.getInstance().apply { timeInMillis = e.expenseDate }
                cal.get(Calendar.YEAR) == selectedYear && (cal.get(Calendar.MONTH) + 1) == m
            }
            val exp = monthExpenses.sumOf { it.amount }

            map[m] = MonthlyFinancialRow(
                year = selectedYear,
                month = m,
                revenue = rev,
                expenses = exp,
                debts = monthDebts,
                netProfit = rev - exp
            )
        }
        map
    }

    val yearTotalRevenue = monthlyDataMap.values.sumOf { it.revenue }
    val yearTotalExpenses = monthlyDataMap.values.sumOf { it.expenses }
    val yearTotalDebts = monthlyDataMap.values.sumOf { it.debts }
    val yearNetProfit = yearTotalRevenue - yearTotalExpenses

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "جدول الميزانية للسنة المالية: $selectedYear",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedYear == currentYear,
                        onClick = { selectedYear = currentYear },
                        label = { Text("$currentYear") }
                    )
                    FilterChip(
                        selected = selectedYear == (currentYear - 1),
                        onClick = { selectedYear = currentYear - 1 },
                        label = { Text("${currentYear - 1}") }
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ملخص الميزانية والأرباح لسنة $selectedYear الكاملة", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("إجمالي المقبوضات:", fontSize = 12.sp, color = Color.Gray)
                            Text(PrintHelper.formatCurrency(yearTotalRevenue), fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                        }
                        Column {
                            Text("إجمالي المصروفات:", fontSize = 12.sp, color = Color.Gray)
                            Text(PrintHelper.formatCurrency(yearTotalExpenses), fontWeight = FontWeight.Bold, color = Color(0xFFEA580C))
                        }
                        Column {
                            Text("الديون المتبقية:", fontSize = 12.sp, color = Color.Gray)
                            Text(PrintHelper.formatCurrency(yearTotalDebts), fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("صافي الأرباح لسنة $selectedYear:", fontWeight = FontWeight.Bold)
                        Text(
                            text = PrintHelper.formatCurrency(yearNetProfit),
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = if (yearNetProfit >= 0) Color(0xFF16A34A) else Color(0xFFDC2626)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text("تفاصيل الأشهر للسنة المالية $selectedYear (من شهر 1 إلى 12):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        items((1..12).toList()) { monthNum ->
            val row = monthlyDataMap[monthNum]!!
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (row.revenue > 0 || row.expenses > 0 || row.debts > 0) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📅 شهر $monthNum / $selectedYear",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        Text(
                            text = "صافي الربح: ${PrintHelper.formatCurrency(row.netProfit)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (row.netProfit >= 0) Color(0xFF16A34A) else Color(0xFFDC2626)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("مقبوضات: ${PrintHelper.formatCurrency(row.revenue)}", fontSize = 11.sp, color = Color(0xFF16A34A))
                        Text("مصاريف: ${PrintHelper.formatCurrency(row.expenses)}", fontSize = 11.sp, color = Color(0xFFEA580C))
                        Text("ديون متبقية: ${PrintHelper.formatCurrency(row.debts)}", fontSize = 11.sp, color = Color(0xFFDC2626))
                    }
                }
            }
        }
    }
}

@Composable
fun CollectorReportsView(
    payments: List<Payment>,
    settings: com.example.generator.data.entity.GeneratorSettings?
) {
    val context = LocalContext.current
    val dateTimeFormat = remember { SimpleDateFormat("yyyy/MM/dd • hh:mm a", Locale("ar")) }

    // Group payments by collector name
    val collectorGroups = remember(payments) {
        payments.groupBy { if (it.collectedBy.isBlank()) "الجابي العام" else it.collectedBy }
    }

    val collectorNames = remember(collectorGroups) {
        collectorGroups.keys.toList()
    }

    var selectedCollector by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    // Auto-select first collector if none selected
    LaunchedEffect(collectorNames) {
        if (selectedCollector == null && collectorNames.isNotEmpty()) {
            selectedCollector = collectorNames.first()
        }
    }

    val activeCollectorPayments = remember(payments, selectedCollector, searchQuery) {
        val collectorPayments = if (selectedCollector == null) {
            payments
        } else {
            payments.filter { (if (it.collectedBy.isBlank()) "الجابي العام" else it.collectedBy) == selectedCollector }
        }

        if (searchQuery.isBlank()) {
            collectorPayments
        } else {
            val q = searchQuery.trim().lowercase()
            collectorPayments.filter {
                it.subscriberName.lowercase().contains(q) ||
                it.receiptCode.lowercase().contains(q) ||
                it.notes.lowercase().contains(q)
            }
        }
    }

    val activeCollectorTotal = remember(activeCollectorPayments) {
        activeCollectorPayments.sumOf { it.amountPaid }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Collectors Overview Header Card
        item {
            Text(
                text = "تقارير تحصيل الجباة وسجل المشتركين المسددين",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (collectorNames.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Text(
                        text = "لا توجد أي عمليات دفع مسجلة للجباة حتى الآن.",
                        fontSize = 13.sp,
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                // Selector Chips for Collectors with total collected per collector
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(collectorNames) { colName ->
                        val colPayments = collectorGroups[colName] ?: emptyList()
                        val colSum = colPayments.sumOf { it.amountPaid }
                        val isSelected = selectedCollector == colName

                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCollector = colName },
                            label = {
                                Column(modifier = Modifier.padding(vertical = 2.dp)) {
                                    Text(colName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(PrintHelper.formatCurrency(colSum), fontSize = 10.sp, color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else Color(0xFF16A34A))
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    }
                }
            }
        }

        // Active Collector Summary Banner
        if (selectedCollector != null) {
            item {
                val totalCount = collectorGroups[selectedCollector]?.size ?: 0
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "الجابي المحدد: $selectedCollector",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "عدد الدفعات والمقبوضات: $totalCount إيصال",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "إجمالي التحصيل",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                text = PrintHelper.formatCurrency(activeCollectorTotal),
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // Voice search box for paid subscribers log
            item {
                VoiceSearchTextField(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholderText = "بحث صوتي أو كتابي باسم المشترك ($selectedCollector)...",
                    prompt = "تحدث باسم المشترك للبحث في سجل الجابي...",
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Title for subscriber log
            item {
                Text(
                    text = "سجل تفاصيل الدفعات للمشتركين المسددين للجابي ($selectedCollector):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Items of Paid Subscribers
            if (activeCollectorPayments.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد نتائج مسددة مطابقة للبحث",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                items(activeCollectorPayments) { payment ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = payment.subscriberName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "رقم الوصل/الإيصال: ${payment.receiptCode}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "التاريخ والوقت: ${dateTimeFormat.format(Date(payment.paymentDate))}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (payment.notes.isNotBlank()) {
                                    Text(
                                        text = "ملاحظة: ${payment.notes}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = PrintHelper.formatCurrency(payment.amountPaid),
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF16A34A),
                                    fontSize = 15.sp
                                )
                                IconButton(
                                    onClick = { PrintHelper.sharePaymentWhatsApp(context, payment, null, settings) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "مشاركة الإيصال",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyCollectionReportView(
    payments: List<Payment>,
    settings: com.example.generator.data.entity.GeneratorSettings?,
    onRevertPayment: (Long) -> Unit,
    onPrintPosPayment: (Payment) -> Unit,
    onPrintPosDailySummary: (List<Payment>, String) -> Unit
) {
    val context = LocalContext.current
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale("ar")) }
    val displayDateFormat = remember { SimpleDateFormat("EEEE ، d MMMM yyyy", Locale("ar")) }

    var selectedCalendar by remember { mutableStateOf(Calendar.getInstance()) }
    var searchQuery by remember { mutableStateOf("") }
    var paymentToRevert by remember { mutableStateOf<Payment?>(null) }

    val todayCalendar = remember { Calendar.getInstance() }

    // Helpers to compare days
    fun isSameDay(cal1: Calendar, cal2: Calendar): Boolean {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
               cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    val isToday = remember(selectedCalendar) { isSameDay(selectedCalendar, todayCalendar) }

    val dayPayments = remember(payments, selectedCalendar) {
        payments.filter { p ->
            val pCal = Calendar.getInstance().apply { timeInMillis = p.paymentDate }
            isSameDay(pCal, selectedCalendar)
        }
    }

    val filteredDayPayments = remember(dayPayments, searchQuery) {
        if (searchQuery.isBlank()) dayPayments
        else {
            val q = searchQuery.trim().lowercase()
            dayPayments.filter {
                it.subscriberName.lowercase().contains(q) ||
                it.receiptCode.lowercase().contains(q) ||
                it.collectedBy.lowercase().contains(q) ||
                it.notes.lowercase().contains(q)
            }
        }
    }

    val dayTotalCollected = remember(dayPayments) { dayPayments.sumOf { it.amountPaid } }
    val dayCollectorGroups = remember(dayPayments) {
        dayPayments.groupBy { if (it.collectedBy.isBlank()) "الجابي العام" else it.collectedBy }
    }

    // Confirmation dialog for reverting single receipt
    if (paymentToRevert != null) {
        val p = paymentToRevert!!
        AlertDialog(
            onDismissRequest = { paymentToRevert = null },
            icon = { Icon(Icons.Default.Undo, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("تأكيد التراجع عن الإيصال", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("المشترك: ${p.subscriberName}", fontWeight = FontWeight.Bold)
                    Text("رقم الإيصال: ${p.receiptCode}")
                    Text("مبلغ الإيصال: ${PrintHelper.formatCurrency(p.amountPaid)}", color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                    Text("هل تريد بالتأكيد إلغاء هذا الإيصال؟ سيتم خصمه من مجموع الجباية وإعادة إضافته كدين على الفاتورة.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRevertPayment(p.id)
                        paymentToRevert = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، تراجع عن القبض")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { paymentToRevert = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    fun openDatePicker() {
        val yr = selectedCalendar.get(Calendar.YEAR)
        val mo = selectedCalendar.get(Calendar.MONTH)
        val da = selectedCalendar.get(Calendar.DAY_OF_MONTH)
        android.app.DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val newCal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                }
                selectedCalendar = newCal
            },
            yr, mo, da
        ).show()
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Date Selector Header Card with Dedicated DatePicker
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("تقرير وسجل الجباية اليومية 📅", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("اختر أي تاريخ لعرض جباية ذلك اليوم", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                val newCal = Calendar.getInstance().apply {
                                    timeInMillis = selectedCalendar.timeInMillis
                                    add(Calendar.DAY_OF_YEAR, -1)
                                }
                                selectedCalendar = newCal
                            }) {
                                Icon(Icons.Default.ChevronRight, contentDescription = "اليوم السابق")
                            }

                            IconButton(onClick = {
                                val newCal = Calendar.getInstance().apply {
                                    timeInMillis = selectedCalendar.timeInMillis
                                    add(Calendar.DAY_OF_YEAR, 1)
                                }
                                selectedCalendar = newCal
                            }) {
                                Icon(Icons.Default.ChevronLeft, contentDescription = "اليوم التالي")
                            }
                        }
                    }

                    // Dedicated Date Picker Box / Button (Replaces Quick Chips)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { openDatePicker() }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = "اختيار تاريخ",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "التاريخ المعروض:",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = displayDateFormat.format(selectedCalendar.time),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Button(
                                onClick = { openDatePicker() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اختيار تاريخ 📅", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Daily Summary Stats
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("مجموع جباية اليوم", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                            Text(PrintHelper.formatCurrency(dayTotalCollected), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("عدد المشتركين المسددين", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                            Text("${dayPayments.size} مشترك / وصل", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }

                    if (dayPayments.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    val dateStr = displayDateFormat.format(selectedCalendar.time)
                                    onPrintPosDailySummary(dayPayments, dateStr)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF0D9488).copy(alpha = 0.15f),
                                    contentColor = Color(0xFF0D9488)
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("طباعة POS 🖨️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            FilledTonalButton(
                                onClick = {
                                    val dateStr = displayDateFormat.format(selectedCalendar.time)
                                    val file = ExcelExporterImporter.exportDailyPaymentsToExcelCsv(context, dayPayments, dateStr, settings)
                                    android.widget.Toast.makeText(context, "تم حفظ كشف الجباية في مجلد التنزيلات (Downloads): ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تنزيل كشف اليوم (Excel)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Breakdown by collector for this day
        if (dayCollectorGroups.isNotEmpty()) {
            item {
                Text("تحصيل الجباة لهذا اليوم (${dayCollectorGroups.size} جباة):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(dayCollectorGroups.entries.toList()) { entry ->
                        val colName = entry.key
                        val colPayments = entry.value
                        val colSum = colPayments.sumOf { it.amountPaid }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                    Text(colName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(PrintHelper.formatCurrency(colSum), fontWeight = FontWeight.Bold, color = Color(0xFF16A34A), fontSize = 13.sp)
                                Text("${colPayments.size} إيصالات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // Voice Search in Day's Receipts
        item {
            VoiceSearchTextField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholderText = "بحث صوتي أو كتابي باسم المشترك...",
                prompt = "تحدث باسم المشترك للبحث في كشف اليوم...",
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Detailed List of Payers for the Day
        item {
            Text(
                text = "قائمة المشتركين المسددين في تاريخ (${displayDateFormat.format(selectedCalendar.time)}):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (filteredDayPayments.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.EventBusy, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "لا توجد نتائج مطابقة لبحثك" else "لا توجد أي مقبوضات مسجلة في هذا التاريخ",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(filteredDayPayments) { payment ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = payment.subscriberName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("وصل: ${payment.receiptCode}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("•", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("الجابي: ${if (payment.collectedBy.isBlank()) "الجابي العام" else payment.collectedBy}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                }
                                Text(
                                    text = "الوقت: ${timeFormat.format(Date(payment.paymentDate))}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (payment.notes.isNotBlank()) {
                                    Text(
                                        text = "ملاحظة: ${payment.notes}",
                                        fontSize = 11.sp,
                                        color = Color(0xFFD97706)
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = PrintHelper.formatCurrency(payment.amountPaid),
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF16A34A),
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    // POS Thermal Receipt Button
                                    IconButton(
                                        onClick = { onPrintPosPayment(payment) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ReceiptLong,
                                            contentDescription = "طباعة وصل POS",
                                            tint = Color(0xFF0D9488),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    // Revert / Undo Single Payment Button
                                    IconButton(
                                        onClick = { paymentToRevert = payment },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Undo,
                                            contentDescription = "تراجع عن الإيصال",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    // Share receipt button
                                    IconButton(
                                        onClick = { PrintHelper.sharePaymentWhatsApp(context, payment, null, settings) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "مشاركة الوصل",
                                            tint = Color(0xFF25D366),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

