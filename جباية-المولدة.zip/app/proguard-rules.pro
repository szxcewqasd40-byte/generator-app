# ProGuard & R8 Optimization & Keep Rules for Google Play Release

# --- Attributes to Preserve ---
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

# --- Room Database ---
-keep class * extends androidx.room.RoomDatabase
-keep class * extends androidx.room.RoomDatabase$Callback
-keep class *_Impl { *; }
-keep class * extends androidx.room.EntityDeletionOrUpdateAdapter { *; }
-keep class * extends androidx.room.SharedSQLiteStatement { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    <init>(...);
}
-dontwarn androidx.room.paging.**
-dontwarn androidx.room.schema.SchemaBasicValidation

# --- All Application Packages, Data Classes, and Entities ---
-keep class com.example.** { *; }
-keepclassmembers class com.example.** { *; }

-keep class com.example.generator.** { *; }
-keepclassmembers class com.example.generator.** { *; }

-keep class com.example.generator.data.** { *; }
-keepclassmembers class com.example.generator.data.** { *; }

-keep class com.example.generator.data.entity.** { *; }
-keepclassmembers class com.example.generator.data.entity.** { *; }

-keep class com.generator.billing.** { *; }
-keepclassmembers class com.generator.billing.** { *; }

-keep class com.generator.billing.app.** { *; }
-keepclassmembers class com.generator.billing.app.** { *; }

# --- Kotlin Coroutines ---
-keep class kotlinx.coroutines.** { *; }
-keepclassmembers class kotlinx.coroutines.** { *; }
-keep class kotlin.coroutines.** { *; }
-keepclassmembers class kotlin.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**

# --- Firebase & Google Models ---
-keep class com.google.firebase.** { *; }
-keepclassmembers class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

-keep class com.google.android.gms.** { *; }
-keepclassmembers class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# --- Google Play Billing ---
-keep class com.android.billingclient.api.** { *; }
-keepclassmembers class com.android.billingclient.api.** { *; }
-dontwarn com.android.billingclient.api.**

# --- Google Credentials & Google ID ---
-keep class androidx.credentials.** { *; }
-keepclassmembers class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
-keepclassmembers class com.google.android.libraries.identity.googleid.** { *; }
-dontwarn androidx.credentials.**
-dontwarn com.google.android.libraries.identity.googleid.**

# --- Moshi & JSON Serialization ---
-keep class com.squareup.moshi.** { *; }
-keepclassmembers class com.squareup.moshi.** { *; }
-keep class * implements com.squareup.moshi.JsonAdapter { *; }
-keep @com.squareup.moshi.JsonQualifier class * { *; }
-keepclassmembers class * {
    @com.squareup.moshi.Json *;
    @com.squareup.moshi.JsonClass *;
}

# --- Retrofit & OkHttp ---
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}
-dontwarn retrofit2.**
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
